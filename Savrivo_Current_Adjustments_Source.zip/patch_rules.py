from pathlib import Path
import json, copy
p=Path('/mnt/data/savrivo_work/firebase/feastly-realtime-database-rules.json')
data=json.loads(p.read_text())
R=data['rules']['feastly']
OWNER="auth.token.savrivoRole === 'owner' || auth.token.savrivoRole === 'ops_admin' || auth.uid === 'r36PY4C5k0RIKrjXYjA3gWRMh9D3'"

def ownerwrap(): return f"({OWNER})"

def member_cap(rid_expr, cap):
    base=f"root.child('feastly/restaurantMembers').child({rid_expr}).child(auth.uid)"
    return f"({base}.child('active').val() === true && ({base}.child('role').val() === 'restaurant_owner' || {base}.child('role').val() === 'restaurant_manager' || {base}.child('permissions/{cap}').val() === true))"

def legacy_cap(rid_expr, cap):
    b="root.child('feastly/staff').child(auth.uid)"
    return f"({b}.child('active').val() === true && {b}.child('restaurantId').val() === {rid_expr} && ({b}.child('role').val() === 'restaurant_owner' || {b}.child('role').val() === 'restaurant_manager' || {b}.child('permissions/{cap}').val() === true))"

def cap(rid_expr, name): return f"({legacy_cap(rid_expr,name)} || {member_cap(rid_expr,name)})"

def member_active(rid_expr):
    return f"root.child('feastly/restaurantMembers').child({rid_expr}).child(auth.uid).child('active').val() === true"

# ---------- Settings schema ----------
C=R['settings']['customer']
C['.validate']="!newData.exists() || newData.hasChildren(['platformFee','freeDeliveryAbove','taxRate','deliverySlabs','maxDeliveryKm','updatedAt','updatedBy'])"
def num(maxv=1000000,minv=0): return {'.validate':f"newData.isNumber() && newData.val() >= {minv} && newData.val() <= {maxv}"}
def boolean(): return {'.validate':'newData.isBoolean()'}
C.update({
 'platformFee':num(5000),'freeDeliveryAbove':num(1000000),'taxRate':num(100),'maxDeliveryKm':num(500),
 'rainFeeEnabled':boolean(),'rainLightFee':num(500),'rainModerateFee':num(500),'rainHeavyFee':num(500),'rainSevereFee':num(500),'rainMinProbability':num(100),'rainLightMm':num(100),'rainModerateMm':num(100),'rainHeavyMm':num(100),'rainSevereMm':num(100),
 'surgeEnabled':boolean(),'surgeLowOrders':num(10000),'surgeMediumOrders':num(10000),'surgeHighOrders':num(10000),'surgeLowFee':num(5000),'surgeMediumFee':num(5000),'surgeHighFee':num(5000),'maxSurgeFee':num(5000),
 'smallOrderFeeEnabled':boolean(),'smallOrderThreshold':num(100000),'smallOrderFee':num(5000),'lateNightFeeEnabled':boolean(),'lateNightStartHour':num(23),'lateNightEndHour':num(23),'lateNightFee':num(5000),
})
C['deliverySlabs']={'$index':{'.validate':"newData.hasChildren(['maxKm','fee'])",'maxKm':num(500),'fee':num(5000),'$other':{'.validate':False}}}
C['platformFeeOverrides']={
 'cities':{'$key':num(5000)},'categories':{'$key':num(5000)},'restaurants':{'$key':num(5000)},
 'orderValueRules':{'$index':{'.validate':"newData.hasChildren(['min','fee'])",'min':num(1000000),'max':{'.validate':"!newData.exists() || (newData.isNumber() && newData.val() >= 0 && newData.val() <= 1000000)"},'fee':num(5000),'$other':{'.validate':False}}},
 '$other':{'.validate':False}
}
C['rainCityOverrides']={'$city':{'.validate':"newData.hasChildren(['light','moderate','heavy','severe'])",'light':num(500),'moderate':num(500),'heavy':num(500),'severe':num(500),'$other':{'.validate':False}}}
C['surgeCityOverrides']={'$city':{'.validate':"newData.hasChildren(['low','medium','high'])",'low':num(5000),'medium':num(5000),'high':num(5000),'$other':{'.validate':False}}}
# Remove old obsolete fields safely from schema? allow them for compatibility
for key,maxv in [('baseDeliveryFee',5000),('includedDeliveryKm',100),('perKmFee',1000),('minDeliveryFee',5000),('maxDeliveryFee',5000),('rainFee',500),('rainThresholdMm',100)]:
    C[key]=num(maxv)
C['$other']={'.validate':False}

# ---------- Catalog restaurant optional metadata/capacity ----------
CR=R['catalog']['restaurants']['$restaurantId']
CR['city']={'.validate':"newData.isString() && newData.val().length <= 120"}
CR['category']={'.validate':"newData.isString() && newData.val().length <= 120"}
CR['deliveryRadiusKm']={'.validate':"newData.isNumber() && newData.val() > 0 && newData.val() <= 500"}
CR['maxConcurrentOrders']={'.validate':"newData.isNumber() && newData.val() >= 1 && newData.val() <= 500"}
CR['autoPauseWhenBusy']={'.validate':'newData.isBoolean()'}

# Add membership alternative to catalog per-field writes via targeted transformations
legacy_patterns={
 'profile': "(root.child('feastly/staff').child(auth.uid).child('active').val() === true && root.child('feastly/staff').child(auth.uid).child('restaurantId').val() === $restaurantId && (root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_owner' || root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_manager' || root.child('feastly/staff').child(auth.uid).child('permissions/profile').val() === true))",
 'availability': "(root.child('feastly/staff').child(auth.uid).child('active').val() === true && root.child('feastly/staff').child(auth.uid).child('restaurantId').val() === $restaurantId && (root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_owner' || root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_manager' || root.child('feastly/staff').child(auth.uid).child('permissions/availability').val() === true))",
 'menu': "(root.child('feastly/staff').child(auth.uid).child('active').val() === true && root.child('feastly/staff').child(auth.uid).child('restaurantId').val() === $restaurantId && (root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_owner' || root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_manager' || root.child('feastly/staff').child(auth.uid).child('permissions/menu').val() === true))",
}
member_patterns={
 k: member_cap("$restaurantId",k) for k in legacy_patterns
}
def transform_strings(obj):
    if isinstance(obj,dict):
        for k,v in list(obj.items()): obj[k]=transform_strings(v)
        return obj
    if isinstance(obj,list): return [transform_strings(x) for x in obj]
    if isinstance(obj,str):
        for k,old in legacy_patterns.items():
            if old in obj: obj=obj.replace(old,f"({old} || {member_patterns[k]})")
        return obj
    return obj
R['catalog']['restaurants']['$restaurantId']=transform_strings(R['catalog']['restaurants']['$restaurantId'])
R['menus']['$restaurantId']['.write']=f"auth != null && ({OWNER} || {cap('$restaurantId','menu')})"

# ---------- Multi-restaurant membership reads ----------
RM=R['restaurantMembers']['$restaurantId']
RM['.read']=f"auth != null && ({OWNER} || {member_active('$restaurantId')} || (root.child('feastly/staff').child(auth.uid).child('active').val() === true && root.child('feastly/staff').child(auth.uid).child('restaurantId').val() === $restaurantId))"
# full member record validation, retaining flexibility
member=RM['$uid']
member['.read']=f"auth != null && (auth.uid === $uid || {OWNER} || {member_active('$restaurantId')})"
member['.validate']="!newData.exists() || (newData.hasChildren(['name','email','restaurantId','restaurantName','active','role','permissions','createdAt','createdBy']) && newData.child('restaurantId').val() === $restaurantId && (newData.child('role').val() === 'restaurant_owner' || newData.child('role').val() === 'restaurant_manager' || newData.child('role').val() === 'restaurant_staff'))"
for field,rule in {
 'name':"newData.isString() && newData.val().length <= 120",'email':"newData.isString() && newData.val().length <= 254",'restaurantId':"newData.val() === $restaurantId",'restaurantName':"newData.isString() && newData.val().length <= 160",'active':"newData.isBoolean()",'role':"newData.val() === 'restaurant_owner' || newData.val() === 'restaurant_manager' || newData.val() === 'restaurant_staff'",'mustSetPassword':"newData.isBoolean()",'createdAt':"newData.isNumber() && newData.val() > 0",'createdBy':"newData.isString() && newData.val().length <= 254"
}.items(): member[field]={'.validate':rule}
member['permissions']={'$permission':{'.validate':'newData.isBoolean()'}}
member['$other']={'.validate':False}

# ---------- Order lifecycle and rider privacy ----------
O=R['orders']['$uid']['$orderId']
rider_after_handover="(root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && data.child('riderId').val() === auth.uid && (data.child('status').val() === 'Handed to rider' || data.child('status').val() === 'Out for delivery' || data.child('status').val() === 'Near you' || data.child('status').val() === 'Arrived' || data.child('status').val() === 'Delivered'))"
rest_read=f"({legacy_cap("data.child('restaurantId').val()",'orders')} || {legacy_cap("data.child('restaurantId').val()",'handover')} || {legacy_cap("data.child('restaurantId').val()",'tracking')} || {member_cap("data.child('restaurantId').val()",'orders')} || {member_cap("data.child('restaurantId').val()",'handover')} || {member_cap("data.child('restaurantId').val()",'tracking')})"
O['.read']=f"auth != null && (auth.uid === $uid || {OWNER} || {rider_after_handover} || {rest_read})"

def status_write(rid_expr):
    orders_cap=cap(rid_expr,'orders'); handover_cap=cap(rid_expr,'handover')
    rest=f"(({orders_cap} && ((data.val() === 'Order placed' && newData.val() === 'Accepted') || (data.val() === 'Accepted' && newData.val() === 'Preparing') || (data.val() === 'Preparing' && newData.val() === 'Ready for pickup'))) || ({handover_cap} && (data.val() === 'Ready for pickup' || data.val() === 'Assigned') && newData.val() === 'Handed to rider' && newData.parent().child('riderId').exists()))"
    rider="(root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && newData.parent().child('riderId').val() === auth.uid && ((data.val() === 'Ready for pickup' && newData.val() === 'Assigned' && root.child('feastly/dispatchQueue').child($orderId).child('claim/riderId').val() === auth.uid) || (data.val() === 'Handed to rider' && newData.val() === 'Out for delivery') || (data.val() === 'Out for delivery' && (newData.val() === 'Near you' || newData.val() === 'Arrived')) || (data.val() === 'Near you' && newData.val() === 'Arrived') || (data.val() === 'Arrived' && newData.val() === 'Delivered') || data.val() === newData.val()))"
    return f"auth != null && ({rest} || {rider})"
O['status']['.write']=status_write("data.parent().child('restaurantId').val()")
O['updatedAt']['.write']=f"auth != null && ((root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && newData.parent().child('riderId').val() === auth.uid) || {cap("data.parent().child('restaurantId').val()",'orders')} || {cap("data.parent().child('restaurantId').val()",'handover')})"
O['statusHistory']['$eventId']['.write']=f"auth != null && !data.exists() && ((root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && newData.child('actorId').val() === auth.uid && newData.child('actorRole').val() === 'rider' && newData.parent().parent().child('riderId').val() === auth.uid) || (({cap("newData.parent().parent().child('restaurantId').val()",'orders')} || {cap("newData.parent().parent().child('restaurantId').val()",'handover')}) && newData.child('actorId').val() === auth.uid && newData.child('actorRole').val() === 'staff'))"

# Order pricing new fee fields
P=O['pricing']
P['.validate']="newData.hasChildren(['subtotal','discount','deliveryFee','smallOrderFee','lateNightFee','rainFee','surgeFee','platformFee','tax','tip','currency','source']) && newData.child('subtotal').val() >= newData.child('discount').val() && (newData.child('discount').val() === 0 || (newData.parent().child('coupon').isString() && newData.parent().child('coupon').val().length > 0))"
P['deliveryFee']={'.validate':"newData.isNumber() && newData.val() >= 0 && newData.val() <= 5000"}
P['platformFee']={'.validate':"newData.isNumber() && newData.val() >= 0 && newData.val() <= 5000"}
for k,maxv in [('smallOrderFee',5000),('lateNightFee',5000),('rainFee',500),('surgeFee',5000)]: P[k]=num(maxv)
P['$other']={'.validate':False}
terms="newData.parent().child('pricing/subtotal').val() - newData.parent().child('pricing/discount').val() + newData.parent().child('pricing/deliveryFee').val() + newData.parent().child('pricing/smallOrderFee').val() + newData.parent().child('pricing/lateNightFee').val() + newData.parent().child('pricing/rainFee').val() + newData.parent().child('pricing/surgeFee').val() + newData.parent().child('pricing/platformFee').val() + newData.parent().child('pricing/tax').val() + newData.parent().child('pricing/tip').val()"
O['total']['.validate']=f"newData.isNumber() && newData.val() >= 0 && newData.val() <= 1200000 && newData.val() >= {terms} - 0.01 && newData.val() <= {terms} + 0.01"
O['pricingContext']={
 '.validate':"newData.hasChildren(['distanceKm','platformFeeRule','weatherSeverity','surgeActiveOrders','pricedAt'])",
 'distanceKm':num(500),'platformFeeRule':{'.validate':"newData.isString() && newData.val().length <= 80"},'weatherSeverity':{'.validate':"newData.isString() && newData.val().length <= 30"},'surgeActiveOrders':num(10000),'pricedAt':{'.validate':"newData.isNumber() && newData.val() > 0 && newData.val() <= now + 300000"},'$other':{'.validate':False}
}
O['contactProxy']={'customerToRider':{'.validate':"newData.isString() && newData.val().length <= 40"},'riderToCustomer':{'.validate':"newData.isString() && newData.val().length <= 40"},'customerToRestaurant':{'.validate':"newData.isString() && newData.val().length <= 40"},'restaurantToCustomer':{'.validate':"newData.isString() && newData.val().length <= 40"},'restaurantToRider':{'.validate':"newData.isString() && newData.val().length <= 40"},'riderToRestaurant':{'.validate':"newData.isString() && newData.val().length <= 40"},'$other':{'.validate':False}}
# pricingContext optional on creation, parent other already false but child key now recognized

# address city both user/order
UA=R['users']['$uid']['addresses']['$index']; UA['city']={'.validate':"newData.isString() && newData.val().length > 0 && newData.val().length <= 120"}
OA=O['address']; OA['city']={'.validate':"newData.isString() && newData.val().length > 0 && newData.val().length <= 120"}

# ---------- Restaurant mirror lifecycle ----------
RO=R['restaurantOrders']['$restaurantId']
RO['.read']=f"auth != null && ({OWNER} || {cap('$restaurantId','orders')} || {cap('$restaurantId','handover')} || {cap('$restaurantId','tracking')})"
RORD=RO['$uid']['$orderId']
RORD['status']['.write']=status_write('$restaurantId')
RORD['updatedAt']['.write']=f"auth != null && ((root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && newData.parent().child('riderId').val() === auth.uid) || {cap('$restaurantId','orders')} || {cap('$restaurantId','handover')})"
RORD['statusHistory']['$eventId']['.write']=f"auth != null && !data.exists() && ((root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && newData.child('actorId').val() === auth.uid && newData.child('actorRole').val() === 'rider' && newData.parent().parent().child('riderId').val() === auth.uid) || (({cap('$restaurantId','orders')} || {cap('$restaurantId','handover')}) && newData.child('actorId').val() === auth.uid && newData.child('actorRole').val() === 'staff'))"

# dispatch queue write restaurant membership
DQ=R['dispatchQueue']['$orderId']
restaurant_dispatch=f"(newData.exists() && {cap("newData.child('restaurantId').val()",'orders')} && root.child('feastly/orders').child(newData.child('customerId').val()).child($orderId).child('restaurantId').val() === newData.child('restaurantId').val() && (root.child('feastly/orders').child(newData.child('customerId').val()).child($orderId).child('status').val() === 'Preparing' || root.child('feastly/orders').child(newData.child('customerId').val()).child($orderId).child('status').val() === 'Ready for pickup') && ((!data.exists() && !newData.child('claim').exists()) || (data.exists() && newData.child('claim/riderId').val() === data.child('claim/riderId').val() && newData.child('claim/riderName').val() === data.child('claim/riderName').val() && newData.child('claim/claimedAt').val() === data.child('claim/claimedAt').val())))"
rider_delete="(!newData.exists() && data.child('claim/riderId').val() === auth.uid && root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && root.child('feastly/orders').child(data.child('customerId').val()).child($orderId).child('riderId').val() === auth.uid)"
DQ['.write']=f"auth != null && ({OWNER} || {rider_delete} || {restaurant_dispatch})"

# ---------- Restaurant load ----------
R['restaurantLoad']={
 '.read':'auth != null',
 '$restaurantId':{
   '.write':f"auth != null && ({OWNER} || {cap('$restaurantId','orders')} || {cap('$restaurantId','availability')})",
   '.validate':"!newData.exists() || (newData.hasChildren(['restaurantId','activeOrders','preparing','ready','updatedAt']) && newData.child('restaurantId').val() === $restaurantId)",
   'restaurantId':{'.validate':"newData.isString() && newData.val() === $restaurantId"},'activeOrders':num(10000),'preparing':num(10000),'ready':num(10000),'updatedAt':{'.validate':"newData.isNumber() && newData.val() > 0 && newData.val() <= now + 300000"},'$other':{'.validate':False}
 }
}

# ---------- Rider job privacy-safe pointer ----------
RJ=R['riderJobs']['$riderId']['$orderId']
RJ['.validate']="!newData.exists() || (newData.hasChildren(['orderId','customerId','restaurantId','assignedAt','status','phase']) && newData.child('orderId').val() === $orderId)"
for key,rule in {
 'restaurantName':"newData.isString() && newData.val().length <= 160",'restaurantAddress':"newData.isString() && newData.val().length <= 500",'approximateDropZone':"newData.isString() && newData.val().length <= 180",'orderStatus':"newData.val() === 'Assigned' || newData.val() === 'Handed to rider' || newData.val() === 'Out for delivery' || newData.val() === 'Near you' || newData.val() === 'Arrived' || newData.val() === 'Delivered'",'itemCount':"newData.isNumber() && newData.val() >= 0 && newData.val() <= 100",'payout':"newData.isNumber() && newData.val() >= 0 && newData.val() <= 100000",'estimatedMinutes':"newData.isNumber() && newData.val() >= 0 && newData.val() <= 360",'restaurantLat':"!newData.exists() || (newData.isNumber() && newData.val() >= -90 && newData.val() <= 90)",'restaurantLng':"!newData.exists() || (newData.isNumber() && newData.val() >= -180 && newData.val() <= 180)",'handoverAt':"!newData.exists() || (newData.isNumber() && newData.val() > 0 && newData.val() <= now + 300000)"
}.items(): RJ[key]={'.validate':rule}
# existing updatedAt child may exist; ensure validation
RJ['updatedAt']={'.write':RJ.get('updatedAt',{}).get('.write',"auth != null && auth.uid === $riderId"),'.validate':"newData.isNumber() && newData.val() > 0 && newData.val() <= now + 300000"}
# restaurant can only write pointer handover/order status when it owns order
pointer_rest=f"auth != null && (auth.uid === $riderId || {OWNER} || (({cap("root.child('feastly/orders').child(data.parent().child('customerId').val()).child($orderId).child('restaurantId').val()",'handover')}) && root.child('feastly/orders').child(data.parent().child('customerId').val()).child($orderId).child('riderId').val() === $riderId))"
for key in ['orderStatus','handoverAt','updatedAt']:
    RJ[key]['.write']=pointer_rest
RJ['$other']={'.validate':False}

# ---------- Restaurant invites membership-aware ----------
RI=R['restaurantStaffInvites']['$restaurantId']
RI['.read']=f"auth != null && ({OWNER} || {member_cap('$restaurantId','ownership')} || (root.child('feastly/staff').child(auth.uid).child('active').val() === true && root.child('feastly/staff').child(auth.uid).child('restaurantId').val() === $restaurantId && root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_owner'))"
RI['$inviteId']['.write']=f"auth != null && ({OWNER} || (({member_active('$restaurantId')} || (root.child('feastly/staff').child(auth.uid).child('active').val() === true && root.child('feastly/staff').child(auth.uid).child('restaurantId').val() === $restaurantId)) && (root.child('feastly/restaurantMembers').child($restaurantId).child(auth.uid).child('role').val() === 'restaurant_owner' || root.child('feastly/staff').child(auth.uid).child('role').val() === 'restaurant_owner') && !data.exists() && newData.child('requestedBy').val() === auth.uid && newData.child('status').val() === 'requested'))"

# ---------- Order chat ----------
order_ref="root.child('feastly/orders').child($uid).child($orderId)"
restaurant_chat=f"({cap(order_ref+".child('restaurantId').val()",'orders')} || {cap(order_ref+".child('restaurantId').val()",'handover')})"
rider_chat=f"(root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && {order_ref}.child('riderId').val() === auth.uid)"
R['orderChats']={
 '$uid':{'$orderId':{'$channel':{
  '.read':f"auth != null && (auth.uid === $uid || {OWNER} || {restaurant_chat} || {rider_chat})",
  '$messageId':{
   '.write':f"auth != null && !data.exists() && ((auth.uid === $uid && ( $channel === 'customerRider' || $channel === 'customerRestaurant') && newData.child('senderRole').val() === 'customer') || ({restaurant_chat} && ($channel === 'customerRestaurant' || $channel === 'restaurantRider') && newData.child('senderRole').val() === 'restaurant') || ({rider_chat} && ($channel === 'customerRider' || $channel === 'restaurantRider') && newData.child('senderRole').val() === 'rider')) && newData.child('senderId').val() === auth.uid",
   '.validate':"newData.hasChildren(['id','senderId','senderRole','body','masked','at']) && newData.child('id').val() === $messageId",
   'id':{'.validate':"newData.isString() && newData.val() === $messageId"},'senderId':{'.validate':"newData.isString() && newData.val() === auth.uid"},'senderRole':{'.validate':"newData.val() === 'customer' || newData.val() === 'restaurant' || newData.val() === 'rider'"},
   'body':{'.validate':"newData.isString() && newData.val().length > 0 && newData.val().length <= 800 && !newData.val().matches(/.*[6-9][0-9]{9}.*/)"},'masked':{'.validate':'newData.isBoolean()'},'at':{'.validate':"newData.isNumber() && newData.val() > 0 && newData.val() <= now + 300000"},'$other':{'.validate':False}
  }
 }}}
}

# Keep top-level unknown false
p.write_text(json.dumps(data,indent=2)+"\n")
json.loads(p.read_text())
print('rules patched')
