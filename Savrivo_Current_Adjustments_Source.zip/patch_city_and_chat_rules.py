from pathlib import Path
import json

work=Path('/mnt/data/savrivo_work')
na=work/'native_android'

# --- Native customer geocoder: propagate city/locality to JS ---
p=na/'app/src/main/java/com/feastly/app/MainActivity.java'
s=p.read_text()
s=s.replace('''        String area = "Nearby";\n        String details = String.format(Locale.US, "%.5f, %.5f", location.getLatitude(), location.getLongitude());''','''        String area = "Nearby";\n        String city = "";\n        String details = String.format(Locale.US, "%.5f, %.5f", location.getLatitude(), location.getLongitude());''',1)
s=s.replace('''              if (notEmpty(address.getSubLocality())) area = address.getSubLocality();\n              else if (notEmpty(address.getLocality())) area = address.getLocality();\n              if (notEmpty(address.getAddressLine(0))) details = address.getAddressLine(0);''','''              if (notEmpty(address.getSubLocality())) area = address.getSubLocality();\n              else if (notEmpty(address.getLocality())) area = address.getLocality();\n              if (notEmpty(address.getLocality())) city = address.getLocality();\n              else if (notEmpty(address.getSubAdminArea())) city = address.getSubAdminArea();\n              if (notEmpty(address.getAddressLine(0))) details = address.getAddressLine(0);''',1)
s=s.replace('''        publishDetectedLocation(label, area, details, location.getLatitude(), location.getLongitude());''','''        publishDetectedLocation(label, area, city, details, location.getLatitude(), location.getLongitude());''',1)
s=s.replace('''  private void publishDetectedLocation(String label, String area, String details,\n                                       double latitude, double longitude) {''','''  private void publishDetectedLocation(String label, String area, String city, String details,\n                                       double latitude, double longitude) {''',1)
s=s.replace('''        + escapeJavascript(label) + "','" + escapeJavascript(area) + "','"\n        + escapeJavascript(details) + "'," + latitude + "," + longitude + ");";''','''        + escapeJavascript(label) + "','" + escapeJavascript(area) + "','"\n        + escapeJavascript(city) + "','" + escapeJavascript(details) + "'," + latitude + "," + longitude + ");";''',1)
p.write_text(s)
print('✅ Customer native location now supplies city/locality')

# --- Customer JS callback accepts city ---
p=na/'app/src/main/assets/premium.js'
s=p.read_text()
s=s.replace('''  window.setDetectedLocation = async function (label, area, details, lat, lng) {''','''  window.setDetectedLocation = async function (label, area, city, details, lat, lng) {''',1)
s=s.replace('''      if(!draft.area&&area)draft.area=area;if(!draft.address&&details)draft.address=details;''','''      if(!draft.area&&area)draft.area=area;if(!draft.city&&city)draft.city=city;if(!draft.address&&details)draft.address=details;''',1)
s=s.replace('''    const record={id:"current-location",label:label||"Current location",area:area||"Nearby",address:details||"Current delivery location",phone:current&&current.phone||state.profile.phone||"",lat:Number(lat),lng:Number(lng),source:"gps",updatedAt:Date.now()};''','''    const record={id:"current-location",label:label||"Current location",area:area||"Nearby",city:city||current&&current.city||area||"",address:details||"Current delivery location",phone:current&&current.phone||state.profile.phone||"",lat:Number(lat),lng:Number(lng),source:"gps",updatedAt:Date.now()};''',1)
p.write_text(s)
print('✅ GPS addresses persist city for city-based discovery/pricing')

# --- Firebase chats: channel-scoped read privacy and stronger phone blocking ---
rules_path=work/'firebase/feastly-realtime-database-rules.json'
data=json.loads(rules_path.read_text())
root=data['rules']['feastly']
chat=root['orderChats']['$uid']['$orderId']['$channel']
owner="(auth.token.savrivoRole === 'owner' || auth.token.savrivoRole === 'ops_admin' || auth.uid === 'r36PY4C5k0RIKrjXYjA3gWRMh9D3')"
order="root.child('feastly/orders').child($uid).child($orderId)"
rid=f"{order}.child('restaurantId').val()"
staff=(
    "((root.child('feastly/staff').child(auth.uid).child('active').val() === true "
    f"&& root.child('feastly/staff').child(auth.uid).child('restaurantId').val() === {rid}) "
    "|| (root.child('feastly/restaurantMembers').child("+rid+").child(auth.uid).child('active').val() === true))"
)
rider=f"(root.child('feastly/riders').child(auth.uid).child('status').val() === 'approved' && {order}.child('riderId').val() === auth.uid)"
customer="auth.uid === $uid"
chat['.read']=(
    "auth != null && ("+owner+
    " || (($channel === 'customerRestaurant') && ("+customer+" || "+staff+"))"
    " || (($channel === 'customerRider') && ("+customer+" || "+rider+"))"
    " || (($channel === 'restaurantRider') && ("+staff+" || "+rider+"))"
    ")"
)
# Block common Indian mobile-number formats even if a modified client skips masking.
chat['$messageId']['body']['.validate']=(
    "newData.isString() && newData.val().length > 0 && newData.val().length <= 800 "
    "&& !newData.val().matches(/.*(?:\\+?91[ .()_-]*)?[6-9](?:[ .()_-]*[0-9]){9}.*/)"
)
rules_path.write_text(json.dumps(data,indent=2)+'\n')
json.loads(rules_path.read_text())
print('✅ Chat reads are channel-scoped; common phone formats blocked server-side')
