from pathlib import Path
p=Path('/mnt/data/savrivo_work/native_android/restaurant/src/main/assets/premium.js')
s=p.read_text()

old='const state={route:"login",history:[],routeData:{},session:load("savrivo.restaurant.session",null),member:null,restaurant:null,menus:{},orders:[],selectedOrderId:"",network:navigator.onLine,loading:false,error:"",lastSync:0,sheet:null,toastTimer:null,watchers:[],syncTimer:null,mapZoom:16,mapDraft:null};'
new='const state={route:"login",history:[],routeData:{},session:load("savrivo.restaurant.session",null),member:null,memberships:{},selectedRestaurantId:localStorage.getItem("savrivo.restaurant.selectedRestaurantId")||"",restaurant:null,menus:{},orders:[],selectedOrderId:"",network:navigator.onLine,loading:false,error:"",lastSync:0,sheet:null,toastTimer:null,watchers:[],syncTimer:null,mapZoom:16,mapDraft:null,chat:{orderId:"",channel:"",messages:[],title:"Chat"}};'
assert old in s;s=s.replace(old,new,1)

old='function restaurantId(){return state.member&&state.member.restaurantId||""}'
new='''function restaurantId(){return state.selectedRestaurantId||state.member&&state.member.restaurantId||""}
  function maskPhoneNumbers(value){return String(value||"").replace(/(?:\\+?91[\\s.()-]*)?[6-9](?:[\\s.()-]*\\d){9}/g,"[phone number hidden]")}
  function membershipFor(rid){return state.memberships&&state.memberships[rid]||null}
  async function switchRestaurant(rid){const member=membershipFor(rid);if(!member)return;state.selectedRestaurantId=rid;state.member=member;localStorage.setItem("savrivo.restaurant.selectedRestaurantId",rid);state.restaurant=null;state.menus={};state.orders=[];closeRealtime();state.loading=true;render({preserve:true});try{await sync(true);startRealtime();state.route="dashboard";state.history=[];toast("Switched to "+(state.restaurant&&state.restaurant.name||member.restaurantName||rid)+".","success")}catch(e){toast(friendly(e),"danger")}finally{state.loading=false;render()}}
  function chatPath(o,channel){return ROOT+"/orderChats/"+encodeURIComponent(o.userId||o.customerId)+"/"+encodeURIComponent(o.id)+"/"+channel}
  async function openChat(o,channel,title){if(!o)return;try{const raw=await db("GET",chatPath(o,channel));state.chat={orderId:o.id,channel,messages:Object.keys(raw||{}).map(id=>Object.assign({id},raw[id]||{})).sort((a,b)=>Number(a.at||0)-Number(b.at||0)),title:title||"Order chat"};go("chat",{orderId:o.id,channel})}catch(e){toast("Chat could not open. "+friendly(e),"danger")}}
  async function sendChat(form){const o=order(state.chat.orderId),original=String(new FormData(form).get("message")||"").trim();if(!o||!original)return;const body=maskPhoneNumbers(original).slice(0,800),id=uid("m_").replace(/-/g,""),record={id,senderId:state.session.uid,senderRole:"restaurant",body,masked:body!==original,at:Date.now()};try{await db("PUT",chatPath(o,state.chat.channel)+"/"+id,record);state.chat.messages.push(record);form.reset();render({preserve:true});if(record.masked)toast("A phone number was hidden for privacy.","success")}catch(e){toast("Message could not be sent. "+friendly(e),"danger")}}'''
assert old in s;s=s.replace(old,new,1)

# Multi restaurant membership resolver
old='async function resolveMember(){const m=await db("GET",ROOT+"/staff/"+state.session.uid);if(!m||m.active!==true)throw new Error("STAFF_INACTIVE");if(!m.restaurantId)throw new Error("RESTAURANT_SCOPE_MISSING");state.member=m}'
new='''async function resolveMember(){const uidValue=state.session.uid,links=await db("GET",ROOT+"/userRestaurants/"+uidValue).catch(()=>null),memberships={};if(links){for(const rid of Object.keys(links||{})){if(links[rid]!==true)continue;const m=await db("GET",ROOT+"/restaurantMembers/"+encodeURIComponent(rid)+"/"+uidValue).catch(()=>null);if(m&&m.active!==false)memberships[rid]=Object.assign({},m,{restaurantId:m.restaurantId||rid})}}const legacy=await db("GET",ROOT+"/staff/"+uidValue).catch(()=>null);if(legacy&&legacy.active===true&&legacy.restaurantId&&!memberships[legacy.restaurantId])memberships[legacy.restaurantId]=legacy;if(!Object.keys(memberships).length)throw new Error("STAFF_INACTIVE");state.memberships=memberships;let rid=state.selectedRestaurantId;if(!rid||!memberships[rid])rid=Object.keys(memberships)[0];state.selectedRestaurantId=rid;state.member=memberships[rid];localStorage.setItem("savrivo.restaurant.selectedRestaurantId",rid)}'''
assert old in s;s=s.replace(old,new,1)

# Add load publication + auto-pause helper before sync
needle='  async function sync(silent){'
insert='''  function activeKitchenOrders(){return state.orders.filter(o=>!["Delivered","Cancelled"].includes(o.status))}
  async function publishRestaurantLoad(){if(!state.session||!state.member||!restaurantId())return;const active=activeKitchenOrders(),record={restaurantId:restaurantId(),activeOrders:active.length,preparing:state.orders.filter(o=>["Accepted","Preparing"].includes(o.status)).length,ready:state.orders.filter(o=>["Ready for pickup","Assigned"].includes(o.status)).length,updatedAt:Date.now()};await db("PUT",ROOT+"/restaurantLoad/"+encodeURIComponent(restaurantId()),record);if(state.restaurant&&state.restaurant.autoPauseWhenBusy===true&&state.restaurant.open!==false&&Number(state.restaurant.maxConcurrentOrders||0)>0&&active.length>=Number(state.restaurant.maxConcurrentOrders)){await db("PATCH",ROOT+"/catalog/restaurants/"+encodeURIComponent(restaurantId()),{open:false,offlineReason:"Auto-paused: kitchen capacity reached",offlineUntil:Date.now()+30*60000,updatedAt:Date.now(),updatedBy:state.session.email}).catch(()=>{});state.restaurant.open=false;state.restaurant.offlineReason="Auto-paused: kitchen capacity reached"}}
'''
assert needle in s;s=s.replace(needle,insert+needle,1)
old='state.orders=flattenOrders(result[2]||{});await ensureNormalizedMenu();state.lastSync=Date.now();'
new='state.orders=flattenOrders(result[2]||{});await publishRestaurantLoad().catch(()=>{});await ensureNormalizedMenu();state.lastSync=Date.now();'
assert old in s;s=s.replace(old,new,1)

# Kitchen board and chat screens before profile
needle='  function screenProfile(){'
insert='''  function kitchenElapsed(o){const minutes=Math.max(0,Math.floor((Date.now()-Number(o.updatedAt||o.createdAt||Date.now()))/60000)),target=Math.max(5,Number(o.etaMin||state.restaurant&&state.restaurant.etaMin||20));return{minutes,remaining:Math.max(0,target-minutes),late:minutes>target}}
  function kitchenCard(o){const t=kitchenElapsed(o),next=nextStatus(o);return'<article class="card stack"><div class="cluster between"><div><span class="status '+(t.late?'danger':'')+'">'+h(o.status)+'</span><h3 class="card-title" style="margin-top:8px">'+h(o.id)+'</h3></div><strong class="'+(t.late?'danger-text':'')+'">'+(t.late?"Late "+(t.minutes-t.remaining)+" min":t.remaining+" min left")+'</strong></div><p class="supporting">'+h((o.items||[]).map(i=>(i.quantity||1)+'× '+i.name).join(" · "))+'</p>'+(next&&["Accepted","Preparing","Ready for pickup"].includes(next)?'<button class="button primary full" data-action="advance-order" data-order-id="'+h(o.id)+'" data-status="'+h(next)+'">'+h(next)+'</button>':'')+'</article>'}
  function screenKitchen(){const groups=[["New",state.orders.filter(o=>o.status==="Order placed")],["Preparing",state.orders.filter(o=>["Accepted","Preparing"].includes(o.status))],["Ready",state.orders.filter(o=>["Ready for pickup","Assigned"].includes(o.status))]];return'<main class="screen"><div class="content page">'+top("Kitchen board","Prep timers, workload and handover",'<button class="icon-button" data-action="refresh">'+icon("refresh")+'</button>')+banner()+'<section class="metric-grid">'+metric("ACTIVE",activeKitchenOrders().length,"Current workload",activeKitchenOrders().length>=Number(state.restaurant&&state.restaurant.maxConcurrentOrders||999)?"warning":"")+metric("PREPARING",groups[1][1].length,"In kitchen","")+metric("READY",groups[2][1].length,"Pickup queue","success")+'</section>'+groups.map(g=>'<section class="stack"><div class="cluster between"><h2 class="section-title">'+g[0]+'</h2><span class="status">'+g[1].length+'</span></div>'+(g[1].length?g[1].map(kitchenCard).join(""):empty("orders","Nothing here","Orders move here automatically."))+'</section>').join("")+'</div>'+nav()+'</main>'}
  function screenChat(){const o=order(state.chat.orderId),messages=state.chat.messages||[];if(!o)return screenOrders();return'<main class="screen"><div class="content page">'+top(state.chat.title||"Order chat","Order "+o.id)+'<div class="notice info">'+icon("shield","small")+'<span>Real phone numbers are not displayed. Any phone number typed here is hidden before sending.</span></div><section class="card chat-thread">'+(messages.length?messages.map(m=>'<div class="chat-message '+(m.senderId===state.session.uid?'mine':'')+'"><strong>'+h(m.senderRole||"user")+'</strong><p>'+h(m.body||"")+'</p><span class="caption">'+h(new Date(Number(m.at||0)).toLocaleTimeString("en-IN",{hour:"numeric",minute:"2-digit"}))+'</span></div>').join(""):empty("users","No messages yet","Use chat for order coordination."))+'</section><form id="chat-form" class="card cluster"><input class="input grow" name="message" maxlength="800" placeholder="Type a message" required><button class="button primary" type="submit">Send</button></form></div>'+nav()+'</main>'}
'''
assert needle in s;s=s.replace(needle,insert+needle,1)

# Profile add city/category, capacity and auto pause fields
old='<div class="field"><label>Cuisines</label><input class="input" name="cuisines" value="'+"'+h((r.cuisines||[]).join(\", \"))+'"+'"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">'
# Use simpler literal via source substring
literal='''<div class="field"><label>Cuisines</label><input class="input" name="cuisines" value="'+h((r.cuisines||[]).join(", "))+'"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">'''
repl='''<div class="field"><label>Cuisines</label><input class="input" name="cuisines" value="'+h((r.cuisines||[]).join(", "))+'"></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px"><div class="field"><label>City</label><input class="input" name="city" value="'+h(r.city||"")+'" placeholder="Nellore"></div><div class="field"><label>Restaurant category</label><input class="input" name="category" value="'+h(r.category||r.type||"")+'" placeholder="Biryani, Cafe, Fast food"></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">'''
assert literal in s;s=s.replace(literal,repl,1)
# add capacity before cover photo
literal='''</section><section class="card form-grid"><h2 class="section-title">Cover photo</h2>'''
repl='''</section><section class="card form-grid"><h2 class="section-title">Kitchen capacity</h2><div class="field"><label>Maximum concurrent active orders</label><input class="input" name="maxConcurrentOrders" type="number" min="1" max="500" value="'+h(r.maxConcurrentOrders||20)+'"></div><label class="notice info"><input type="checkbox" name="autoPauseWhenBusy" '+(r.autoPauseWhenBusy===true?'checked':'')+'><span>Automatically pause new orders for 30 minutes when this limit is reached.</span></label></section><section class="card form-grid"><h2 class="section-title">Cover photo</h2>'''
assert literal in s;s=s.replace(literal,repl,1)

# More screen with restaurant switcher and kitchen shortcut
start=s.index('  function screenMore(){')
end=s.index('\n  function screenStaff()',start)
new_func='''  function screenMore(){const memberships=Object.keys(state.memberships||{});return'<main class="screen"><div class="content page">'+top("More","Access and account")+'<section class="card stack"><div class="settings-row"><span class="grow"><strong>'+h(state.member&&state.member.name||"Restaurant user")+'</strong><span class="caption" style="display:block">'+h((state.member&&state.member.role||"restaurant_staff").replace(/_/g," "))+'</span></span></div>'+(memberships.length>1?'<div><h2 class="section-title">Switch restaurant</h2><div class="stack" style="margin-top:10px">'+memberships.map(rid=>'<button class="button '+(rid===restaurantId()?'primary':'tonal')+' full" data-action="switch-restaurant" data-restaurant-id="'+h(rid)+'">'+h((state.memberships[rid]&&state.memberships[rid].restaurantName)||rid)+'</button>').join("")+'</div></div>':'')+'<button class="button tonal full" data-action="go" data-route="kitchen">'+icon("orders")+' Kitchen board</button><button class="button tonal full" data-action="staff">'+icon("users")+' Staff & invitations</button><button class="button danger full" data-action="logout">'+icon("logout")+' Sign out</button></section></div>'+nav()+'</main>'}'''
s=s[:start]+new_func+s[end:]

# Order screen replace to add chats and clear lifecycle owner
start=s.index('  function screenOrder(){')
end=s.index('\n  function screenMenu()',start)
new_func='''  function screenOrder(){const o=order();if(!o)return'<main class="screen"><div class="content page">'+top("Order unavailable","Refresh and try again")+empty("orders","Order not found","This account cannot access the order.","refresh","Refresh")+'</div>'+nav()+'</main>';const next=nextStatus(o);return'<main class="screen"><div class="content page">'+top("Order "+o.id,o.status)+'<section class="card stack"><div class="cluster between"><span class="status">'+h(o.status)+'</span><strong>'+money(o.total||o.pricing&&o.pricing.total||0)+'</strong></div><div class="stack">'+(o.items||[]).map(i=>'<div class="settings-row"><span class="grow"><strong>'+h((i.quantity||1)+'× '+i.name)+'</strong><span class="caption" style="display:block">'+h(i.note||"")+'</span></span><span>'+money((Number(i.price||0)+Number(i.variantPrice||0)+Number(i.addOnTotal||0))*Number(i.quantity||1))+'</span></div>').join("")+'</div></section><section class="card stack"><h2 class="section-title">Delivery</h2><p class="supporting">'+h(o.address&&o.address.address||o.address&&o.address.details||"Delivery address")+'</p>'+(o.riderName?'<div class="notice info"><strong>Rider:</strong>&nbsp;'+h(o.riderName)+'</div>':'<p class="caption">Rider will be assigned after the order is ready.</p>')+'</section><section class="card stack"><h2 class="section-title">Communication</h2><p class="supporting">Use Savrivo chat instead of exchanging personal mobile numbers.</p><div class="cluster wrap"><button class="button tonal grow" data-action="open-chat" data-channel="customerRestaurant" data-order-id="'+h(o.id)+'">Chat customer</button>'+(o.riderId?'<button class="button tonal grow" data-action="open-chat" data-channel="restaurantRider" data-order-id="'+h(o.id)+'">Chat rider</button>':'')+'</div></section>'+(next?'<button class="button primary full" data-action="advance-order" data-order-id="'+h(o.id)+'" data-status="'+h(next)+'">'+h(next)+'</button>':'')+'</div>'+nav()+'</main>'}'''
s=s[:start]+new_func+s[end:]

# Fix advance actor role, update rider pointer on handover and publish load
old='event={status,at:now,actorId:state.session.uid,actorRole:state.member.role||"restaurant_staff"},changes={}'
new='event={status,at:now,actorId:state.session.uid,actorRole:"staff",detail:(state.member.role||"restaurant_staff").replace(/_/g," ")},changes={}'
assert old in s;s=s.replace(old,new,1)
old='if(status==="Ready for pickup"&&!o.riderId){changes["dispatchQueue/"+o.id]=dispatchRecord(o,now)}try{await db("PATCH",ROOT,changes);o.status=status;o.updatedAt=now;toast'
new='if(status==="Ready for pickup"&&!o.riderId){changes["dispatchQueue/"+o.id]=dispatchRecord(o,now)}if(status==="Handed to rider"&&o.riderId){changes["riderJobs/"+o.riderId+"/"+o.id+"/orderStatus"]="Handed to rider";changes["riderJobs/"+o.riderId+"/"+o.id+"/handoverAt"]=now;changes["riderJobs/"+o.riderId+"/"+o.id+"/updatedAt"]=now}try{await db("PATCH",ROOT,changes);o.status=status;o.updatedAt=now;await publishRestaurantLoad().catch(()=>{});toast'
assert old in s;s=s.replace(old,new,1)

# Save profile new fields
old='changes={description:String(fd.get("description")||"").trim(),cuisines:String(fd.get("cuisines")||"").split(",").map(x=>x.trim()).filter(Boolean),etaMin:Number(fd.get("etaMin")||25),etaMax:Number(fd.get("etaMax")||35),opensUntil:String(fd.get("opensUntil")||"").trim(),address:String(fd.get("address")||"").trim(),updatedAt:Date.now(),updatedBy:state.session.email}'
new='changes={description:String(fd.get("description")||"").trim(),cuisines:String(fd.get("cuisines")||"").split(",").map(x=>x.trim()).filter(Boolean),city:String(fd.get("city")||"").trim(),category:String(fd.get("category")||"").trim(),etaMin:Number(fd.get("etaMin")||25),etaMax:Number(fd.get("etaMax")||35),opensUntil:String(fd.get("opensUntil")||"").trim(),address:String(fd.get("address")||"").trim(),maxConcurrentOrders:Number(fd.get("maxConcurrentOrders")||20),autoPauseWhenBusy:fd.get("autoPauseWhenBusy")==="on",updatedAt:Date.now(),updatedBy:state.session.email}'
assert old in s;s=s.replace(old,new,1)

# Click actions switch/chat
needle='if(a==="open-order"){go("order",{orderId:c.dataset.orderId});return}'
rep=needle+'if(a==="switch-restaurant"){switchRestaurant(c.dataset.restaurantId);return}if(a==="open-chat"){const o=order(c.dataset.orderId);if(o)openChat(o,c.dataset.channel,c.dataset.channel==="customerRestaurant"?"Chat with customer":"Chat with rider");return}'
assert needle in s;s=s.replace(needle,rep,1)

# Submit chat
old='if(form.id==="invite-form"){inviteStaff(form);return}}'
new='if(form.id==="invite-form"){inviteStaff(form);return}if(form.id==="chat-form"){sendChat(form);return}}'
assert old in s;s=s.replace(old,new,1)

# Logout clear selection/memberhips (keep selected id okay but memberships reset)
old='state.session=null;state.member=null;state.restaurant=null;state.menus={};state.orders=[];localStorage.removeItem("savrivo.restaurant.session");'
new='state.session=null;state.member=null;state.memberships={};state.restaurant=null;state.menus={};state.orders=[];localStorage.removeItem("savrivo.restaurant.session");'
s=s.replace(old,new,1)

# Screens add kitchen/chat
old='Object.assign(SCREENS,{login:screenLogin,dashboard:screenDashboard,orders:screenOrders,order:screenOrder,menu:screenMenu,profile:screenProfile,more:screenMore,staff:screenStaff});'
new='Object.assign(SCREENS,{login:screenLogin,dashboard:screenDashboard,orders:screenOrders,order:screenOrder,kitchen:screenKitchen,chat:screenChat,menu:screenMenu,profile:screenProfile,more:screenMore,staff:screenStaff});'
assert old in s;s=s.replace(old,new,1)

p.write_text(s)
print('restaurant patched')
