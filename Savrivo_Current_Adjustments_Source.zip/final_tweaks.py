from pathlib import Path
import re
root=Path('/mnt/data/savrivo_work/native_android')

# ---------- Partner: remove dead verification screen ----------
p=root/'rider/src/main/assets/premium.js'
s=p.read_text()
s,n=re.subn(r'\n\s*function screenVerify\(\)\{.*?\}\n(?=\s*function screenOnboarding\()', '\n', s, count=1, flags=re.S)
if n:
    print('✅ Removed dead Partner email-verification screen')
else:
    print('ℹ️ Partner verification screen already absent')
p.write_text(s)

# ---------- Customer: city filtering + nearby option + placeholder ----------
p=root/'app/src/main/assets/premium.js'
s=p.read_text()
# allow local SVG asset in safeUrl
s=s.replace(r'(?:jpg|jpeg|png|webp)', r'(?:jpg|jpeg|png|webp|svg)', 1)
# card fallback and hero fallback
s=s.replace('safeUrl(r.image,"veg-meal.jpg")','safeUrl(r.image,"restaurant-placeholder.svg")')
s=s.replace('safeUrl(r.image,"55-bistro.jpg")','safeUrl(r.image,"restaurant-placeholder.svg")')
# add city-aware filtering after address acquisition
needle='''    const address=currentAddress();\n    const pinned=address\n      &&Number.isFinite(Number(address.lat))\n      &&Number.isFinite(Number(address.lng));\n\n    if(pinned)\n      list=list.filter(restaurantServiceable);'''
replacement='''    const address=currentAddress();\n    const customerCity=keyName(address&&address.city||"");\n    if(customerCity){\n      const cityTagged=list.some(r=>keyName(r.city||""));\n      if(cityTagged)list=list.filter(r=>!keyName(r.city||"")||keyName(r.city)===customerCity);\n    }\n    const pinned=address\n      &&Number.isFinite(Number(address.lat))\n      &&Number.isFinite(Number(address.lng));\n\n    if(pinned)\n      list=list.filter(restaurantServiceable);'''
if needle not in s:
    raise SystemExit('Customer city-filter insertion marker not found')
s=s.replace(needle,replacement,1)
# add Nearby option in filter sheet
old='''<option value="recommended" '+(state.sort==="recommended"?'selected':'')+'>Recommended</option><option value="rating"'''
new='''<option value="recommended" '+(state.sort==="recommended"?'selected':'')+'>Recommended</option><option value="nearby" '+(state.sort==="nearby"?'selected':'')+'>Nearby first</option><option value="rating"'''
if old not in s:
    raise SystemExit('Customer Nearby sort marker not found')
s=s.replace(old,new,1)
p.write_text(s)
print('✅ Added city-aware restaurant discovery and Nearby sort')
print('✅ Added clean restaurant placeholder fallback')

# ---------- Customer CSP for Google Weather ----------
p=root/'app/src/main/assets/premium.html'
s=p.read_text()
if 'https://weather.googleapis.com' not in s:
    s=s.replace('connect-src ', 'connect-src https://weather.googleapis.com ', 1)
    print('✅ Customer CSP allows Google Weather API')
p.write_text(s)

# ---------- Clean fallback restaurant image (local SVG asset) ----------
svg=root/'app/src/main/assets/restaurant-placeholder.svg'
svg.write_text('''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 960 640" role="img" aria-label="Savrivo restaurant image placeholder">\n  <defs>\n    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">\n      <stop offset="0" stop-color="#0b3f91"/>\n      <stop offset="0.62" stop-color="#155eef"/>\n      <stop offset="1" stop-color="#31b6f6"/>\n    </linearGradient>\n  </defs>\n  <rect width="960" height="640" fill="url(#g)"/>\n  <circle cx="755" cy="115" r="180" fill="none" stroke="#fff" stroke-opacity=".10" stroke-width="44"/>\n  <circle cx="210" cy="540" r="220" fill="none" stroke="#fff" stroke-opacity=".08" stroke-width="54"/>\n  <g fill="none" stroke="#fff" stroke-width="18" stroke-linecap="round" stroke-linejoin="round" opacity=".95">\n    <path d="M395 210v220M355 210v90c0 44 80 44 80 0v-90M500 210v220M500 210c70 30 70 130 0 155"/>\n  </g>\n  <text x="480" y="500" text-anchor="middle" font-family="system-ui, sans-serif" font-size="42" font-weight="700" fill="#fff">Savrivo Restaurant</text>\n  <text x="480" y="548" text-anchor="middle" font-family="system-ui, sans-serif" font-size="24" fill="#fff" opacity=".78">Restaurant photo coming soon</text>\n</svg>\n''')

# ---------- Customer CSS card layout + chat ----------
p=root/'app/src/main/assets/premium.css'
s=p.read_text()
extra='''\n\n/* Savrivo operational upgrade: restaurant-card alignment and private order chat */\n.restaurant-card.horizontal{grid-template-columns:142px minmax(0,1fr);min-height:144px}\n.restaurant-card.horizontal .restaurant-media{min-height:144px}\n.restaurant-media img{object-position:center center}\n.restaurant-title-row{display:flex;align-items:flex-start;gap:8px;min-width:0}\n.restaurant-title-row .restaurant-name{flex:1;min-width:0;white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.28}\n.rating.compact{flex:0 0 auto;display:inline-flex;align-items:center;gap:3px;background:var(--success-soft);padding:5px 7px;border-radius:9px;font-size:12px;line-height:1;max-width:72px}\n.restaurant-cuisines{white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.restaurant-meta{gap:6px 10px}\n.restaurant-meta>span{display:inline-flex;align-items:center;gap:4px;min-width:0}\n.chat-thread{display:flex;flex-direction:column;gap:10px;min-height:260px;max-height:55vh;overflow-y:auto}\n.chat-message{align-self:flex-start;max-width:82%;background:var(--surface-raised);border:1px solid var(--border);border-radius:16px 16px 16px 5px;padding:10px 12px;display:grid;gap:4px}\n.chat-message.mine{align-self:flex-end;background:var(--brand-soft);border-color:transparent;border-radius:16px 16px 5px 16px}\n.chat-message p{overflow-wrap:anywhere}\n@media(max-width:430px){.restaurant-card.horizontal{grid-template-columns:132px minmax(0,1fr)}.restaurant-copy{padding:14px 13px}.restaurant-meta{font-size:12px}}\n'''
if 'Savrivo operational upgrade: restaurant-card alignment' not in s:
    s+=extra
p.write_text(s)

# ---------- Restaurant/Rider chat CSS ----------
for rel in ['restaurant/src/main/assets/premium.css','rider/src/main/assets/premium.css']:
    p=root/rel;s=p.read_text()
    extra='''\n/* Private order chat */\n.chat-thread{display:flex;flex-direction:column;gap:10px;min-height:260px;max-height:55vh;overflow-y:auto}\n.chat-message{align-self:flex-start;max-width:82%;background:var(--raised);border:1px solid var(--border);border-radius:16px 16px 16px 5px;padding:10px 12px;display:grid;gap:4px}\n.chat-message.mine{align-self:flex-end;background:var(--brand-soft);border-color:transparent;border-radius:16px 16px 5px 16px}\n.chat-message p{overflow-wrap:anywhere}\n'''
    if '/* Private order chat */' not in s:s+=extra
    p.write_text(s)
print('✅ Added private-chat and restaurant-card styles')
