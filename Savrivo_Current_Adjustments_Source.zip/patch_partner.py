from pathlib import Path
p=Path('/mnt/data/savrivo_work/native_android/rider/src/main/assets/premium.js')
s=p.read_text()

# State: add draft/chat
old='const state={route:"welcome",history:[],routeData:{},session:load("savrivo.partner.session",null),profile:load("savrivo.partner.profile",{}),documents:{},location:{granted:false,enabled:false},pendingOnline:false,online:false,network:navigator.onLine,loading:false,error:"",lastSync:0,timer:null,queue:{},jobPointers:{},jobs:[],selectedJobId:"",trackingOrderId:"",sheet:null,toastTimer:null,documentDraft:{},documentFiles:{},watchers:[],syncDebounce:null,theme:localStorage.getItem("savrivo.partner.theme")||"dark"};'
new='const state={route:"welcome",history:[],routeData:{},session:load("savrivo.partner.session",null),profile:load("savrivo.partner.profile",{}),applicationDraft:load("savrivo.partner.applicationDraft",{}),documents:{},location:{granted:false,enabled:false},pendingOnline:false,online:false,network:navigator.onLine,loading:false,error:"",lastSync:0,timer:null,queue:{},jobPointers:{},jobs:[],selectedJobId:"",trackingOrderId:"",sheet:null,toastTimer:null,documentDraft:{},documentFiles:{},chat:{orderId:"",channel:"",messages:[],title:"Chat"},watchers:[],syncDebounce:null,theme:localStorage.getItem("savrivo.partner.theme")||"dark"};'
assert old in s
s=s.replace(old,new,1)

# Persist helpers and privacy/chat helpers
old='function persist(){save("savrivo.partner.profile",state.profile);state.session?save("savrivo.partner.session",state.session):localStorage.removeItem("savrivo.partner.session")}'
new='''function persist(){save("savrivo.partner.profile",state.profile);state.session?save("savrivo.partner.session",state.session):localStorage.removeItem("savrivo.partner.session")}
  function persistApplicationDraft(){save("savrivo.partner.applicationDraft",state.applicationDraft||{})}
  function draftValue(key,fallback){const d=state.applicationDraft||{};return d[key]!=null?d[key]:(fallback==null?"":fallback)}
  function captureApplicationDraft(form){if(!form)return;const fd=new FormData(form),keys=["fullName","phone","city","address","vehicleType","vehicleNumber","aadhaarLast4","panNumber"];keys.forEach(k=>{if(fd.has(k))state.applicationDraft[k]=String(fd.get(k)||"")});state.applicationDraft.verificationConsent=fd.get("verificationConsent")==="on";persistApplicationDraft()}
  function maskPhoneNumbers(value){return String(value||"").replace(/(?:\\+?91[\\s.()-]*)?[6-9](?:[\\s.()-]*\\d){9}/g,"[phone number hidden]")}
  function customerUnlocked(o){return !!(o&&["Handed to rider","Out for delivery","Near you","Arrived","Delivered"].includes(o.status))}
  function chatPath(o,channel){return ROOT+"/orderChats/"+encodeURIComponent(o.userId||o.customerId)+"/"+encodeURIComponent(o.id)+"/"+channel}
  async function openChat(o,channel,title){if(!o)return;try{const raw=await db("GET",chatPath(o,channel));state.chat={orderId:o.id,channel,messages:Object.keys(raw||{}).map(id=>Object.assign({id},raw[id]||{})).sort((a,b)=>Number(a.at||0)-Number(b.at||0)),title:title||"Order chat"};go("chat",{jobId:o.id,channel},false)}catch(e){toast("Chat could not open. "+friendly(e),"danger")}}
  async function sendChat(form){const o=job(state.chat.orderId),bodyInput=String(new FormData(form).get("message")||"").trim();if(!o||!bodyInput)return;const body=maskPhoneNumbers(bodyInput).slice(0,800),id=uid("m_").replace(/-/g,""),record={id,senderId:state.session.uid,senderRole:"rider",body,masked:body!==bodyInput,at:Date.now()};try{await db("PUT",chatPath(o,state.chat.channel)+"/"+id,record);state.chat.messages.push(record);form.reset();render({preserve:true});if(record.masked)toast("A phone number was hidden for privacy.","success")}catch(e){toast("Message could not be sent. "+friendly(e),"danger")}}
'''
assert old in s
s=s.replace(old,new,1)

# Remove email verification function and rename route resolver
old='async function emailIsVerified(){const result=await auth("accounts:lookup",{idToken:state.session.idToken}),account=result&&result.users&&result.users[0],verified=!!(account&&account.emailVerified);state.profile.emailVerified=verified;persist();return verified}\n  function routeAfterVerification(){if(state.profile.status==="approved")return"jobs";if(["submitted","under_review","rejected"].includes(state.profile.status))return"pending";return"onboarding"}'
new='function routeAfterApplication(){if(state.profile.status==="approved")return"jobs";if(["submitted","under_review","rejected"].includes(state.profile.status))return"pending";return"onboarding"}'
assert old in s
s=s.replace(old,new,1)

# syncApproved: safe pointer fallback before handover
old='''async function syncApproved(silent){if(state.profile.status!=="approved")return;try{const result=await Promise.all([db("GET",ROOT+"/dispatchQueue"),db("GET",ROOT+"/riderJobs/"+state.session.uid),db("GET",ROOT+"/riderPresence/"+state.session.uid).catch(()=>null)]);state.queue=result[0]||{};state.jobPointers=result[1]||{};state.online=!!(result[2]&&result[2].online);const pointers=Object.keys(state.jobPointers).map(id=>Object.assign({id},state.jobPointers[id]||{})),orders=await Promise.all(pointers.map(async pointer=>{try{const o=await db("GET",ROOT+"/orders/"+encodeURIComponent(pointer.customerId)+"/"+encodeURIComponent(pointer.id));return o?Object.assign({id:pointer.id,userId:pointer.customerId},o):null}catch(_){return null}}));state.jobs=orders.filter(Boolean).sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));state.lastSync=Date.now();state.error="";const current=activeJobs()[0];if(current&&["Assigned","Handed to rider","Out for delivery","Near you","Arrived"].includes(current.status))startTracking(current,current.status==="Assigned"||current.status==="Handed to rider"?"pickup":"delivery");else if(state.trackingOrderId)stopTracking()}catch(e){state.error=friendly(e);if(!silent)toast("Delivery data could not sync.","danger");throw e}finally{if(!silent)render({preserve:true})}}'''
new='''async function syncApproved(silent){if(state.profile.status!=="approved")return;try{const result=await Promise.all([db("GET",ROOT+"/dispatchQueue"),db("GET",ROOT+"/riderJobs/"+state.session.uid),db("GET",ROOT+"/riderPresence/"+state.session.uid).catch(()=>null)]);state.queue=result[0]||{};state.jobPointers=result[1]||{};state.online=!!(result[2]&&result[2].online);const pointers=Object.keys(state.jobPointers).map(id=>Object.assign({id},state.jobPointers[id]||{})),orders=await Promise.all(pointers.map(async pointer=>{try{const o=await db("GET",ROOT+"/orders/"+encodeURIComponent(pointer.customerId)+"/"+encodeURIComponent(pointer.id));if(o)return Object.assign({id:pointer.id,userId:pointer.customerId},o)}catch(_){}return Object.assign({id:pointer.id,userId:pointer.customerId,status:pointer.orderStatus||"Assigned",restaurantId:pointer.restaurantId||"",restaurant:pointer.restaurantName||"Restaurant",restaurantLocation:{address:pointer.restaurantAddress||"",lat:pointer.restaurantLat,lng:pointer.restaurantLng},approximateDropZone:pointer.approximateDropZone||"Service area",riderPayout:Number(pointer.payout||0),pricing:{deliveryFee:Number(pointer.payout||0),tip:0},createdAt:pointer.assignedAt||pointer.createdAt||Date.now(),updatedAt:pointer.updatedAt||pointer.assignedAt||Date.now()},pointer)}));state.jobs=orders.filter(Boolean).sort((a,b)=>Number(b.createdAt||0)-Number(a.createdAt||0));state.lastSync=Date.now();state.error="";const current=activeJobs()[0];if(current&&["Assigned","Handed to rider","Out for delivery","Near you","Arrived"].includes(current.status))startTracking(current,current.status==="Assigned"||current.status==="Handed to rider"?"pickup":"delivery");else if(state.trackingOrderId)stopTracking()}catch(e){state.error=friendly(e);if(!silent)toast("Delivery data could not sync.","danger");throw e}finally{if(!silent)render({preserve:true})}}'''
assert old in s
s=s.replace(old,new,1)

# Enrich rider job pointer on claim
old='changes["riderJobs/"+state.session.uid+"/"+id]={orderId:id,customerId:offer.customerId,restaurantId:offer.restaurantId||"",assignedAt:now,status:"active",phase:"pickup"};'
new='changes["riderJobs/"+state.session.uid+"/"+id]={orderId:id,customerId:offer.customerId,restaurantId:offer.restaurantId||"",restaurantName:offer.restaurantName||"Restaurant",restaurantAddress:offer.restaurantAddress||"",restaurantLat:offer.restaurantLat==null?null:Number(offer.restaurantLat),restaurantLng:offer.restaurantLng==null?null:Number(offer.restaurantLng),approximateDropZone:offer.approximateDropZone||"Service area",itemCount:Number(offer.itemCount||0),payout:Number(offer.payout||0),estimatedMinutes:Number(offer.estimatedMinutes||30),assignedAt:now,updatedAt:now,orderStatus:"Assigned",status:"active",phase:"pickup"};'
assert old in s
s=s.replace(old,new,1)

# Update pointer orderStatus on rider status transitions
old='changes["riderJobs/"+state.session.uid+"/"+o.id+"/updatedAt"]=now;try{await db("PATCH",ROOT,changes);'
new='changes["riderJobs/"+state.session.uid+"/"+o.id+"/updatedAt"]=now;changes["riderJobs/"+state.session.uid+"/"+o.id+"/orderStatus"]=status;try{await db("PATCH",ROOT,changes);'
assert old in s
s=s.replace(old,new,1)

# New onboarding screen, preserving draft
start=s.index('  function screenOnboarding()')
end=s.index('\n  function screenPending()',start)
new_func='''  function screenOnboarding(){const d=state.applicationDraft||{},v=(k,f)=>h(draftValue(k,f));return'<main class="screen no-nav"><div class="content page">'+top("Partner application","Your progress is saved on this device while you choose documents.")+'<div class="stepper"><span class="step-dot done"></span><span class="step-dot done"></span><span class="step-dot"></span></div><div class="notice warning">'+icon("shield","small")+'<span>Upload only a masked Aadhaar copy. Hide the first 8 digits. Choosing a document will not clear the details you already entered.</span></div><form id="onboarding-form" class="stack-lg"><section class="card form-grid"><h2 class="section-title">Contact and city</h2><div class="field"><label>Full name</label><input class="input" name="fullName" value="'+v("fullName",state.profile.fullName||"")+'" required></div><div class="field"><label>Mobile number</label><input class="input" name="phone" type="tel" inputmode="tel" value="'+v("phone",state.profile.phone||"")+'" required></div><div class="field"><label>Operating city</label><input class="input" name="city" value="'+v("city",state.profile.city||"")+'" required></div><div class="field"><label>Residential address</label><textarea class="textarea" name="address" required>'+v("address",state.profile.address||"")+'</textarea></div></section><section class="card form-grid"><h2 class="section-title">Vehicle</h2><div class="field"><label>Vehicle type</label><select class="select" name="vehicleType">'+["Motorcycle","Scooter","Electric two-wheeler","Bicycle"].map(x=>'<option '+(draftValue("vehicleType",state.profile.vehicleType||"Motorcycle")===x?'selected':'')+'>'+h(x)+'</option>').join("")+'</select></div><div class="field"><label>Vehicle registration</label><input class="input" name="vehicleNumber" value="'+v("vehicleNumber",state.profile.vehicleNumber||"")+'" placeholder="AP 00 AB 0000" required></div></section><section class="card form-grid"><h2 class="section-title">Identity details</h2><div class="field"><label>Last 4 digits of Aadhaar</label><input class="input" name="aadhaarLast4" inputmode="numeric" maxlength="4" value="'+v("aadhaarLast4",state.profile.aadhaarLast4||"")+'" required></div><div class="field"><label>PAN number</label><input class="input" name="panNumber" maxlength="10" value="'+v("panNumber",state.profile.panNumber||"")+'" required></div></section>'+docCard("aadhaarFront","Aadhaar — front","Masked copy; first 8 digits hidden")+docCard("aadhaarBack","Aadhaar — back","Address side of the masked copy")+docCard("panCopy","PAN card copy","Clear image for owner verification")+'<label class="notice info"><input type="checkbox" name="verificationConsent" '+(d.verificationConsent?'checked':'')+' required><span>I confirm these documents belong to me, the Aadhaar copy is masked and I consent to verification.</span></label><button class="button primary full" type="submit">Submit for secure review</button></form></div></main>'}'''
s=s[:start]+new_func+s[end:]

# Replace job detail with privacy-aware version
start=s.index('  function screenJobDetail(){')
end=s.index('\n  function deliveryEarning',start)
new_func='''  function screenJobDetail(){
    const o=job();if(!o)return screenActive();
    const unlocked=customerUnlocked(o),address=unlocked?(o.address||{}):{},restaurantLoc=o.restaurantLocation||{},lat=unlocked?Number(address.lat):Number(restaurantLoc.lat),lng=unlocked?Number(address.lng):Number(restaurantLoc.lng),map=tile(lat,lng,15);
    let html='<main class="screen"><div class="content page">'+top("Delivery "+o.id,o.restaurant||"Active job",'<span class="status">'+h(o.status)+'</span>')+banner()+health();
    html+='<section class="card hero stack"><div class="cluster between"><span class="status" style="background:rgba(255,255,255,.16);color:white">'+h(o.status)+'</span><strong>'+money(partnerEarning(o))+' payout</strong></div><h1 class="title">'+(unlocked?'Deliver to '+h(o.customerName||"the customer"):'Head to '+h(o.restaurant||"the restaurant"))+'</h1><p class="supporting" style="color:rgba(255,255,255,.82)">Last updated '+h(ago(o.updatedAt||o.createdAt))+'</p></section>'+workflowAction(o);
    html+='<section class="card stack"><h2 class="section-title">Pickup and drop</h2><div class="job-route"><div class="route-dots"><span></span><i></i><span></span></div><div class="stack"><div><strong>'+h(o.restaurant||"Restaurant")+'</strong><p class="supporting">'+h(restaurantLoc.address||o.restaurantAddress||"Restaurant address unavailable")+'</p></div><div><strong>'+(unlocked?h(o.customerName||"Customer"):"Customer details protected")+'</strong><p class="supporting">'+(unlocked?h(address.address||address.details||"Delivery address unavailable"):h(o.approximateDropZone||"Exact address unlocks after restaurant handover"))+'</p></div></div></div></section>';
    html+='<section class="card stack"><div><h2 class="section-title">Communication</h2><p class="supporting">Real mobile numbers are not displayed. Chat automatically hides phone numbers typed in messages.</p></div><div class="cluster wrap"><button class="button tonal grow" data-action="open-chat" data-channel="restaurantRider" data-job-id="'+h(o.id)+'">Chat restaurant</button>'+(unlocked?'<button class="button tonal grow" data-action="open-chat" data-channel="customerRider" data-job-id="'+h(o.id)+'">Chat customer</button>':'')+(unlocked&&o.contactProxy&&o.contactProxy.riderToCustomer?'<a class="button secondary grow" href="tel:'+h(o.contactProxy.riderToCustomer)+'">Secure call customer</a>':'')+'</div>'+(unlocked&&o.instructions?'<div class="notice info">'+icon("help","small")+'<span>'+h(o.instructions)+'</span></div>':'')+'</section>';
    html+='<section class="card map"><div class="map-canvas" '+(map?'style="background-image:url('+h(map)+')"':'')+'></div><div class="map-overlay"><div class="cluster between"><div><strong>'+(unlocked?'Delivery location':'Restaurant pickup')+'</strong><p class="caption">Location-only map · © OpenStreetMap contributors</p></div><button class="button secondary small" data-action="'+(unlocked?'navigate-customer':'navigate-restaurant')+'" data-job-id="'+h(o.id)+'">Open route</button></div></div></section>';
    html+='<section class="card stack"><h2 class="section-title">Order and payment</h2><div class="price-row"><span>Package</span><strong>'+h((o.items||[]).length||o.itemCount||0)+' items</strong></div>'+(unlocked?'<div class="price-row"><span>Customer total</span><strong>'+money(o.total)+'</strong></div><div class="price-row"><span>Payment</span><strong>'+h(o.paymentMethod==="cod"?"Cash on delivery":o.paymentMethod||"Unknown")+'</strong></div>':'<div class="notice info">'+icon("shield","small")+'<span>Customer address, contact and payment details unlock after confirmed restaurant handover.</span></div>')+'</section></div>'+nav()+'</main>';
    return html;
  }
  function screenChat(){const o=job(state.chat.orderId),messages=state.chat.messages||[];if(!o)return screenActive();return'<main class="screen"><div class="content page">'+top(state.chat.title||"Order chat","Order "+o.id)+'<div class="notice info">'+icon("shield","small")+'<span>Phone numbers are automatically hidden. Use Savrivo secure calling when a temporary proxy number is available.</span></div><section class="card chat-thread">'+(messages.length?messages.map(m=>'<div class="chat-message '+(m.senderId===state.session.uid?'mine':'')+'"><strong>'+h(m.senderRole||"user")+'</strong><p>'+h(m.body||"")+'</p><span class="caption">'+h(dateTime(m.at))+'</span></div>').join(""):empty("help","No messages yet","Use chat for pickup or delivery coordination."))+'</section><form id="chat-form" class="card cluster"><input class="input grow" name="message" maxlength="800" placeholder="Type a message" autocomplete="off" required><button class="button primary" type="submit">Send</button></form></div>'+nav()+'</main>'}'''
s=s[:start]+new_func+s[end:]

# SCREENS remove verify add chat
old='Object.assign(SCREENS,{welcome:screenWelcome,login:screenLogin,signup:screenSignup,verify:screenVerify,onboarding:screenOnboarding,pending:screenPending,jobs:screenJobs,active:screenActive,jobDetail:screenJobDetail,earnings:screenEarnings,history:screenHistory,account:screenAccount,support:screenSupport});'
new='Object.assign(SCREENS,{welcome:screenWelcome,login:screenLogin,signup:screenSignup,onboarding:screenOnboarding,pending:screenPending,jobs:screenJobs,active:screenActive,jobDetail:screenJobDetail,chat:screenChat,earnings:screenEarnings,history:screenHistory,account:screenAccount,support:screenSupport});'
assert old in s
s=s.replace(old,new,1)

# handle click: chat actions
needle='if(a==="open-job"){go("jobDetail",{jobId:c.dataset.jobId});return}'
rep=needle+'if(a==="open-chat"){const o=job(c.dataset.jobId);if(o)openChat(o,c.dataset.channel,c.dataset.channel==="customerRider"?"Chat with customer":"Chat with restaurant");return}'
assert needle in s
s=s.replace(needle,rep,1)

# Remove verification click handler registration and function block
start=s.index('  async function handleVerificationClick')
end=s.index('\n  function compress',start)
s=s[:start]+'  app.addEventListener("click",handleClick);sheetRegion.addEventListener("click",handleClick);\n'+s[end:]

# document change: capture draft before file flow
old='document.addEventListener("change",async event=>{const input=event.target.closest(".document-input");if(!input)return;const file=input.files&&input.files[0],key=input.dataset.document;if(!file)return;try{const data=await compress(file);'
new='document.addEventListener("change",async event=>{const input=event.target.closest(".document-input");if(!input)return;captureApplicationDraft(document.getElementById("onboarding-form"));const file=input.files&&input.files[0],key=input.dataset.document;if(!file)return;try{const data=await compress(file);'
assert old in s
s=s.replace(old,new,1)

# Remove verification submit intercept line
old='  document.addEventListener("submit",event=>{if(event.target&&event.target.id==="onboarding-form"&&state.profile.emailVerified!==true){event.preventDefault();event.stopImmediatePropagation();state.route="verify";render();toast("Verify your email before submitting identity documents.","danger")}},true);\n\n'
assert old in s
s=s.replace(old,'',1)

# Login without verification
old='async function login(form){const email=form.elements.email.value.trim().toLowerCase(),password=form.elements.password.value;if(!/^\\S+@\\S+\\.\\S+$/.test(email)||!password){toast("Enter your email and password.","danger");return}state.loading=true;render({preserve:true});try{const d=await auth("accounts:signInWithPassword",{email,password,returnSecureToken:true});setAuth(d,email);await syncProfile();if(!(await emailIsVerified()))state.route="verify";else{state.route=routeAfterVerification();if(state.profile.status==="approved"){requestLocation(false);await syncApproved(true);startPoll()}}state.history=[];toast("Signed in securely.","success")}catch(e){state.session=null;persist();toast(friendly(e),"danger")}finally{state.loading=false;render()}}'
new='async function login(form){const email=form.elements.email.value.trim().toLowerCase(),password=form.elements.password.value;if(!/^\\S+@\\S+\\.\\S+$/.test(email)||!password){toast("Enter your email and password.","danger");return}state.loading=true;render({preserve:true});try{const d=await auth("accounts:signInWithPassword",{email,password,returnSecureToken:true});setAuth(d,email);await syncProfile();state.route=routeAfterApplication();if(state.profile.status==="approved"){requestLocation(false);await syncApproved(true);startPoll()}state.history=[];toast("Signed in securely.","success")}catch(e){state.session=null;persist();toast(friendly(e),"danger")}finally{state.loading=false;render()}}'
assert old in s
s=s.replace(old,new,1)

# Signup no verification
old='async function signup(form){const fd=new FormData(form),name=String(fd.get("name")||"").trim(),email=String(fd.get("email")||"").trim().toLowerCase(),phone=String(fd.get("phone")||"").trim(),password=String(fd.get("password")||""),confirm=String(fd.get("confirm")||"");if(name.length<2||!/^\\S+@\\S+\\.\\S+$/.test(email)||phone.replace(/\\D/g,"").length<10||password.length<8||!/[A-Za-z]/.test(password)||!/\\d/.test(password)||password!==confirm||fd.get("consent")!=="on"){toast("Complete all fields, use a strong matching password and accept the application terms.","danger");return}state.loading=true;render({preserve:true});try{const d=await auth("accounts:signUp",{email,password,returnSecureToken:true});setAuth(d,email);state.profile={fullName:name,email,phone,status:"draft",emailVerified:false,createdAt:Date.now(),updatedAt:Date.now()};persist();await auth("accounts:sendOobCode",{requestType:"VERIFY_EMAIL",idToken:state.session.idToken}).catch(()=>null);state.route="verify";state.history=[];toast("Account created. Verify your email to continue.","success")}catch(e){toast(friendly(e),"danger")}finally{state.loading=false;render()}}'
new='async function signup(form){const fd=new FormData(form),name=String(fd.get("name")||"").trim(),email=String(fd.get("email")||"").trim().toLowerCase(),phone=String(fd.get("phone")||"").trim(),password=String(fd.get("password")||""),confirm=String(fd.get("confirm")||"");if(name.length<2||!/^\\S+@\\S+\\.\\S+$/.test(email)||phone.replace(/\\D/g,"").length<10||password.length<8||!/[A-Za-z]/.test(password)||!/\\d/.test(password)||password!==confirm||fd.get("consent")!=="on"){toast("Complete all fields, use a strong matching password and accept the application terms.","danger");return}state.loading=true;render({preserve:true});try{const d=await auth("accounts:signUp",{email,password,returnSecureToken:true});setAuth(d,email);state.profile={fullName:name,email,phone,status:"draft",createdAt:Date.now(),updatedAt:Date.now()};state.applicationDraft={fullName:name,phone};persistApplicationDraft();persist();state.route="onboarding";state.history=[];toast("Account created. Complete your partner application.","success")}catch(e){toast(friendly(e),"danger")}finally{state.loading=false;render()}}'
assert old in s
s=s.replace(old,new,1)

# submitOnboarding clear draft on success; capture before validation
old='async function submitOnboarding(form){const fd=new FormData(form),fullName='
new='async function submitOnboarding(form){captureApplicationDraft(form);const fd=new FormData(form),fullName='
assert old in s
s=s.replace(old,new,1)
old='state.profile=record;state.documentDraft={};state.documentFiles={};persist();state.route="pending";'
new='state.profile=record;state.documentDraft={};state.documentFiles={};state.applicationDraft={};localStorage.removeItem("savrivo.partner.applicationDraft");persist();state.route="pending";'
assert old in s
s=s.replace(old,new,1)

# submit listener add chat
old='else if(form.id==="support-form")submitSupport(form);else if(form.id==="complete-form")'
new='else if(form.id==="support-form")submitSupport(form);else if(form.id==="chat-form")sendChat(form);else if(form.id==="complete-form")'
assert old in s
s=s.replace(old,new,1)

# Bootstrap no verification
old='async function bootstrap(){applyTheme();if(!localStorage.getItem("savrivo.partner.seen")){state.route="welcome";render();app.setAttribute("aria-busy","false");return}if(!state.session){state.route="login";render();app.setAttribute("aria-busy","false");return}state.loading=true;render();try{await ensure();await syncProfile();if(!(await emailIsVerified()))state.route="verify";else if(state.profile.status==="approved"){state.route="jobs";requestLocation(false);await syncApproved(true);startPoll()}else if(["submitted","under_review","rejected"].includes(state.profile.status))state.route="pending";else state.route="onboarding"}catch(e){state.session=null;persist();state.route="login";toast("Your session expired. Sign in again.","danger")}finally{state.loading=false;app.setAttribute("aria-busy","false");render()}}'
new='async function bootstrap(){applyTheme();if(!localStorage.getItem("savrivo.partner.seen")){state.route="welcome";render();app.setAttribute("aria-busy","false");return}if(!state.session){state.route="login";render();app.setAttribute("aria-busy","false");return}state.loading=true;render();try{await ensure();await syncProfile();if(state.profile.status==="approved"){state.route="jobs";requestLocation(false);await syncApproved(true);startPoll()}else if(["submitted","under_review","rejected"].includes(state.profile.status))state.route="pending";else state.route="onboarding"}catch(e){state.session=null;persist();state.route="login";toast("Your session expired. Sign in again.","danger")}finally{state.loading=false;app.setAttribute("aria-busy","false");render()}}'
assert old in s
s=s.replace(old,new,1)

# Input autosave and safe visibility sync
old='const originalGo=go;go=function(route,data,replace){if(route==="signup"||route==="login")localStorage.setItem("savrivo.partner.seen","1");return originalGo(route,data,replace)};\n  window.addEventListener("online",()=>{state.network=true;if(state.session&&state.profile.status==="approved")refresh();else render({preserve:true})});window.addEventListener("offline",()=>{state.network=false;if(state.online)setOnline(false);render({preserve:true})});document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"&&state.session&&state.network){requestLocation(false);syncProfile().then(()=>syncApproved(true)).then(()=>render({preserve:true})).catch(()=>{})}});'
new='''const originalGo=go;go=function(route,data,replace){if(route==="signup"||route==="login")localStorage.setItem("savrivo.partner.seen","1");return originalGo(route,data,replace)};
  document.addEventListener("input",event=>{const form=event.target&&event.target.closest&&event.target.closest("#onboarding-form");if(form)captureApplicationDraft(form)});
  document.addEventListener("change",event=>{const form=event.target&&event.target.closest&&event.target.closest("#onboarding-form");if(form&&!event.target.classList.contains("document-input"))captureApplicationDraft(form)});
  window.addEventListener("online",()=>{state.network=true;if(state.session&&state.profile.status==="approved")refresh();else render({preserve:true})});window.addEventListener("offline",()=>{state.network=false;if(state.online)setOnline(false);render({preserve:true})});document.addEventListener("visibilitychange",()=>{if(document.visibilityState==="visible"&&state.session&&state.network){captureApplicationDraft(document.getElementById("onboarding-form"));requestLocation(false);syncProfile().then(()=>state.profile.status==="approved"?syncApproved(true):null).then(()=>render({preserve:true})).catch(()=>{})}});'''
assert old in s
s=s.replace(old,new,1)

p.write_text(s)
print('partner patched')
