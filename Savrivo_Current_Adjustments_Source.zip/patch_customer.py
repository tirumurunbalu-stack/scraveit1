from pathlib import Path
p=Path('/mnt/data/savrivo_work/native_android/app/src/main/assets/premium.js')
s=p.read_text()

# State defaults & chat/dynamic pricing
old='promotions: [], settings: {platformFee:12, taxRate:0, freeDeliveryAbove:0, baseDeliveryFee:20, includedDeliveryKm:2, perKmFee:8, minDeliveryFee:20, maxDeliveryFee:100, maxDeliveryKm:15},'
new='promotions: [], settings: {platformFee:15, taxRate:0, freeDeliveryAbove:0, maxDeliveryKm:15, deliverySlabs:{"0":{maxKm:2,fee:29},"1":{maxKm:4,fee:39},"2":{maxKm:6,fee:59},"3":{maxKm:8,fee:79},"4":{maxKm:10,fee:99},"5":{maxKm:12,fee:119},"6":{maxKm:15,fee:139}}, platformFeeOverrides:{cities:{},categories:{},restaurants:{},orderValueRules:{}}, rainFeeEnabled:true,rainLightFee:9,rainModerateFee:19,rainHeavyFee:29,rainSevereFee:39,rainMinProbability:35,rainLightMm:0.1,rainModerateMm:1,rainHeavyMm:4,rainSevereMm:10,surgeEnabled:true,surgeLowOrders:4,surgeMediumOrders:8,surgeHighOrders:12,surgeLowFee:9,surgeMediumFee:19,surgeHighFee:29,maxSurgeFee:39,smallOrderFeeEnabled:true,smallOrderThreshold:149,smallOrderFee:19,lateNightFeeEnabled:true,lateNightStartHour:23,lateNightEndHour:5,lateNightFee:19},'
assert old in s;s=s.replace(old,new,1)
old='sheet: null, toastTimer: null, timers: [], watchers: [], trackingWatchers: {}, syncDebounce: null, locationBusy: false,'
new='sheet: null, toastTimer: null, timers: [], watchers: [], trackingWatchers: {}, syncDebounce: null, locationBusy: false, dynamicPricing:{rainFee:0,surgeFee:0,weatherSeverity:"",weatherChecked:false,activeOrders:0,checkedAt:0}, chat:{orderId:"",channel:"",messages:[],title:"Chat"},'
assert old in s;s=s.replace(old,new,1)

# Replace delivery/platform/order pricing block
start=s.index('  function deliveryFeeForRestaurant(r,subtotal) {')
end=s.index('\n\n  function addCartItem',start)
new_block='''  function keyName(value){return String(value||"").trim().toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,"")}
  function deliverySlabs(){const raw=state.settings.deliverySlabs||{};const list=Array.isArray(raw)?raw:Object.keys(raw).sort((a,b)=>Number(a)-Number(b)).map(k=>raw[k]);return (list||[]).filter(x=>x&&Number.isFinite(Number(x.maxKm))&&Number.isFinite(Number(x.fee))).sort((a,b)=>Number(a.maxKm)-Number(b.maxKm))}
  function deliveryFeeForRestaurant(r,subtotal){if(!r)return 0;const threshold=Number(state.settings.freeDeliveryAbove||0);if(threshold>0&&Number(subtotal||0)>=threshold)return 0;const d=restaurantDistanceKm(r);if(d==null)return Number(state.settings.fallbackDeliveryFee||29);const slabs=deliverySlabs();for(const slab of slabs)if(d<=Number(slab.maxKm))return Math.max(0,Number(slab.fee||0));return Math.max(0,Number(slabs.length?slabs[slabs.length-1].fee:139))}
  function hasPinnedAddress(){return(state.profile.addresses||[]).some(address=>Number.isFinite(Number(address.lat))&&Number.isFinite(Number(address.lng)));}
  function offerAutomaticLocation(){if(!hasPinnedAddress()&&!state.locationBusy)setTimeout(()=>{if(state.session&&!hasPinnedAddress())requestLocation();},450);}
  function clampLat(lat){return Math.max(-85.05112878,Math.min(85.05112878,Number(lat)||0));}
  function mapWorld(lat,lng,zoom){const size=256*Math.pow(2,zoom),x=(Number(lng)+180)/360*size,rad=clampLat(lat)*Math.PI/180,y=(1-Math.log(Math.tan(rad)+1/Math.cos(rad))/Math.PI)/2*size;return{x,y,size};}
  function worldToLatLng(x,y,zoom){const size=256*Math.pow(2,zoom),lng=x/size*360-180,n=Math.PI-2*Math.PI*y/size,lat=180/Math.PI*Math.atan(Math.sinh(n));return{lat:clampLat(lat),lng:Math.max(-180,Math.min(180,lng))};}
  function openAddressSheet(address){
    const source=address||{},fallback=currentAddress()||{};
    const lat=Number.isFinite(Number(source.lat))?Number(source.lat):(Number.isFinite(Number(fallback.lat))?Number(fallback.lat):14.9077);
    const lng=Number.isFinite(Number(source.lng))?Number(source.lng):(Number.isFinite(Number(fallback.lng))?Number(fallback.lng):79.8946);
    state.addressMapDraft={lat,lng};state.addressMapZoom=16;setSheet({type:"address",address:clone(source)});
  }
  function addressMapMarkup(){
    const point=state.addressMapDraft||{lat:14.9077,lng:79.8946},zoom=Math.max(12,Math.min(18,Number(state.addressMapZoom)||16)),world=mapWorld(point.lat,point.lng,zoom),tileX=Math.floor(world.x/256),tileY=Math.floor(world.y/256),max=Math.pow(2,zoom),tiles=[];
    for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){let tx=(tileX+dx)%max;if(tx<0)tx+=max;const ty=Math.max(0,Math.min(max-1,tileY+dy)),left=(tileX+dx)*256-world.x,top=(tileY+dy)*256-world.y;tiles.push('<img alt="" aria-hidden="true" src="https://tile.openstreetmap.org/'+zoom+'/'+tx+'/'+ty+'.png" style="position:absolute;width:256px;height:256px;left:calc(50% + '+left.toFixed(1)+'px);top:calc(50% + '+top.toFixed(1)+'px);max-width:none">');}
    return '<div class="stack"><div class="cluster between"><div><strong>Delivery pin</strong><div class="caption">Tap the map to move the pin. Use phone location for your exact position.</div></div><div class="cluster"><button type="button" class="icon-button" data-action="address-map-zoom" data-delta="-1" aria-label="Zoom out">−</button><button type="button" class="icon-button" data-action="address-map-zoom" data-delta="1" aria-label="Zoom in">+</button></div></div><div data-action="address-map-pick" class="map-picker" role="button" tabindex="0" aria-label="Choose delivery location on map" style="height:250px;position:relative;overflow:hidden;border-radius:18px;border:1px solid var(--border);background:#dce7ef;touch-action:manipulation">'+tiles.join("")+'<div style="position:absolute;left:50%;top:50%;transform:translate(-50%,-100%);font-size:34px;filter:drop-shadow(0 3px 4px rgba(0,0,0,.35));pointer-events:none">📍</div></div><div class="cluster wrap"><button type="button" class="button tonal grow" data-action="detect-address-location">'+icon("target","small")+' Use phone location</button><span class="caption">'+point.lat.toFixed(5)+', '+point.lng.toFixed(5)+'</span></div></div>';
  }
  function restaurant(id){return state.catalog[id||state.selectedRestaurantId]||null;}
  function menuItem(rid,iid){const r=restaurant(rid);return r&&r.menu.find(x=>x.id===iid);}
  function cartCount(){return state.cart.reduce((sum,item)=>sum+Number(item.quantity||0),0);}
  function cartRestaurant(){return state.cart.length?restaurant(state.cart[0].restaurantId):null;}
  function cartSubtotal(){return state.cart.reduce((sum,item)=>sum+(Number(item.price)+Number(item.variantPrice||0)+Number(item.addOnTotal||0))*Number(item.quantity||0),0);}
  function deliveryFee(){return deliveryFeeForRestaurant(cartRestaurant(),cartSubtotal());}
  function platformFeeDetails(){const r=cartRestaurant(),base=Number(state.settings.platformFee||15),over=state.settings.platformFeeOverrides||{},subtotal=cartSubtotal(),rid=keyName(r&&r.id),city=keyName(r&&r.city||currentAddress()&&currentAddress().city||currentAddress()&&currentAddress().area),category=keyName(r&&r.category||r&&r.type||(r&&r.cuisines||[])[0]);if(over.restaurants&&over.restaurants[rid]!=null)return{fee:Number(over.restaurants[rid]),rule:"Restaurant override"};const rules=over.orderValueRules||{};for(const k of Object.keys(rules)){const rule=rules[k]||{},min=Number(rule.min||0),max=rule.max==null?Infinity:Number(rule.max);if(subtotal>=min&&subtotal<=max&&Number.isFinite(Number(rule.fee)))return{fee:Number(rule.fee),rule:"Order value override"}}if(over.categories&&over.categories[category]!=null)return{fee:Number(over.categories[category]),rule:"Category override"};if(over.cities&&over.cities[city]!=null)return{fee:Number(over.cities[city]),rule:"City override"};return{fee:base,rule:"Global default"}}
  function platformFee(){return Math.max(0,platformFeeDetails().fee);}
  function eligibleCoupon(){if(!state.coupon||!state.cart.length||state.coupon.active!==true)return null;if(state.coupon.expiresAt&&Date.now()>Number(state.coupon.expiresAt))return null;if(state.coupon.minimumOrder&&cartSubtotal()<Number(state.coupon.minimumOrder))return null;if(Array.isArray(state.coupon.restaurantIds)&&!state.coupon.restaurantIds.includes(state.cart[0].restaurantId))return null;return state.coupon;}
  function discount(){const coupon=eligibleCoupon();return coupon?Math.min(Number(coupon.maxDiscount||99999),cartSubtotal()*Number(coupon.percent||0)/100):0;}
  function tax(){return Math.max(0,(cartSubtotal()-discount())*Number(state.settings.taxRate||0)/100);}
  function smallOrderFee(){return state.settings.smallOrderFeeEnabled===true&&cartSubtotal()>0&&cartSubtotal()<Number(state.settings.smallOrderThreshold||149)?Math.max(0,Number(state.settings.smallOrderFee||19)):0;}
  function lateNightFee(){if(state.settings.lateNightFeeEnabled!==true)return 0;const hNow=new Date().getHours(),start=Number(state.settings.lateNightStartHour==null?23:state.settings.lateNightStartHour),end=Number(state.settings.lateNightEndHour==null?5:state.settings.lateNightEndHour),active=start>end?(hNow>=start||hNow<end):(hNow>=start&&hNow<end);return active?Math.max(0,Number(state.settings.lateNightFee||19)):0;}
  function rainFee(){return Math.max(0,Number(state.dynamicPricing&&state.dynamicPricing.rainFee||0));}
  function surgeFee(){return Math.max(0,Number(state.dynamicPricing&&state.dynamicPricing.surgeFee||0));}
  function orderTotal(){return Math.max(0,cartSubtotal()+deliveryFee()+platformFee()+smallOrderFee()+lateNightFee()+rainFee()+surgeFee()+Number(state.tip||0)+tax()-discount());}
  function weatherSeverity(result){const p=result&&result.precipitation||{},qpf=Number(p.qpf&&p.qpf.quantity||0),prob=Number(p.probability&&p.probability.percent||0),storm=Number(result&&result.thunderstormProbability||0),type=String(result&&result.weatherCondition&&result.weatherCondition.type||"").toUpperCase(),s=state.settings;if(storm>=30||type.includes("THUNDERSTORM")||qpf>=Number(s.rainSevereMm||10))return{level:"severe",mm:qpf,prob};if(qpf>=Number(s.rainHeavyMm||4))return{level:"heavy",mm:qpf,prob};if(qpf>=Number(s.rainModerateMm||1))return{level:"moderate",mm:qpf,prob};if(qpf>=Number(s.rainLightMm||0.1)&&prob>=Number(s.rainMinProbability||35))return{level:"light",mm:qpf,prob};return{level:"",mm:qpf,prob};}
  async function googleWeather(lat,lng){const key=CONFIG.googleWeatherApiKey||CONFIG.weatherApiKey||CONFIG.apiKey;if(!key)throw new Error("WEATHER_KEY_MISSING");const url="https://weather.googleapis.com/v1/currentConditions:lookup?key="+encodeURIComponent(key)+"&location.latitude="+encodeURIComponent(lat)+"&location.longitude="+encodeURIComponent(lng)+"&unitsSystem=METRIC";return request(url,{method:"GET"},9000);}
  async function refreshDynamicPricing(){const r=cartRestaurant(),a=currentAddress(),next={rainFee:0,surgeFee:0,weatherSeverity:"",weatherChecked:false,activeOrders:0,checkedAt:Date.now()};if(!r||!a){state.dynamicPricing=next;return next}if(state.settings.rainFeeEnabled===true&&Number.isFinite(Number(a.lat))&&Number.isFinite(Number(a.lng))&&Number.isFinite(Number(r.lat))&&Number.isFinite(Number(r.lng))){try{const points=[[Number(a.lat),Number(a.lng)],[Number(r.lat),Number(r.lng)],[(Number(a.lat)+Number(r.lat))/2,(Number(a.lng)+Number(r.lng))/2]],weather=await Promise.all(points.map(x=>googleWeather(x[0],x[1]))),rank={"":0,light:1,moderate:2,heavy:3,severe:4};let worst={level:"",mm:0,prob:0};weather.map(weatherSeverity).forEach(x=>{if(rank[x.level]>rank[worst.level])worst=x});next.weatherChecked=true;next.weatherSeverity=worst.level;if(worst.level){const city=keyName(r.city||a.city||a.area),cityOverride=state.settings.rainCityOverrides&&state.settings.rainCityOverrides[city]||{},feeMap={light:Number(cityOverride.light!=null?cityOverride.light:state.settings.rainLightFee||9),moderate:Number(cityOverride.moderate!=null?cityOverride.moderate:state.settings.rainModerateFee||19),heavy:Number(cityOverride.heavy!=null?cityOverride.heavy:state.settings.rainHeavyFee||29),severe:Number(cityOverride.severe!=null?cityOverride.severe:state.settings.rainSevereFee||39)};next.rainFee=Math.max(0,Number(feeMap[worst.level]||0))}}catch(_){next.rainFee=0;next.weatherChecked=false}}if(state.settings.surgeEnabled===true){try{const load=await db("GET",DB_ROOT+"/restaurantLoad/"+encodeURIComponent(r.id)),fresh=load&&Date.now()-Number(load.updatedAt||0)<180000;if(fresh){const active=Math.max(0,Number(load.activeOrders||0));next.activeOrders=active;const low=Number(state.settings.surgeLowOrders||4),mid=Number(state.settings.surgeMediumOrders||8),high=Number(state.settings.surgeHighOrders||12),cap=Number(state.settings.maxSurgeFee||39);let fee=active>=high?Number(state.settings.surgeHighFee||29):active>=mid?Number(state.settings.surgeMediumFee||19):active>=low?Number(state.settings.surgeLowFee||9):0;const city=keyName(r.city||a.city||a.area),over=state.settings.surgeCityOverrides&&state.settings.surgeCityOverrides[city];if(over&&fee>0){fee=active>=high?Number(over.high!=null?over.high:fee):active>=mid?Number(over.medium!=null?over.medium:fee):Number(over.low!=null?over.low:fee)}next.surgeFee=Math.max(0,Math.min(cap,fee))}}catch(_){next.surgeFee=0}}state.dynamicPricing=next;return next;}
  function maskPhoneNumbers(value){return String(value||"").replace(/(?:\\+?91[\\s.()-]*)?[6-9](?:[\\s.()-]*\\d){9}/g,"[phone number hidden]")}
  function chatPath(o,channel){return DB_ROOT+"/orderChats/"+encodeURIComponent(state.session.uid)+"/"+encodeURIComponent(o.id)+"/"+channel}
  async function openOrderChat(o,channel,title){if(!o)return;try{const raw=await db("GET",chatPath(o,channel));state.chat={orderId:o.id,channel,messages:Object.keys(raw||{}).map(id=>Object.assign({id},raw[id]||{})).sort((a,b)=>Number(a.at||0)-Number(b.at||0)),title:title||"Order chat"};go("chat",{orderId:o.id,channel})}catch(e){toast("Chat could not open. "+friendlyError(e),"danger")}}
  async function sendOrderChat(form){const o=state.orders.find(x=>x.id===state.chat.orderId),original=String(new FormData(form).get("message")||"").trim();if(!o||!original)return;const body=maskPhoneNumbers(original).slice(0,800),id=uid("m_").replace(/-/g,""),record={id,senderId:state.session.uid,senderRole:"customer",body,masked:body!==original,at:Date.now()};try{await db("PUT",chatPath(o,state.chat.channel)+"/"+id,record);state.chat.messages.push(record);form.reset();render({preserveScroll:true});if(record.masked)toast("A phone number was hidden for privacy.","success")}catch(e){toast("Message could not be sent. "+friendlyError(e),"danger")}}
'''
s=s[:start]+new_block+s[end:]

# Fix restaurant card markup
start=s.index('  function restaurantCard(r,horizontal) {')
end=s.index('\n  function screenHome()',start)
new_func='''  function restaurantCard(r,horizontal){const liked=(state.profile.favourites||[]).includes(r.id),distance=restaurantDistanceKm(r),fee=deliveryFeeForRestaurant(r,0),distanceText=distance==null?"":distance.toFixed(distance<10?1:0)+" km",rating=r.rating?Number(r.rating).toFixed(1):"New";return'<article class="restaurant-card '+(horizontal?'horizontal':'')+'" data-action="open-restaurant" data-restaurant-id="'+h(r.id)+'" tabindex="0" role="button" aria-label="Open '+h(r.name)+'"><div class="restaurant-media"><img src="'+h(safeUrl(r.image,"veg-meal.jpg"))+'" alt="'+h(r.name)+'"><span class="media-badge">'+(r.open?'Open':'Closed')+'</span><button class="heart-button '+(liked?'liked':'')+'" data-action="toggle-favourite" data-restaurant-id="'+h(r.id)+'" aria-label="'+(liked?'Remove from':'Add to')+' favourites">'+icon("heart")+'</button></div><div class="restaurant-copy"><div class="restaurant-title-row"><h3 class="card-title restaurant-name">'+h(r.name)+'</h3><span class="rating compact">'+icon("star","small")+'<strong>'+h(rating)+'</strong></span></div><p class="supporting restaurant-cuisines">'+h((r.cuisines||[]).join(" · "))+'</p><div class="restaurant-meta"><span>'+icon("clock","small")+' '+h(r.etaMin||25)+'–'+h(r.etaMax||35)+' min</span>'+(distanceText?'<span>'+icon("pin","small")+' '+h(distanceText)+'</span>':'')+'<span>'+(fee===0?'Free delivery':money(fee)+' delivery')+'</span></div></div></article>'}'''
s=s[:start]+new_func+s[end:]

# Restaurant detail fee dynamic
old="+(Number(r.deliveryFee||0)===0?'Free':money(r.deliveryFee))+'</strong><span>Delivery fee</span></div></section>'"
new="+(deliveryFeeForRestaurant(r,0)===0?'Free':money(deliveryFeeForRestaurant(r,0)))+'</strong><span>Delivery fee</span></div></section>'"
assert old in s;s=s.replace(old,new,1)

# Price breakdown function
start=s.index('  function priceBreakdown(includeTotal) {')
end=s.index('\n  function screenCart()',start)
new_func='''  function priceBreakdown(includeTotal){return'<div class="stack"><div class="price-row"><span>Item subtotal</span><span>'+money(cartSubtotal())+'</span></div>'+(discount()?'<div class="price-row success-text"><span>'+h(state.coupon.code)+' discount</span><span>−'+money(discount())+'</span></div>':'')+'<div class="price-row"><span>Delivery fee</span><span>'+(deliveryFee()?money(deliveryFee()):'<span class="success-text">Free</span>')+'</span></div>'+(smallOrderFee()>0?'<div class="price-row"><span>Small order fee</span><span>'+money(smallOrderFee())+'</span></div>':'')+(lateNightFee()>0?'<div class="price-row"><span>Late-night fee</span><span>'+money(lateNightFee())+'</span></div>':'')+(rainFee()>0?'<div class="price-row"><span>Rain fee</span><span>'+money(rainFee())+'</span></div>':'')+(surgeFee()>0?'<div class="price-row"><span>High demand fee</span><span>'+money(surgeFee())+'</span></div>':'')+'<div class="price-row"><span>Platform fee</span><span>'+money(platformFee())+'</span></div>'+(tax()?'<div class="price-row"><span>Taxes</span><span>'+money(tax())+'</span></div>':'')+(state.tip?'<div class="price-row"><span>Delivery partner tip</span><span>'+money(state.tip)+'</span></div>':'')+(includeTotal?'<div class="price-row total"><span>Order total</span><span>'+money(orderTotal())+'</span></div>':'')+'</div>'}'''
s=s[:start]+new_func+s[end:]

# Checkout dynamic fee notices only if active
old="+'<section class=\"card\">'+priceBreakdown(true)+'</section><div class=\"notice info\">'"
new="+'<section class=\"card\">'+priceBreakdown(true)+'</section>'+(rainFee()>0?'<div class=\"notice info\">'+icon(\"info\",\"small\")+'<span>Rain fee applied because Google Weather reports '+h(state.dynamicPricing.weatherSeverity||\"rain\")+' conditions along this delivery journey.</span></div>':'')+(surgeFee()>0?'<div class=\"notice warning\">'+icon(\"clock\",\"small\")+'<span>High demand fee is temporary and based on the restaurant’s live active-order load.</span></div>':'')+'<div class=\"notice info\">'"
assert old in s;s=s.replace(old,new,1)

# Address form add city
old='<div class="field"><label for="address-area">Area</label><input id="address-area" class="input" name="area" value="'+"'+h(address.area||\"\")+'"+'" placeholder="Neighbourhood or locality" required></div><div class="field"><label for="address-full">'
literal='''<div class="field"><label for="address-area">Area</label><input id="address-area" class="input" name="area" value="'+h(address.area||"")+'" placeholder="Neighbourhood or locality" required></div><div class="field"><label for="address-full">'''
repl='''<div class="field"><label for="address-area">Area</label><input id="address-area" class="input" name="area" value="'+h(address.area||"")+'" placeholder="Neighbourhood or locality" required></div><div class="field"><label for="address-city">City</label><input id="address-city" class="input" name="city" value="'+h(address.city||"")+'" placeholder="Nellore" required></div><div class="field"><label for="address-full">'''
assert literal in s;s=s.replace(literal,repl,1)

# submit address city
old='record={id:existingId||uid("addr_"),label:String(values.get("label")||"").trim(),area:String(values.get("area")||"").trim(),address:String(values.get("address")||"").trim(),phone:phone,source:'
new='record={id:existingId||uid("addr_"),label:String(values.get("label")||"").trim(),area:String(values.get("area")||"").trim(),city:String(values.get("city")||"").trim(),address:String(values.get("address")||"").trim(),phone:phone,source:'
assert old in s;s=s.replace(old,new,1)
old='if(!record.label||!record.area||!record.address){toast("Complete the label, area and full address.","danger");return;}'
new='if(!record.label||!record.area||!record.city||!record.address){toast("Complete the label, area, city and full address.","danger");return;}'
assert old in s;s=s.replace(old,new,1)

# Add chat screen before tracking
needle='  function screenTracking() {'
insert='''  function screenChat(){const o=state.orders.find(x=>x.id===state.chat.orderId),messages=state.chat.messages||[];if(!o)return screenOrders();return'<main class="screen"><div class="screen-content page-stack">'+topbar(state.chat.title||"Order chat","Order "+o.id)+'<div class="notice info">'+icon("shield","small")+'<span>Real phone numbers are not displayed. Phone numbers typed in chat are automatically hidden.</span></div><section class="card chat-thread">'+(messages.length?messages.map(m=>'<div class="chat-message '+(m.senderId===state.session.uid?'mine':'')+'"><strong>'+h(m.senderRole||"user")+'</strong><p>'+h(m.body||"")+'</p><span class="caption">'+h(dateTime(m.at))+'</span></div>').join(""):emptyState("help","No messages yet","Use chat to coordinate this order."))+'</section><form id="chat-form" class="card cluster"><input class="input grow" name="message" maxlength="800" placeholder="Type a message" required><button class="button primary" type="submit">Send</button></form></div>'+nav()+'</main>'}
'''
assert needle in s;s=s.replace(needle,insert+needle,1)

# Add communication to customer order screen before items section
needle="+'<section class=\"card stack\"><div class=\"cluster between\"><h2 class=\"section-title\">Items</h2>"
insert="+'<section class=\"card stack\"><h2 class=\"section-title\">Communication</h2><p class=\"supporting\">Use private Savrivo chat. Personal mobile numbers stay hidden.</p><div class=\"cluster wrap\"><button class=\"button tonal grow\" data-action=\"open-order-chat\" data-channel=\"customerRestaurant\" data-order-id=\"'+h(order.id)+'\">Chat restaurant</button>'+(order.riderId?'<button class=\"button tonal grow\" data-action=\"open-order-chat\" data-channel=\"customerRider\" data-order-id=\"'+h(order.id)+'\">Chat rider</button>':'')+(order.contactProxy&&order.contactProxy.customerToRider?'<a class=\"button secondary grow\" href=\"tel:'+h(order.contactProxy.customerToRider)+'\">Secure call rider</a>':'')+'</div></section>'"
assert needle in s;s=s.replace(needle,insert+needle,1)

# go-checkout refresh pricing
old='if(action==="go-checkout"){if(!state.cart.length)return;go("checkout");return;}'
new='if(action==="go-checkout"){if(!state.cart.length)return;go("checkout");refreshDynamicPricing().then(()=>{if(state.route==="checkout")render({preserveScroll:true})}).catch(()=>{});return;}'
assert old in s;s=s.replace(old,new,1)

# Chat action
needle='if(action==="open-order"){go("order",{orderId:control.dataset.orderId});return;}'
rep=needle+'if(action==="open-order-chat"){const o=state.orders.find(x=>x.id===control.dataset.orderId);if(o)openOrderChat(o,control.dataset.channel,control.dataset.channel==="customerRider"?"Chat with delivery partner":"Chat with restaurant");return;}'
assert needle in s;s=s.replace(needle,rep,1)

# Refresh dynamic before submit order and conditional pricing fields/context
old='if(!r||!r.open){toast("This restaurant is not accepting orders right now.","danger");return;}\n    state.checkout.instructions='
new='if(!r||!r.open){toast("This restaurant is not accepting orders right now.","danger");return;}\n    await refreshDynamicPricing();\n    state.checkout.instructions='
assert old in s;s=s.replace(old,new,1)
old='pricing:{subtotal:cartSubtotal(),discount:discount(),deliveryFee:deliveryFee(),platformFee:platformFee(),tax:tax(),tip:Number(state.tip||0),currency:"INR",source:"catalog_snapshot_v3"},'
new='pricing:Object.assign({subtotal:cartSubtotal(),discount:discount(),deliveryFee:deliveryFee(),platformFee:platformFee(),tax:tax(),tip:Number(state.tip||0),currency:"INR",source:"catalog_snapshot_v3"},smallOrderFee()>0?{smallOrderFee:smallOrderFee()}:{},lateNightFee()>0?{lateNightFee:lateNightFee()}:{},rainFee()>0?{rainFee:rainFee()}:{},surgeFee()>0?{surgeFee:surgeFee()}:{}),\n      pricingContext:{distanceKm:Number((restaurantDistanceKm(r)||0).toFixed(2)),platformFeeRule:platformFeeDetails().rule,weatherSeverity:state.dynamicPricing.weatherSeverity||"",surgeActiveOrders:Number(state.dynamicPricing.activeOrders||0),pricedAt:Date.now()},'
assert old in s;s=s.replace(old,new,1)

# reset dynamic after order
old='state.cart=[];state.coupon=null;state.tip=0;state.checkout.pendingOrderId="";'
new='state.cart=[];state.coupon=null;state.tip=0;state.dynamicPricing={rainFee:0,surgeFee:0,weatherSeverity:"",weatherChecked:false,activeOrders:0,checkedAt:0};state.checkout.pendingOrderId="";'
assert old in s;s=s.replace(old,new,1)

# Screens chat
old='order:screenOrder, tracking:screenTracking, offers:screenOffers, account:screenAccount,'
new='order:screenOrder, chat:screenChat, tracking:screenTracking, offers:screenOffers, account:screenAccount,'
assert old in s;s=s.replace(old,new,1)
# submit chat
old='else if(form.id==="support-form")submitSupport(form);'
new='else if(form.id==="support-form")submitSupport(form);\n    else if(form.id==="chat-form")sendOrderChat(form);'
assert old in s;s=s.replace(old,new,1)

p.write_text(s)
print('customer patched')
