# Savrivo 3.1 developer build — install and test

Savrivo is now split into **four Android apps** over the same Firebase project:

1. **Savrivo Customer** — discovery, ordering, addresses and live tracking.
2. **Savrivo Admin** — Savrivo platform-owner operations, approvals and overrides.
3. **Savrivo Restaurant** — restaurant owner/manager/staff daily operations.
4. **Savrivo Partner** — rider onboarding, delivery workflow, navigation and live location.

All modules target Android API 36 and Android 6.0+ (min API 23).

## Build on the development Mac

From the repository root:

```sh
native_android/tests/run.sh
native_android/build_savrivo.sh
```

The build script expects Android SDK platform 36+, current Android build tools, a JDK and Node.js. It produces developer-signed APKs for all four apps.

## First integrated test

1. Run `native_android/tests/run.sh`; do not continue if it fails.
2. Deploy the prepared Firebase RTDB/Storage rules to a **test Firebase project first**, not production.
3. Sign in to Savrivo Admin as the platform owner.
4. Create/verify a restaurant and provision a Restaurant account for it.
5. Sign in to Savrivo Restaurant and verify only the assigned restaurant is visible.
6. Add/edit a menu item, upload a photo, change price and toggle availability. Confirm Customer receives the normalized menu update.
7. Toggle the restaurant offline for 30 minutes. Confirm Customer immediately treats it as unavailable; restore online.
8. In Customer, add a delivery address using the tappable map pin or phone location, then place a COD test order.
9. In Restaurant, accept → preparing → ready for pickup. Confirm the delivery appears to eligible Partner users.
10. Put a Partner online and claim the delivery. Attempt a near-simultaneous second claim from another Partner; only one fresh claim should win.
11. Navigate to restaurant, confirm handover, navigate to customer, and verify the Customer tracking view updates from the foreground GPS service.
12. Complete delivery with the verification flow and confirm it appears in history.

## Important production gates

The repository is substantially safer than the previous developer build, but do **not** take real online payments yet. Production launch still requires trusted server-side price/payment verification, payment-gateway webhooks, production push delivery, Firebase emulator/rules testing, real-device QA, release signing, legal/privacy pages, monitoring and controlled Firebase deployment.
