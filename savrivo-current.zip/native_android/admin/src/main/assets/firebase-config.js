window.FEASTLY_FIREBASE = {
  apiKey: "AIzaSyBV3xmCm7HiWJLygloPDNBg6qq6gkO-F6I",
  projectId: "savrivo-app",
  databaseUrl: "https://savrivo-app-default-rtdb.firebaseio.com",
  storageBucket: "savrivo-app.firebasestorage.app"
};
