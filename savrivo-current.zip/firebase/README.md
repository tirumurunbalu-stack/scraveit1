# Savrivo Firebase deployment files

- `feastly-realtime-database-rules.json` — Realtime Database rules. The legacy `feastly` root remains for backward compatibility.
- `storage.rules` — Firebase Storage rules for restaurant media and private rider KYC.

These files are repository configuration only. They are **not deployed automatically** by the Android build script. Deploy them only after testing against a Firebase emulator or a non-production project, then publish them with the Firebase CLI/account that owns project `kamju-a4750`.
