import {describe, expect, it} from "vitest";
import {buildRestaurantOrderProjection} from "../src/domain/restaurantOrder";
import type {SavrivoOrder} from "../src/types";

describe("restaurant order privacy projection", () => {
  it("keeps order operations but removes raw phone and exact drop location", () => {
    const order = {
      id: "SV-RESTAURANT",
      customerId: "customer-1",
      customerName: "Customer",
      customerPhone: "+919999999999",
      contactProxy: "+911234567890",
      address: {
        id: "home",
        label: "Home",
        area: "Naidupeta",
        city: "Tirupati",
        address: "Exact house and street",
        phone: "+918888888888",
        lat: 13.91,
        lng: 79.89,
      },
      status: "Preparing",
      deliveryOtpHash: "a".repeat(64),
      deliveryOtpSalt: "b".repeat(32),
    } as unknown as SavrivoOrder;

    const projection = buildRestaurantOrderProjection(order);
    expect(projection).toMatchObject({
      id: "SV-RESTAURANT",
      customerId: "customer-1",
      status: "Preparing",
      contactProxy: "+911234567890",
      address: {label: "Home", area: "Naidupeta", city: "Tirupati"},
    });
    expect(projection).not.toHaveProperty("customerPhone");
    expect(projection.address).not.toHaveProperty("address");
    expect(projection.address).not.toHaveProperty("phone");
    expect(projection.address).not.toHaveProperty("lat");
    expect(projection.address).not.toHaveProperty("lng");
    expect(JSON.stringify(projection)).not.toContain("9999999999");
    expect(JSON.stringify(projection)).not.toContain("8888888888");
    expect(JSON.stringify(projection)).not.toContain("deliveryOtp");
  });
});
