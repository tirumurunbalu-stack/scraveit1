import {describe, expect, it} from "vitest";
import {buildRiderJobProjection} from "../src/domain/riderJob";
import type {SavrivoOrder} from "../src/types";

function order(status: SavrivoOrder["status"]): SavrivoOrder {
  return {
    id: "SV-JOB",
    customerId: "customer-1",
    customerName: "Private Customer",
    customerPhone: "+919999999999",
    restaurantId: "restaurant-1",
    restaurant: "The Waffle Spot",
    restaurantLocation: {address: "Restaurant address", lat: 13.9, lng: 79.88},
    address: {
      id: "home", label: "Home", area: "Naidupeta", address: "Exact private address",
      phone: "+918888888888", source: "gps", updatedAt: 1, lat: 13.91, lng: 79.89,
    },
    items: [{itemId: "waffle", name: "Waffle", quantity: 1, price: 100, variant: "", variantPrice: 0, addOns: [], addOnTotal: 0, note: "", diet: "veg"}],
    pricing: {deliveryFee: 39},
    total: 139,
    paymentMethod: "cod",
    instructions: "Ring bell",
    contactless: false,
    etaMax: 30,
    createdAt: 1_000,
    updatedAt: 2_000,
    status,
    statusHistory: {assigned: {status: "Assigned", at: 1_500, actorId: "rider-1", actorRole: "rider"}},
  } as SavrivoOrder;
}

describe("rider job privacy projection", () => {
  it("keeps exact customer details hidden before restaurant handover", () => {
    const projection = buildRiderJobProjection(order("Assigned"));
    expect(projection).toMatchObject({approximateDropZone: "Naidupeta", itemCount: 1, orderStatus: "Assigned"});
    expect(projection).not.toHaveProperty("customerName");
    expect(projection).not.toHaveProperty("address");
    expect(JSON.stringify(projection)).not.toContain("9999999999");
    expect(JSON.stringify(projection)).not.toContain("8888888888");
  });

  it("reveals only delivery-required fields after handover and never a raw phone", () => {
    const projection = buildRiderJobProjection(order("Handed to rider"));
    expect(projection).toMatchObject({
      customerName: "Private Customer",
      address: {address: "Exact private address", lat: 13.91, lng: 79.89},
      paymentMethod: "cod",
      otpRequired: true,
    });
    expect(JSON.stringify(projection)).not.toContain("customerPhone");
    expect(JSON.stringify(projection)).not.toContain("phone");
    expect(JSON.stringify(projection)).not.toContain("9999999999");
    expect(JSON.stringify(projection)).not.toContain("8888888888");
  });

  it("redacts exact drop details again when the job is terminal", () => {
    const projection = buildRiderJobProjection(order("Delivered"));
    expect(projection).toMatchObject({status: "completed", phase: "complete"});
    expect(projection).not.toHaveProperty("address");
    expect(projection).not.toHaveProperty("items");
    expect(projection).not.toHaveProperty("customerName");
  });
});
