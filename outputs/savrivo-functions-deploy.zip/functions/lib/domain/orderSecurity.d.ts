import type { SavrivoOrder } from "../types";
export interface LegacyOtpVerifier {
    verifier: string;
    salt: string;
}
/**
 * Removes legacy delivery-code material before an order is returned, mirrored,
 * or rewritten. The cast is intentional: old RTDB rows can contain fields that
 * no longer exist in the public SavrivoOrder type.
 */
export declare function stripPrivateOrderFields(order: SavrivoOrder): SavrivoOrder;
/** Reads only legacy rows so their verifier can be migrated server-side. */
export declare function legacyOtpVerifier(order: SavrivoOrder): LegacyOtpVerifier | null;
export declare function publicOrderContainsPrivateFields(order: unknown): boolean;
