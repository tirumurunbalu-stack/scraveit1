import type { ActorRole, CatalogItem, CartSelection, GeoPoint, OrderStatus, PricedOrderItem, PricingBreakdown, RiderCandidate } from "../types";
export declare const TRANSITIONS: Readonly<Record<OrderStatus, readonly OrderStatus[]>>;
export declare function canTransition(from: OrderStatus, to: OrderStatus, role: ActorRole): boolean;
export declare function deterministicOrderId(customerId: string, idempotencyKey: string): string;
export declare function hashOtp(otp: string, salt: string): string;
export declare function roundMoney(value: number): number;
export declare function haversineKm(a: GeoPoint, b: GeoPoint): number;
export declare function priceCart(selections: CartSelection[], menuById: Record<string, CatalogItem>): {
    items: PricedOrderItem[];
    subtotal: number;
};
export interface FeeInput {
    subtotal: number;
    discount: number;
    deliveryFee: number;
    platformFee: number;
    taxRate: number;
    tip: number;
    smallOrderThreshold?: number;
    smallOrderFee?: number;
    lateNightFee?: number;
    rainFee?: number;
    surgeFee?: number;
}
export declare function buildPricing(input: FeeInput): {
    pricing: PricingBreakdown;
    total: number;
};
export declare function rankRiders(candidates: Omit<RiderCandidate, "score">[]): RiderCandidate[];
