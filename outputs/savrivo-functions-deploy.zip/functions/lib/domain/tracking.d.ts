import type { GeoPoint, OrderStatus } from "../types";
export declare const MAX_GEOFENCE_ACCURACY_METERS = 35;
export declare const MAX_TRACKING_AGE_MS = 30000;
export declare const MAX_TRACKING_FUTURE_SKEW_MS = 5000;
export declare const MIN_CONSECUTIVE_FIX_GAP_MS = 5000;
export declare const MAX_CONSECUTIVE_FIX_GAP_MS = 45000;
export type ProximityStatus = "Near you" | "Arrived";
export interface TrackingFix extends GeoPoint {
    orderId: string;
    customerId: string;
    riderId: string;
    accuracy: number;
    updatedAt: number;
    phase: "delivery";
    status: "live";
}
export interface PendingTrackingTransition {
    status: ProximityStatus;
    evidenceEventId: string;
    qualifiedAt: number;
    distanceMeters: number;
}
export interface TrackingEvidenceRecord extends GeoPoint {
    orderId: string;
    customerId: string;
    riderId: string;
    lastEventId: string;
    lastFixAt: number;
    accuracy: number;
    distanceMeters: number;
    candidate: ProximityStatus | "";
    consecutiveFixes: number;
    lastQualifiedAt: number;
    updatedAt: number;
    pendingTransition?: PendingTrackingTransition;
    lastTransition?: {
        status: ProximityStatus;
        at: number;
        evidenceEventId: string;
    };
    lastRejected?: {
        eventId: string;
        reason: "impossible_movement";
        at: number;
    };
}
export interface ProximityRequirement {
    status: ProximityStatus;
    thresholdMeters: number;
    requiredFixes: number;
}
export declare function normalizeTrackingFix(value: unknown, expectedOrderId: string): TrackingFix | null;
export declare function isFreshMonotonicFix(fix: TrackingFix, previousClientTimestamp: number, now: number): boolean;
export declare function proximityRequirement(status: OrderStatus, distanceMeters: number): ProximityRequirement | null;
export declare function trackingDistanceMeters(fix: TrackingFix, dropPoint: GeoPoint): number;
export declare function plausibleMovement(previous: TrackingEvidenceRecord | null, fix: TrackingFix): boolean;
export interface AdvanceEvidenceInput {
    eventId: string;
    fix: TrackingFix;
    distanceMeters: number;
    requirement: ProximityRequirement | null;
    serverNow: number;
}
/** Pure transaction reducer. The pending transition survives retries/crashes. */
export declare function advanceTrackingEvidence(previous: TrackingEvidenceRecord | null, input: AdvanceEvidenceInput): TrackingEvidenceRecord | null;
export declare function hasReachedProximityStatus(current: OrderStatus, target: ProximityStatus): boolean;
