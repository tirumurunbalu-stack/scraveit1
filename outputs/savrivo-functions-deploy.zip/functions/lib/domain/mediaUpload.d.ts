export declare const PUBLIC_MEDIA_MAX_BYTES = 2500000;
export declare const KYC_MEDIA_MAX_BYTES = 1500000;
export declare const PUBLIC_MEDIA_DAILY_LIMIT: {
    readonly count: 100;
    readonly bytes: 100000000;
};
export declare const KYC_MEDIA_DAILY_LIMIT: {
    readonly count: 12;
    readonly bytes: 12000000;
};
export type SupportedImageType = "image/jpeg" | "image/png" | "image/webp";
export type UploadQuota = {
    count: number;
    bytes: number;
    updatedAt: number;
};
export interface InspectedImage {
    buffer: Buffer;
    contentType: SupportedImageType;
    width: number;
    height: number;
    sha256: string;
}
export declare function inspectRasterImage(encoded: string, contentType: SupportedImageType, purpose: "public" | "kyc", suppliedSha256?: string): InspectedImage;
export declare function reserveUploadQuota(current: UploadQuota | null, bytes: number, limit: {
    count: number;
    bytes: number;
}, now: number): UploadQuota;
export declare function utcDayKey(now: number): string;
export declare function publicObjectUrl(bucket: string, objectPath: string, generation: string): string;
