import type { SavrivoOrder } from "../types";
export type RestaurantOrderProjection = Omit<SavrivoOrder, "customerPhone" | "address"> & {
    address: {
        label: string;
        area: string;
        city?: string;
    };
};
/** Restaurant operations need the order, not a customer's phone or drop pin. */
export declare function buildRestaurantOrderProjection(order: SavrivoOrder): RestaurantOrderProjection;
