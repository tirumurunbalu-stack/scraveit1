import type { OrderStatus, SavrivoOrder } from "../types";
export interface WorkloadOrderState {
    status: OrderStatus;
    orderUpdatedAt: number;
    terminalAt?: number;
}
export interface RestaurantWorkload {
    restaurantId: string;
    activeOrders: number;
    preparing: number;
    ready: number;
    updatedAt: number;
    source: "functions";
    orders: Record<string, WorkloadOrderState>;
}
export declare function trustedActiveOrderCount(value: unknown, restaurantId: string): number;
export declare function reduceRestaurantWorkload(current: RestaurantWorkload | null, order: Pick<SavrivoOrder, "id" | "restaurantId" | "status" | "updatedAt">, now: number): RestaurantWorkload;
