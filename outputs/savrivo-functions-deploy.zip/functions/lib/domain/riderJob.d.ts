import type { SavrivoOrder } from "../types";
type ExistingRiderJob = Record<string, unknown> | null | undefined;
export declare function riderMaySeeDropDetails(order: SavrivoOrder): boolean;
/** Minimum backend-owned projection; never includes customerPhone. */
export declare function buildRiderJobProjection(order: SavrivoOrder, existing?: ExistingRiderJob): Record<string, unknown>;
export {};
