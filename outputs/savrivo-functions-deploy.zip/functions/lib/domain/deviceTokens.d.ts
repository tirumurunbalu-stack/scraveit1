export interface DeviceTokenRecord {
    token: string;
    app: "customer" | "restaurant" | "rider" | "admin";
    platform: "android" | "ios";
    appVersion: string;
    deviceModel: string;
    enabled: true;
    createdAt: number;
    updatedAt: number;
}
export declare function deviceTokenKey(token: string): string;
export declare function upsertDeviceToken(current: Record<string, DeviceTokenRecord> | null, record: Omit<DeviceTokenRecord, "createdAt" | "updatedAt">, now: number, cap: number): {
    tokens: Record<string, DeviceTokenRecord>;
    key: string;
};
