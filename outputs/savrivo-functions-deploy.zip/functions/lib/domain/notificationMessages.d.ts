import type { MulticastMessage } from "firebase-admin/messaging";
import type { SavrivoOrder } from "../types";
export type TokenlessMulticastMessage = Omit<MulticastMessage, "tokens">;
type RestaurantNewOrder = Pick<SavrivoOrder, "id" | "customerId" | "restaurantId" | "items" | "total">;
type RiderOfferOrder = Pick<SavrivoOrder, "id" | "customerId" | "restaurantId" | "restaurant" | "pricing">;
export declare function restaurantAlarmId(orderId: string): string;
export declare function restaurantOrderCollapseKey(orderId: string): string;
export declare function riderOfferId(orderId: string): string;
export declare function riderOfferCollapseKey(orderId: string): string;
/**
 * Android deliberately receives a data-only message. A top-level notification
 * payload lets Android render the message without invoking onMessageReceived,
 * which would make the app-owned acknowledgement alarm unreliable.
 */
export declare function buildRestaurantNewOrderMessage(order: RestaurantNewOrder): TokenlessMulticastMessage;
export declare function buildStopRestaurantAlarmMessage(orderId: string): TokenlessMulticastMessage;
/** Android data-only for exact offer persistence before the app displays it. */
export declare function buildRiderOfferMessage(order: RiderOfferOrder, expiresAt: number, now?: number): TokenlessMulticastMessage;
export declare function buildRemoveRiderOfferMessage(orderId: string, assignedRiderId: string): TokenlessMulticastMessage;
export {};
