export interface TrackingUpdateContext {
    orderId: string;
    eventId: string;
    authType: "app_user" | "admin" | "unauthenticated" | "unknown";
    authId?: string;
    before: unknown;
    after: unknown;
    now?: number;
}
export interface TrackingUpdateResult {
    outcome: "ignored" | "evidence_recorded" | "transitioned";
    reason?: string;
    status?: "Near you" | "Arrived";
}
export declare function processTrackingUpdate(context: TrackingUpdateContext): Promise<TrackingUpdateResult>;
