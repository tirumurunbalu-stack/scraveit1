import type { DecodedIdToken } from "firebase-admin/auth";
import { z } from "zod";
export declare const restaurantMediaUploadSchema: z.ZodObject<{
    restaurantId: z.ZodString;
    kind: z.ZodEnum<["cover", "menu"]>;
    entityId: z.ZodOptional<z.ZodString>;
    contentType: z.ZodEnum<["image/jpeg", "image/png", "image/webp"]>;
    dataBase64: z.ZodString;
    sha256: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    restaurantId: string;
    kind: "cover" | "menu";
    contentType: "image/jpeg" | "image/png" | "image/webp";
    dataBase64: string;
    sha256?: string | undefined;
    entityId?: string | undefined;
}, {
    restaurantId: string;
    kind: "cover" | "menu";
    contentType: "image/jpeg" | "image/png" | "image/webp";
    dataBase64: string;
    sha256?: string | undefined;
    entityId?: string | undefined;
}>;
export declare const platformMediaUploadSchema: z.ZodObject<{
    kind: z.ZodEnum<["ads", "banners"]>;
    entityId: z.ZodString;
    contentType: z.ZodEnum<["image/jpeg", "image/png", "image/webp"]>;
    dataBase64: z.ZodString;
    sha256: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    kind: "ads" | "banners";
    entityId: string;
    contentType: "image/jpeg" | "image/png" | "image/webp";
    dataBase64: string;
    sha256?: string | undefined;
}, {
    kind: "ads" | "banners";
    entityId: string;
    contentType: "image/jpeg" | "image/png" | "image/webp";
    dataBase64: string;
    sha256?: string | undefined;
}>;
export declare const riderKycUploadSchema: z.ZodObject<{
    documentKind: z.ZodEnum<["aadhaarFront", "aadhaarBack", "panCopy"]>;
    contentType: z.ZodEnum<["image/jpeg", "image/png", "image/webp"]>;
    dataBase64: z.ZodString;
    sha256: z.ZodOptional<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    contentType: "image/jpeg" | "image/png" | "image/webp";
    dataBase64: string;
    documentKind: "aadhaarFront" | "aadhaarBack" | "panCopy";
    sha256?: string | undefined;
}, {
    contentType: "image/jpeg" | "image/png" | "image/webp";
    dataBase64: string;
    documentKind: "aadhaarFront" | "aadhaarBack" | "panCopy";
    sha256?: string | undefined;
}>;
export declare const riderKycReviewSchema: z.ZodObject<{
    riderUid: z.ZodString;
    documentKind: z.ZodEnum<["aadhaarFront", "aadhaarBack", "panCopy"]>;
}, "strict", z.ZodTypeAny, {
    documentKind: "aadhaarFront" | "aadhaarBack" | "panCopy";
    riderUid: string;
}, {
    documentKind: "aadhaarFront" | "aadhaarBack" | "panCopy";
    riderUid: string;
}>;
export type RestaurantMediaUploadInput = z.infer<typeof restaurantMediaUploadSchema>;
export type PlatformMediaUploadInput = z.infer<typeof platformMediaUploadSchema>;
export type RiderKycUploadInput = z.infer<typeof riderKycUploadSchema>;
export type RiderKycReviewInput = z.infer<typeof riderKycReviewSchema>;
export declare function uploadRestaurantMediaObject(uid: string, token: DecodedIdToken, input: RestaurantMediaUploadInput): Promise<{
    objectPath: string;
    imageUrl: string;
    width: number;
    height: number;
    sha256: string;
}>;
export declare function uploadPlatformMediaObject(uid: string, token: DecodedIdToken, input: PlatformMediaUploadInput): Promise<{
    objectPath: string;
    imageUrl: string;
    width: number;
    height: number;
    sha256: string;
}>;
export declare function uploadRiderKycObject(uid: string, input: RiderKycUploadInput): Promise<{
    documentKind: RiderKycUploadInput["documentKind"];
    uploadedAt: number;
    sha256: string;
}>;
export declare function createRiderKycReviewUrl(reviewerUid: string, token: DecodedIdToken, input: RiderKycReviewInput): Promise<{
    url: string;
    expiresAt: number;
    contentType: string;
    size: number;
    sha256: string;
}>;
