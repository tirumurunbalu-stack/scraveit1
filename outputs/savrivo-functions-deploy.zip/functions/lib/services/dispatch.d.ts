import type { DispatchQueueRecord, SavrivoOrder } from "../types";
export interface Presence {
    online?: boolean;
    riderId?: string;
    riderName?: string;
    updatedAt?: number;
    lat?: number;
    lng?: number;
    activeOrderId?: string;
    city?: string;
}
type QueueWithOfferData = DispatchQueueRecord & {
    active: boolean;
    restaurantAddress: string;
    restaurantLat: number;
    restaurantLng: number;
    approximateDropZone: string;
    itemCount: number;
    payout: number;
    estimatedMinutes: number;
    offeredRiderId?: string;
};
export declare function availabilityCityKey(value: unknown): string;
export declare function updateRiderAvailabilityIndex(riderId: string, before: Presence | null, after: Presence | null): Promise<void>;
export declare function beginSequentialDispatch(order: SavrivoOrder): Promise<QueueWithOfferData | null>;
export declare function advanceDispatchOffer(orderId: string, expectedAttempt: number): Promise<void>;
export declare function claimDispatchOffer(uid: string, orderId: string): Promise<SavrivoOrder>;
export {};
