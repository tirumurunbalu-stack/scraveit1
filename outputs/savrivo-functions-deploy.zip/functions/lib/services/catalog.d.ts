import type { Address, CatalogItem, CatalogRestaurant } from "../types";
type UnknownRecord = Record<string, unknown>;
export declare function loadRestaurantAndMenu(restaurantId: string): Promise<{
    restaurant: CatalogRestaurant;
    menuById: Record<string, CatalogItem>;
}>;
export declare function loadCustomerAddress(uid: string, addressId: string): Promise<{
    address: Address;
    profile: UnknownRecord;
}>;
export declare function loadServerFees(restaurant: CatalogRestaurant, address: Address, subtotal: number): Promise<{
    deliveryFee: number;
    platformFee: number;
    taxRate: number;
    smallOrderThreshold: number;
    smallOrderFee: number;
    lateNightFee: number;
    rainFee: number;
    surgeFee: number;
    distanceKm: number;
    activeOrders: number;
}>;
export declare function calculateDiscount(code: string, subtotal: number, restaurantId: string): Promise<number>;
export {};
