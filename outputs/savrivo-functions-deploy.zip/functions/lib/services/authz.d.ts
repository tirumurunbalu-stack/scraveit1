import type { DecodedIdToken } from "firebase-admin/auth";
import type { ActorRole, OrderStatus, SavrivoOrder } from "../types";
export declare function authorizeTransition(uid: string, token: DecodedIdToken, order: SavrivoOrder, target: OrderStatus): Promise<ActorRole>;
export declare function requireApprovedRider(uid: string): Promise<Record<string, unknown>>;
