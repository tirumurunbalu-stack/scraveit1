import type { SavrivoOrder } from "../types";
import type { InitiatePaymentInput } from "./serviceTypes";
export interface PaymentIntent {
    provider: "phonepe";
    merchantOrderId: string;
    redirectUrl: string;
    expiresAt: number;
}
export interface VerifiedPaymentEvent {
    verified: true;
    provider: "phonepe";
    merchantOrderId: string;
    providerTransactionId: string;
    amountPaise: number;
    state: "paid" | "failed" | "refunded";
    rawEventHash: string;
}
export type VerificationResult = VerifiedPaymentEvent | {
    verified: false;
    reason: string;
};
export interface PaymentGateway {
    readonly provider: "phonepe";
    createIntent(order: SavrivoOrder): Promise<PaymentIntent>;
    verifyWebhook(headers: Record<string, string | undefined>, rawBody: Buffer): Promise<VerificationResult>;
}
/**
 * Fail-closed adapter. Replace only after PhonePe issues production credentials
 * and the exact contracted API/webhook version is confirmed. It deliberately
 * cannot create an intent or return `verified: true`.
 */
export declare class UnconfiguredPhonePeGateway implements PaymentGateway {
    readonly provider: "phonepe";
    createIntent(_order: SavrivoOrder): Promise<PaymentIntent>;
    verifyWebhook(_headers: Record<string, string | undefined>, rawBody: Buffer): Promise<VerificationResult>;
}
export declare function initiatePayment(uid: string, input: InitiatePaymentInput, gateway: PaymentGateway): Promise<PaymentIntent>;
export declare function applyVerifiedPayment(event: VerifiedPaymentEvent): Promise<void>;
export declare function callbackHash(rawBody: Buffer): string;
export declare function constantTimeStringEqual(left: string, right: string): boolean;
