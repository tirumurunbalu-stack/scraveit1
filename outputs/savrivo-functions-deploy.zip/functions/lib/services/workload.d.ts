import { type RestaurantWorkload } from "../domain/workload";
import type { SavrivoOrder } from "../types";
export declare function reconcileRestaurantWorkload(order: SavrivoOrder): Promise<RestaurantWorkload>;
