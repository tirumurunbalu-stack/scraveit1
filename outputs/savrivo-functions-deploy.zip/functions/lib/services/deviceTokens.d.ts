import type { DecodedIdToken } from "firebase-admin/auth";
import type { RegisterDeviceTokenInput, UnregisterDeviceTokenInput } from "./serviceTypes";
export declare function registerDeviceToken(uid: string, authToken: DecodedIdToken, input: RegisterDeviceTokenInput): Promise<{
    tokenId: string;
    updatedAt: number;
}>;
export declare function unregisterDeviceToken(uid: string, input: UnregisterDeviceTokenInput): Promise<{
    removed: boolean;
}>;
