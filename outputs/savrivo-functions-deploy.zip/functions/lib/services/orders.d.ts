import type { DecodedIdToken } from "firebase-admin/auth";
import type { ProximityStatus } from "../domain/tracking";
import type { CreateCodOrderInput, TransitionOrderInput } from "./serviceTypes";
import type { ActorRole, SavrivoOrder } from "../types";
export declare function scrubLegacyPublicOtp(order: SavrivoOrder): Promise<SavrivoOrder>;
export declare function createAuthoritativeCodOrder(uid: string, input: CreateCodOrderInput): Promise<{
    order: SavrivoOrder;
    deliveryOtp: string;
    recovered: boolean;
}>;
export declare function transitionOrder(uid: string, token: DecodedIdToken, input: TransitionOrderInput): Promise<{
    order: SavrivoOrder;
    actorRole: ActorRole;
}>;
export declare function transitionOrderFromTracking(customerId: string, orderId: string, riderId: string, target: ProximityStatus, evidenceEventId: string, distanceMeters: number): Promise<SavrivoOrder>;
export declare function recordCodLedger(order: SavrivoOrder): Promise<void>;
