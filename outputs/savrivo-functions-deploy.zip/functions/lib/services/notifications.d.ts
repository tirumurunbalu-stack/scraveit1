import type { SavrivoOrder } from "../types";
export declare function notifyRestaurantNewOrder(order: SavrivoOrder): Promise<void>;
export declare function stopRestaurantAlarm(order: SavrivoOrder): Promise<void>;
export declare function notifyCustomerStatus(order: SavrivoOrder): Promise<void>;
export declare function notifyRiderOffer(riderId: string, order: SavrivoOrder, expiresAt: number): Promise<void>;
export declare function stopRiderOffers(riderIds: string[], orderId: string, assignedRiderId: string): Promise<void>;
