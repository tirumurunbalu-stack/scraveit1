import { z } from "zod";
export declare const cartLineSchema: z.ZodObject<{
    itemId: z.ZodString;
    quantity: z.ZodNumber;
    variantId: z.ZodOptional<z.ZodString>;
    addOnIds: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
    note: z.ZodDefault<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    itemId: string;
    quantity: number;
    addOnIds: string[];
    note: string;
    variantId?: string | undefined;
}, {
    itemId: string;
    quantity: number;
    variantId?: string | undefined;
    addOnIds?: string[] | undefined;
    note?: string | undefined;
}>;
export declare const createCodOrderSchema: z.ZodObject<{
    idempotencyKey: z.ZodString;
    restaurantId: z.ZodString;
    items: z.ZodArray<z.ZodObject<{
        itemId: z.ZodString;
        quantity: z.ZodNumber;
        variantId: z.ZodOptional<z.ZodString>;
        addOnIds: z.ZodDefault<z.ZodArray<z.ZodString, "many">>;
        note: z.ZodDefault<z.ZodString>;
    }, "strict", z.ZodTypeAny, {
        itemId: string;
        quantity: number;
        addOnIds: string[];
        note: string;
        variantId?: string | undefined;
    }, {
        itemId: string;
        quantity: number;
        variantId?: string | undefined;
        addOnIds?: string[] | undefined;
        note?: string | undefined;
    }>, "many">;
    addressId: z.ZodString;
    couponCode: z.ZodDefault<z.ZodString>;
    tip: z.ZodDefault<z.ZodNumber>;
    deliveryMode: z.ZodDefault<z.ZodLiteral<"asap">>;
    instructions: z.ZodDefault<z.ZodString>;
    contactless: z.ZodDefault<z.ZodBoolean>;
}, "strict", z.ZodTypeAny, {
    restaurantId: string;
    items: {
        itemId: string;
        quantity: number;
        addOnIds: string[];
        note: string;
        variantId?: string | undefined;
    }[];
    instructions: string;
    contactless: boolean;
    idempotencyKey: string;
    deliveryMode: "asap";
    addressId: string;
    couponCode: string;
    tip: number;
}, {
    restaurantId: string;
    items: {
        itemId: string;
        quantity: number;
        variantId?: string | undefined;
        addOnIds?: string[] | undefined;
        note?: string | undefined;
    }[];
    idempotencyKey: string;
    addressId: string;
    instructions?: string | undefined;
    contactless?: boolean | undefined;
    deliveryMode?: "asap" | undefined;
    couponCode?: string | undefined;
    tip?: number | undefined;
}>;
export declare const statusSchema: z.ZodEnum<["Order placed", "Accepted", "Preparing", "Ready for pickup", "Assigned", "Handed to rider", "Out for delivery", "Near you", "Arrived", "Delivered", "Cancelled"]>;
export declare const transitionOrderSchema: z.ZodObject<{
    customerId: z.ZodString;
    orderId: z.ZodString;
    toStatus: z.ZodEnum<["Order placed", "Accepted", "Preparing", "Ready for pickup", "Assigned", "Handed to rider", "Out for delivery", "Near you", "Arrived", "Delivered", "Cancelled"]>;
    reason: z.ZodDefault<z.ZodString>;
    deliveryOtp: z.ZodOptional<z.ZodString>;
    cashCollected: z.ZodDefault<z.ZodBoolean>;
}, "strict", z.ZodTypeAny, {
    orderId: string;
    customerId: string;
    toStatus: "Order placed" | "Accepted" | "Preparing" | "Ready for pickup" | "Assigned" | "Handed to rider" | "Out for delivery" | "Near you" | "Arrived" | "Delivered" | "Cancelled";
    reason: string;
    cashCollected: boolean;
    deliveryOtp?: string | undefined;
}, {
    orderId: string;
    customerId: string;
    toStatus: "Order placed" | "Accepted" | "Preparing" | "Ready for pickup" | "Assigned" | "Handed to rider" | "Out for delivery" | "Near you" | "Arrived" | "Delivered" | "Cancelled";
    deliveryOtp?: string | undefined;
    reason?: string | undefined;
    cashCollected?: boolean | undefined;
}>;
export declare const claimOrderSchema: z.ZodObject<{
    orderId: z.ZodString;
}, "strict", z.ZodTypeAny, {
    orderId: string;
}, {
    orderId: string;
}>;
export declare const initiatePaymentSchema: z.ZodObject<{
    customerId: z.ZodString;
    orderId: z.ZodString;
    provider: z.ZodLiteral<"phonepe">;
}, "strict", z.ZodTypeAny, {
    orderId: string;
    customerId: string;
    provider: "phonepe";
}, {
    orderId: string;
    customerId: string;
    provider: "phonepe";
}>;
export declare const deviceAppSchema: z.ZodEnum<["customer", "restaurant", "rider", "admin"]>;
export declare const devicePlatformSchema: z.ZodEnum<["android", "ios"]>;
export declare const registerDeviceTokenSchema: z.ZodObject<{
    token: z.ZodString;
    app: z.ZodEnum<["customer", "restaurant", "rider", "admin"]>;
    platform: z.ZodEnum<["android", "ios"]>;
    appVersion: z.ZodDefault<z.ZodString>;
    deviceModel: z.ZodDefault<z.ZodString>;
}, "strict", z.ZodTypeAny, {
    token: string;
    app: "customer" | "rider" | "restaurant" | "admin";
    platform: "android" | "ios";
    appVersion: string;
    deviceModel: string;
}, {
    token: string;
    app: "customer" | "rider" | "restaurant" | "admin";
    platform: "android" | "ios";
    appVersion?: string | undefined;
    deviceModel?: string | undefined;
}>;
export declare const unregisterDeviceTokenSchema: z.ZodObject<{
    token: z.ZodString;
}, "strict", z.ZodTypeAny, {
    token: string;
}, {
    token: string;
}>;
export declare function validationMessage(error: z.ZodError): string;
