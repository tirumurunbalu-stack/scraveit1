import { HttpsError, type FunctionsErrorCode } from "firebase-functions/v2/https";
export declare class DomainError extends Error {
    readonly code: FunctionsErrorCode;
    readonly details?: unknown | undefined;
    constructor(code: FunctionsErrorCode, message: string, details?: unknown | undefined);
}
export declare function asHttpsError(error: unknown): HttpsError;
