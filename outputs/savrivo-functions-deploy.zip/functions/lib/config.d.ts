export declare const REGION = "asia-south1";
export declare const ROOT = "feastly";
export declare const SCHEMA_VERSION = 3;
export declare const PRESENCE_FRESH_MS = 90000;
export declare const RIDER_OFFER_SECONDS = 30;
export declare const MAX_RIDER_CANDIDATES = 20;
export declare const MAX_CART_LINES = 50;
export declare const MAX_ITEMS_PER_LINE = 20;
export declare const MAX_DEVICE_TOKENS_PER_USER = 20;
export declare const pathFor: {
    readonly order: (customerId: string, orderId: string) => string;
    readonly restaurantOrder: (restaurantId: string, customerId: string, orderId: string) => string;
    readonly menu: (restaurantId: string) => string;
    readonly restaurant: (restaurantId: string) => string;
    readonly user: (uid: string) => string;
    readonly dispatch: (orderId: string) => string;
};
