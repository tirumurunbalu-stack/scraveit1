import type { SavrivoOrder } from "./types";
export declare const createCodOrder: import("firebase-functions/v2/https").CallableFunction<any, Promise<{
    orderId: string;
    order: SavrivoOrder;
    deliveryOtp: string;
    recovered: boolean;
}>, unknown>;
export declare const updateOrderStatus: import("firebase-functions/v2/https").CallableFunction<any, Promise<{
    orderId: string;
    status: import("./types").OrderStatus;
    updatedAt: number;
}>, unknown>;
export declare const claimRiderOrder: import("firebase-functions/v2/https").CallableFunction<any, Promise<{
    orderId: string;
    status: import("./types").OrderStatus;
    riderId: string | undefined;
}>, unknown>;
export declare const registerPushToken: import("firebase-functions/v2/https").CallableFunction<any, Promise<{
    tokenId: string;
    updatedAt: number;
}>, unknown>;
export declare const unregisterPushToken: import("firebase-functions/v2/https").CallableFunction<any, Promise<{
    removed: boolean;
}>, unknown>;
export declare const createPhonePeIntent: import("firebase-functions/v2/https").CallableFunction<any, Promise<import("./services/payments").PaymentIntent>, unknown>;
export declare const phonePeWebhook: import("firebase-functions/v2/https").HttpsFunction;
export declare const dispatchOfferTimeout: import("firebase-functions/v2/tasks").TaskQueueFunction<any>;
export declare const onOrderCreated: import("firebase-functions").CloudFunction<import("firebase-functions/v2/database").DatabaseEvent<import("firebase-functions/v2/database").DataSnapshot, {
    orderId: string;
    customerId: string;
}>>;
export declare const onOrderUpdated: import("firebase-functions").CloudFunction<import("firebase-functions/v2/database").DatabaseEvent<import("firebase-functions").Change<import("firebase-functions/v2/database").DataSnapshot>, {
    orderId: string;
    customerId: string;
}>>;
export declare const onRiderPresenceUpdated: import("firebase-functions").CloudFunction<import("firebase-functions/v2/database").DatabaseEvent<import("firebase-functions").Change<import("firebase-functions/v2/database").DataSnapshot>, {
    riderId: string;
}>>;
export declare const onTrackingUpdated: import("firebase-functions").CloudFunction<import("firebase-functions/v2/database").DatabaseEvent<import("firebase-functions").Change<import("firebase-functions/v2/database").DataSnapshot>, {
    orderId: string;
}>>;
