export declare const db: import("firebase-admin/database").Database;
export declare const messaging: import("firebase-admin/messaging").Messaging;
export declare const storage: import("firebase-admin/storage").Storage;
