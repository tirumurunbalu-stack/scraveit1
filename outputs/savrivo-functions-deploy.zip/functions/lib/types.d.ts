export type ActorRole = "customer" | "staff" | "owner" | "ops_admin" | "rider" | "system";
export type OrderStatus = "Order placed" | "Accepted" | "Preparing" | "Ready for pickup" | "Assigned" | "Handed to rider" | "Out for delivery" | "Near you" | "Arrived" | "Delivered" | "Cancelled";
export interface GeoPoint {
    lat: number;
    lng: number;
}
export interface Address extends GeoPoint {
    id: string;
    label: string;
    area: string;
    address: string;
    phone: string;
    source: "gps" | "manual";
    updatedAt: number;
    details?: string;
    city?: string;
}
export interface CatalogChoice {
    id?: string;
    name: string;
    price?: number;
    priceDelta?: number;
    available?: boolean;
}
export interface CatalogItem {
    id: string;
    name: string;
    price: number;
    diet?: string;
    available?: boolean;
    archived?: boolean;
    variants?: CatalogChoice[] | Record<string, CatalogChoice>;
    addOns?: CatalogChoice[] | Record<string, CatalogChoice>;
}
export interface CatalogRestaurant extends GeoPoint {
    id: string;
    name: string;
    address: string;
    open: boolean;
    archived: boolean;
    deliveryFee: number;
    platformFee?: number;
    etaMin: number;
    etaMax: number;
    menu?: CatalogItem[] | Record<string, CatalogItem>;
}
export interface CartSelection {
    itemId: string;
    quantity: number;
    variantId?: string;
    addOnIds?: string[];
    note?: string;
}
export interface PricedOrderItem {
    itemId: string;
    name: string;
    quantity: number;
    price: number;
    variant: string;
    variantPrice: number;
    addOns: Array<{
        name: string;
        price: number;
    }>;
    addOnTotal: number;
    note: string;
    diet: string;
}
export interface PricingBreakdown {
    subtotal: number;
    discount: number;
    deliveryFee: number;
    smallOrderFee: number;
    lateNightFee: number;
    rainFee: number;
    surgeFee: number;
    platformFee: number;
    tax: number;
    tip: number;
    currency: "INR";
    source: "catalog_snapshot_v3";
}
export interface StatusEvent {
    status: OrderStatus;
    at: number;
    actorId: string;
    actorRole: ActorRole;
    detail?: string;
    reason?: string;
    proof?: string;
}
export interface SavrivoOrder {
    id: string;
    schemaVersion: number;
    idempotencyKey: string;
    customerId: string;
    customerName: string;
    customerPhone: string;
    contactProxy?: string;
    restaurantId: string;
    restaurant: string;
    restaurantLocation: {
        address: string;
        lat: number;
        lng: number;
    };
    items: PricedOrderItem[];
    pricing: PricingBreakdown;
    pricingContext: {
        distanceKm: number;
        platformFeeRule: string;
        weatherSeverity: string;
        surgeActiveOrders: number;
        pricedAt: number;
    };
    total: number;
    coupon: string;
    paymentMethod: "cod" | "upi" | "card";
    paymentState: "cash_due" | "pending" | "authorized" | "paid" | "refunded" | "failed";
    deliveryMode: "asap" | "scheduled";
    address: Address;
    instructions: string;
    contactless: boolean;
    status: OrderStatus;
    statusHistory: Record<string, StatusEvent>;
    createdAt: number;
    updatedAt: number;
    etaMin: number;
    etaMax: number;
    riderId?: string;
    riderName?: string;
    deliveredAt?: number;
    cancelReason?: string;
}
export interface AuthzDecision {
    role: ActorRole;
    canTransition: boolean;
}
export interface RiderCandidate {
    riderId: string;
    riderName: string;
    distanceKm: number;
    activeLoad: number;
    score: number;
}
export interface DispatchQueueRecord {
    orderId: string;
    customerId: string;
    restaurantId: string;
    restaurantName: string;
    candidates: RiderCandidate[];
    attempt: number;
    currentOffer?: {
        riderId: string;
        offeredAt: number;
        expiresAt: number;
    };
    claim?: {
        riderId: string;
        claimedAt: number;
    };
    status: "offering" | "assigned" | "exhausted" | "cancelled";
    createdAt: number;
    updatedAt: number;
}
