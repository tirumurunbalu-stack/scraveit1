import type {DecodedIdToken} from "firebase-admin/auth";
import {db} from "../admin";
import {ROOT} from "../config";
import {DomainError} from "../errors";
import type {ActorRole, OrderStatus, SavrivoOrder} from "../types";

interface Membership {
  active?: boolean;
  restaurantId?: string;
  role?: string;
  permissions?: Record<string, boolean>;
}

function privilegedRole(token: DecodedIdToken): ActorRole | undefined {
  return token.savrivoRole === "owner" ? "owner" : token.savrivoRole === "ops_admin" ? "ops_admin" : undefined;
}

function permissionFor(target: OrderStatus): string | undefined {
  if (["Accepted", "Preparing", "Ready for pickup", "Cancelled"].includes(target)) return "orders";
  if (target === "Handed to rider") return "handover";
  return undefined;
}

function membershipAllows(member: Membership | null, restaurantId: string, target: OrderStatus): boolean {
  if (!member || member.active !== true) return false;
  if (member.restaurantId && member.restaurantId !== restaurantId) return false;
  if (["restaurant_owner", "restaurant_manager"].includes(member.role ?? "")) return true;
  const permission = permissionFor(target);
  return permission !== undefined && member.permissions?.[permission] === true;
}

export async function authorizeTransition(
  uid: string,
  token: DecodedIdToken,
  order: SavrivoOrder,
  target: OrderStatus,
): Promise<ActorRole> {
  const privileged = privilegedRole(token);
  if (privileged) return privileged;

  if (order.customerId === uid && target === "Cancelled") return "customer";

  if (order.riderId === uid && ["Out for delivery", "Delivered"].includes(target)) {
    const rider = (await db.ref(`${ROOT}/riders/${uid}/status`).get()).val();
    if (rider === "approved") return "rider";
  }

  const [normalized, legacy] = await Promise.all([
    db.ref(`${ROOT}/restaurantMembers/${order.restaurantId}/${uid}`).get(),
    db.ref(`${ROOT}/staff/${uid}`).get(),
  ]);
  const normalizedMember = normalized.val() as Membership | null;
  const legacyMember = legacy.val() as Membership | null;
  if (membershipAllows(normalizedMember, order.restaurantId, target) ||
      membershipAllows(legacyMember, order.restaurantId, target)) return "staff";

  throw new DomainError("permission-denied", "This account cannot perform that order transition.");
}

export async function requireApprovedRider(uid: string): Promise<Record<string, unknown>> {
  const snapshot = await db.ref(`${ROOT}/riders/${uid}`).get();
  const rider = snapshot.val() as Record<string, unknown> | null;
  if (!rider || rider.status !== "approved") {
    throw new DomainError("permission-denied", "An approved delivery-partner account is required.");
  }
  return rider;
}
