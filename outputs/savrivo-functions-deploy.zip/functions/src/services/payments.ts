import {createHash, timingSafeEqual} from "node:crypto";
import {db} from "../admin";
import {pathFor, ROOT} from "../config";
import {DomainError} from "../errors";
import type {SavrivoOrder} from "../types";
import type {InitiatePaymentInput} from "./serviceTypes";

export interface PaymentIntent {
  provider: "phonepe";
  merchantOrderId: string;
  redirectUrl: string;
  expiresAt: number;
}

export interface VerifiedPaymentEvent {
  verified: true;
  provider: "phonepe";
  merchantOrderId: string;
  providerTransactionId: string;
  amountPaise: number;
  state: "paid" | "failed" | "refunded";
  rawEventHash: string;
}

export type VerificationResult =
  | VerifiedPaymentEvent
  | {verified: false; reason: string};

export interface PaymentGateway {
  readonly provider: "phonepe";
  createIntent(order: SavrivoOrder): Promise<PaymentIntent>;
  verifyWebhook(headers: Record<string, string | undefined>, rawBody: Buffer): Promise<VerificationResult>;
}

/**
 * Fail-closed adapter. Replace only after PhonePe issues production credentials
 * and the exact contracted API/webhook version is confirmed. It deliberately
 * cannot create an intent or return `verified: true`.
 */
export class UnconfiguredPhonePeGateway implements PaymentGateway {
  readonly provider = "phonepe" as const;

  async createIntent(_order: SavrivoOrder): Promise<PaymentIntent> {
    throw new DomainError("failed-precondition", "PhonePe is not configured. COD remains available.");
  }

  async verifyWebhook(_headers: Record<string, string | undefined>, rawBody: Buffer): Promise<VerificationResult> {
    return {
      verified: false,
      reason: rawBody.length ? "PHONEPE_VERIFIER_NOT_CONFIGURED" : "EMPTY_CALLBACK",
    };
  }
}

export async function initiatePayment(
  uid: string,
  input: InitiatePaymentInput,
  gateway: PaymentGateway,
): Promise<PaymentIntent> {
  if (uid !== input.customerId) throw new DomainError("permission-denied", "Payment owner mismatch.");
  const order = (await db.ref(pathFor.order(uid, input.orderId)).get()).val() as SavrivoOrder | null;
  if (!order) throw new DomainError("not-found", "Order not found.");
  if (order.customerId !== uid || order.status !== "Order placed") {
    throw new DomainError("failed-precondition", "Order cannot start an online payment.");
  }
  if (order.paymentState === "paid") throw new DomainError("already-exists", "Order is already paid.");
  if (order.paymentMethod !== "upi" || order.paymentState !== "pending") {
    throw new DomainError("failed-precondition", "This is not a pending UPI order. COD cannot be converted after creation.");
  }

  const intent = await gateway.createIntent(order);
  const attempt = {
    provider: gateway.provider, merchantOrderId: intent.merchantOrderId,
    customerId: uid, orderId: order.id, amountPaise: Math.round(order.total * 100),
    state: "pending", createdAt: Date.now(), expiresAt: intent.expiresAt,
  };
  await db.ref(ROOT).update({
    [`paymentAttempts/${order.id}/${intent.merchantOrderId}`]: attempt,
    [`paymentAttemptsByMerchantOrder/${intent.merchantOrderId}`]: {customerId: uid, orderId: order.id, createdAt: attempt.createdAt},
  });
  return intent;
}

export async function applyVerifiedPayment(event: VerifiedPaymentEvent): Promise<void> {
  if (event.verified !== true) throw new DomainError("permission-denied", "Unverified payment event rejected.");
  const attemptRef = db.ref(`${ROOT}/paymentAttemptsByMerchantOrder/${event.merchantOrderId}`);
  const locator = (await attemptRef.get()).val() as {customerId?: string; orderId?: string} | null;
  if (!locator?.customerId || !locator.orderId) throw new DomainError("not-found", "Payment attempt not found.");
  const orderRef = db.ref(pathFor.order(locator.customerId, locator.orderId));
  const order = (await orderRef.get()).val() as SavrivoOrder | null;
  if (!order) throw new DomainError("not-found", "Payment order not found.");
  if (event.amountPaise !== Math.round(order.total * 100)) {
    throw new DomainError("failed-precondition", "Verified payment amount does not match the order.");
  }
  await db.ref(ROOT).update({
    [`paymentEvents/${event.rawEventHash}`]: {...event, receivedAt: Date.now()},
    [`orders/${order.customerId}/${order.id}/paymentState`]: event.state,
    [`restaurantOrders/${order.restaurantId}/${order.customerId}/${order.id}/paymentState`]: event.state,
    [`orders/${order.customerId}/${order.id}/updatedAt`]: Date.now(),
    [`restaurantOrders/${order.restaurantId}/${order.customerId}/${order.id}/updatedAt`]: Date.now(),
  });
}

export function callbackHash(rawBody: Buffer): string {
  return createHash("sha256").update(rawBody).digest("hex");
}

export function constantTimeStringEqual(left: string, right: string): boolean {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}
