import {logger} from "firebase-functions";
import type {MulticastMessage} from "firebase-admin/messaging";
import {db, messaging} from "../admin";
import {ROOT} from "../config";
import {
  buildRemoveRiderOfferMessage,
  buildRestaurantNewOrderMessage,
  buildRiderOfferMessage,
  buildStopRestaurantAlarmMessage,
} from "../domain/notificationMessages";
import type {OrderStatus, SavrivoOrder} from "../types";

interface DeviceTokenRecord {
  token?: string;
  enabled?: boolean;
  app?: "customer" | "restaurant" | "rider" | "admin";
}

function tokenRecords(value: unknown): Array<{key: string; value: DeviceTokenRecord}> {
  if (!value || typeof value !== "object") return [];
  return Object.entries(value as Record<string, DeviceTokenRecord>)
    .map(([key, record]) => ({key, value: record ?? {}}))
    .filter(({value}) => value.enabled !== false && typeof value.token === "string" && value.token.length > 20);
}

async function tokensForUsers(uids: string[], app?: DeviceTokenRecord["app"]): Promise<Array<{uid: string; key: string; token: string}>> {
  const unique = [...new Set(uids.filter(Boolean))];
  const snapshots = await Promise.all(unique.map((uid) => db.ref(`${ROOT}/deviceTokens/${uid}`).get()));
  return snapshots.flatMap((snapshot, index) => tokenRecords(snapshot.val())
    .filter(({value}) => !app || value.app === app)
    .map(({key, value}) => ({uid: unique[index] ?? "", key, token: String(value.token)})));
}

async function restaurantUserIds(restaurantId: string): Promise<string[]> {
  const [membersSnapshot, legacySnapshot] = await Promise.all([
    db.ref(`${ROOT}/restaurantMembers/${restaurantId}`).get(),
    db.ref(`${ROOT}/staff`).orderByChild("restaurantId").equalTo(restaurantId).get(),
  ]);
  const normalized = membersSnapshot.val() as Record<string, {active?: boolean}> | null;
  const legacy = legacySnapshot.val() as Record<string, {active?: boolean}> | null;
  return [
    ...Object.entries(normalized ?? {}).filter(([, member]) => member.active === true).map(([uid]) => uid),
    ...Object.entries(legacy ?? {}).filter(([, member]) => member.active === true).map(([uid]) => uid),
  ];
}

async function sendToUsers(
  uids: string[],
  message: Omit<MulticastMessage, "tokens">,
  app?: DeviceTokenRecord["app"],
): Promise<void> {
  const records = await tokensForUsers(uids, app);
  for (let offset = 0; offset < records.length; offset += 500) {
    const batch = records.slice(offset, offset + 500);
    const response = await messaging.sendEachForMulticast({...message, tokens: batch.map((entry) => entry.token)});
    const removals: Record<string, null> = {};
    response.responses.forEach((result, index) => {
      const code = result.error?.code;
      if (code === "messaging/registration-token-not-registered" || code === "messaging/invalid-registration-token") {
        const record = batch[index];
        if (record) removals[`${ROOT}/deviceTokens/${record.uid}/${record.key}`] = null;
      }
    });
    if (Object.keys(removals).length) await db.ref().update(removals);
    if (response.failureCount) logger.warn("FCM batch had failures", {failureCount: response.failureCount});
  }
}

function statusCopy(status: OrderStatus, restaurant: string): {title: string; body: string} {
  const copy: Record<OrderStatus, {title: string; body: string}> = {
    "Order placed": {title: "Order placed", body: `${restaurant} received your order.`},
    "Accepted": {title: "Order confirmed", body: `${restaurant} accepted your order.`},
    "Preparing": {title: "Your food is being prepared", body: `${restaurant} has started cooking.`},
    "Ready for pickup": {title: "Order is ready", body: "We are finding a delivery partner."},
    "Assigned": {title: "Delivery partner assigned", body: "Your rider is heading to the restaurant."},
    "Handed to rider": {title: "Order picked up", body: "Your order has left the restaurant."},
    "Out for delivery": {title: "On the way", body: "Track your rider live in Savrivo."},
    "Near you": {title: "Delivery partner is near you", body: "Please be ready to receive your order."},
    "Arrived": {title: "Delivery partner is at your doorstep", body: "Share the delivery OTP only after receiving the order."},
    "Delivered": {title: "Order delivered", body: "Enjoy your meal. You can now rate the restaurant and rider."},
    "Cancelled": {title: "Order cancelled", body: "Open Savrivo for the cancellation details."},
  };
  return copy[status];
}

export async function notifyRestaurantNewOrder(order: SavrivoOrder): Promise<void> {
  const recipients = await restaurantUserIds(order.restaurantId);
  await sendToUsers(recipients, buildRestaurantNewOrderMessage(order), "restaurant");
}

export async function stopRestaurantAlarm(order: SavrivoOrder): Promise<void> {
  const recipients = await restaurantUserIds(order.restaurantId);
  await sendToUsers(recipients, buildStopRestaurantAlarmMessage(order.id), "restaurant");
}

export async function notifyCustomerStatus(order: SavrivoOrder): Promise<void> {
  const copy = statusCopy(order.status, order.restaurant);
  await sendToUsers([order.customerId], {
    notification: copy,
    data: {type: "ORDER_STATUS", orderId: order.id, status: order.status, restaurantId: order.restaurantId},
    android: {priority: "high", notification: {channelId: "customer_orders", sound: "default"}},
    apns: {headers: {"apns-priority": "10"}, payload: {aps: {sound: "default"}}},
  }, "customer");
}

export async function notifyRiderOffer(riderId: string, order: SavrivoOrder, expiresAt: number): Promise<void> {
  await sendToUsers([riderId], buildRiderOfferMessage(order, expiresAt), "rider");
}

export async function stopRiderOffers(riderIds: string[], orderId: string, assignedRiderId: string): Promise<void> {
  await sendToUsers(riderIds, buildRemoveRiderOfferMessage(orderId, assignedRiderId), "rider");
}
