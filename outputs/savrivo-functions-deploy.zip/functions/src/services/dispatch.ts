import {getFunctions} from "firebase-admin/functions";
import {logger} from "firebase-functions";
import {db} from "../admin";
import {
  MAX_RIDER_CANDIDATES,
  pathFor,
  PRESENCE_FRESH_MS,
  REGION,
  RIDER_OFFER_SECONDS,
  ROOT,
} from "../config";
import {canTransition, haversineKm, rankRiders} from "../domain/order";
import {stripPrivateOrderFields} from "../domain/orderSecurity";
import {buildRiderJobProjection} from "../domain/riderJob";
import {buildRestaurantOrderProjection} from "../domain/restaurantOrder";
import {DomainError} from "../errors";
import type {DispatchQueueRecord, RiderCandidate, SavrivoOrder, StatusEvent} from "../types";
import {requireApprovedRider} from "./authz";
import {notifyRiderOffer} from "./notifications";

export interface Presence {
  online?: boolean;
  riderId?: string;
  riderName?: string;
  updatedAt?: number;
  lat?: number;
  lng?: number;
  activeOrderId?: string;
  city?: string;
}

interface RiderProfile {
  status?: string;
  fullName?: string;
}

interface RiderJob {
  status?: string;
}

type QueueWithOfferData = DispatchQueueRecord & {
  active: boolean;
  restaurantAddress: string;
  restaurantLat: number;
  restaurantLng: number;
  approximateDropZone: string;
  itemCount: number;
  payout: number;
  estimatedMinutes: number;
  offeredRiderId?: string;
};

function objectMap<T>(value: unknown): Record<string, T> {
  return value && typeof value === "object" ? value as Record<string, T> : {};
}

function activeLoad(jobs: Record<string, RiderJob> | undefined): number {
  return Object.values(jobs ?? {}).filter((job) => job?.status === "active").length;
}

export function availabilityCityKey(value: unknown): string {
  return String(value ?? "").trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 80) || "unknown";
}

export async function updateRiderAvailabilityIndex(
  riderId: string,
  before: Presence | null,
  after: Presence | null,
): Promise<void> {
  const oldCity = availabilityCityKey(before?.city);
  const newCity = availabilityCityKey(after?.city);
  const updates: Record<string, unknown> = {};
  if (before && (oldCity !== newCity || after?.online !== true)) {
    updates[`${ROOT}/riderAvailabilityByCity/${oldCity}/${riderId}`] = null;
  }
  if (after?.online === true && Number.isFinite(Number(after.lat)) && Number.isFinite(Number(after.lng))) {
    updates[`${ROOT}/riderAvailabilityByCity/${newCity}/${riderId}`] = {
      riderId,
      riderName: String(after.riderName ?? "Savrivo Partner").slice(0, 120),
      city: String(after.city ?? "").slice(0, 120),
      online: true,
      lat: Number(after.lat),
      lng: Number(after.lng),
      updatedAt: Number(after.updatedAt ?? Date.now()),
      ...(after.activeOrderId ? {activeOrderId: String(after.activeOrderId)} : {}),
    };
  }
  if (Object.keys(updates).length) await db.ref().update(updates);
}

async function scheduleTimeout(orderId: string, attempt: number): Promise<void> {
  await getFunctions().taskQueue(`locations/${REGION}/functions/dispatchOfferTimeout`).enqueue(
    {orderId, attempt},
    {scheduleDelaySeconds: RIDER_OFFER_SECONDS},
  );
}

async function candidatesFor(order: SavrivoOrder): Promise<RiderCandidate[]> {
  const cityKey = availabilityCityKey(order.address.city || order.address.area);
  let presenceSnapshot = await db.ref(`${ROOT}/riderAvailabilityByCity/${cityKey}`).limitToFirst(500).get();
  // Compatibility fallback while the index is being populated by rider
  // heartbeats after first deployment. It is hard-capped and should disappear
  // after the rollout/backfill is complete.
  if (!presenceSnapshot.exists()) presenceSnapshot = await db.ref(`${ROOT}/riderPresence`).limitToFirst(500).get();
  const presences = objectMap<Presence>(presenceSnapshot.val());
  const now = Date.now();
  const nearestPresence = Object.entries(presences).flatMap(([riderId, presence]) => {
    const lat = Number(presence?.lat);
    const lng = Number(presence?.lng);
    if (presence?.online !== true || now - Number(presence.updatedAt ?? 0) > PRESENCE_FRESH_MS ||
      !Number.isFinite(lat) || !Number.isFinite(lng) || presence.activeOrderId) return [];
    return [{riderId, presence, distanceKm: haversineKm({lat, lng}, order.restaurantLocation)}];
  }).sort((a, b) => a.distanceKm - b.distanceKm).slice(0, 100);
  const hydrated = await Promise.all(nearestPresence.map(async ({riderId, presence, distanceKm}) => {
    const [profileSnapshot, jobsSnapshot, walletSnapshot] = await Promise.all([
      db.ref(`${ROOT}/riders/${riderId}`).get(),
      db.ref(`${ROOT}/riderJobs/${riderId}`).get(),
      db.ref(`${ROOT}/riderWallets/${riderId}`).get(),
    ]);
    const profile = profileSnapshot.val() as RiderProfile | null;
    const wallet = walletSnapshot.val() as {codBlocked?: boolean; orderBlocked?: boolean} | null;
    const load = activeLoad(objectMap<RiderJob>(jobsSnapshot.val()));
    if (profile?.status !== "approved" || wallet?.codBlocked === true || wallet?.orderBlocked === true || load > 0) return null;
    return {
      riderId,
      riderName: String(profile.fullName ?? presence.riderName ?? "Savrivo Partner"),
      distanceKm,
      activeLoad: load,
    };
  }));
  return rankRiders(hydrated.filter((entry): entry is Omit<RiderCandidate, "score"> => entry !== null))
    .slice(0, MAX_RIDER_CANDIDATES);
}

export async function beginSequentialDispatch(order: SavrivoOrder): Promise<QueueWithOfferData | null> {
  if (order.status !== "Ready for pickup") return null;
  const candidates = await candidatesFor(order);
  const now = Date.now();
  const first = candidates[0];
  const queue: QueueWithOfferData = {
    orderId: order.id,
    customerId: order.customerId,
    restaurantId: order.restaurantId,
    restaurantName: order.restaurant,
    candidates,
    attempt: 0,
    ...(first ? {currentOffer: {riderId: first.riderId, offeredAt: now, expiresAt: now + RIDER_OFFER_SECONDS * 1000}} : {}),
    status: first ? "offering" : "exhausted",
    createdAt: now,
    updatedAt: now,
    active: Boolean(first),
    restaurantAddress: order.restaurantLocation.address,
    restaurantLat: order.restaurantLocation.lat,
    restaurantLng: order.restaurantLocation.lng,
    approximateDropZone: order.address.area || order.address.city || "Service area",
    itemCount: order.items.reduce((sum, item) => sum + item.quantity, 0),
    payout: order.pricing.deliveryFee,
    estimatedMinutes: order.etaMax,
    ...(first ? {offeredRiderId: first.riderId} : {}),
  };
  const ref = db.ref(pathFor.dispatch(order.id));
  const result = await ref.transaction((current: QueueWithOfferData | null) => {
    if (current && ["offering", "assigned"].includes(current.status)) return undefined;
    return queue;
  }, undefined, false);
  const activeQueue = result.snapshot.val() as QueueWithOfferData;
  if (activeQueue?.status === "offering" && activeQueue.currentOffer) {
    // Enqueuing duplicate timeout tasks is safe: each task carries the expected
    // attempt and the queue transaction rejects stale attempts.
    await scheduleTimeout(order.id, activeQueue.attempt);
    if (result.committed && first) {
      await notifyRiderOffer(first.riderId, order, activeQueue.currentOffer.expiresAt)
        .catch((error) => logger.error("Initial rider offer notification failed", {orderId: order.id, riderId: first.riderId, error}));
    }
  }
  return activeQueue;
}

export async function advanceDispatchOffer(orderId: string, expectedAttempt: number): Promise<void> {
  const ref = db.ref(pathFor.dispatch(orderId));
  let nextRider: RiderCandidate | undefined;
  let nextAttempt = expectedAttempt;
  const result = await ref.transaction((current: QueueWithOfferData | null) => {
    if (!current || current.status !== "offering" || current.claim || current.attempt !== expectedAttempt ||
      !current.currentOffer || current.currentOffer.expiresAt > Date.now()) return undefined;
    nextAttempt = expectedAttempt + 1;
    nextRider = current.candidates[nextAttempt];
    const now = Date.now();
    if (!nextRider) {
      const {currentOffer: _offer, offeredRiderId: _offered, ...rest} = current;
      return {...rest, status: "exhausted", active: false, attempt: nextAttempt, updatedAt: now};
    }
    return {
      ...current,
      attempt: nextAttempt,
      currentOffer: {riderId: nextRider.riderId, offeredAt: now, expiresAt: now + RIDER_OFFER_SECONDS * 1000},
      offeredRiderId: nextRider.riderId,
      updatedAt: now,
    };
  }, undefined, false);
  if (!result.committed || !nextRider) return;
  const queue = result.snapshot.val() as QueueWithOfferData;
  const order = (await db.ref(pathFor.order(queue.customerId, orderId)).get()).val() as SavrivoOrder | null;
  if (!order || order.status !== "Ready for pickup") {
    await ref.update({status: "cancelled", active: false, updatedAt: Date.now()});
    return;
  }
  await scheduleTimeout(orderId, nextAttempt);
  await notifyRiderOffer(nextRider.riderId, order, queue.currentOffer!.expiresAt)
    .catch((error) => logger.error("Rider offer notification failed", {orderId, riderId: nextRider?.riderId, error}));
}

export async function claimDispatchOffer(uid: string, orderId: string): Promise<SavrivoOrder> {
  const rider = await requireApprovedRider(uid);
  const [presenceSnapshot, walletSnapshot] = await Promise.all([
    db.ref(`${ROOT}/riderPresence/${uid}`).get(),
    db.ref(`${ROOT}/riderWallets/${uid}`).get(),
  ]);
  const presence = presenceSnapshot.val() as Presence | null;
  const wallet = walletSnapshot.val() as {codBlocked?: boolean; orderBlocked?: boolean} | null;
  if (wallet?.codBlocked === true || wallet?.orderBlocked === true) {
    throw new DomainError("failed-precondition", "Resolve the rider account hold before accepting another order.");
  }
  if (!presence || presence.online !== true || Date.now() - Number(presence.updatedAt ?? 0) > PRESENCE_FRESH_MS) {
    throw new DomainError("failed-precondition", "Go online with current location before accepting an order.");
  }
  if (!Number.isFinite(Number(presence.lat)) || !Number.isFinite(Number(presence.lng))) {
    throw new DomainError("failed-precondition", "A current rider location is required to accept this order.");
  }
  const queueRef = db.ref(pathFor.dispatch(orderId));
  const claimAt = Date.now();
  const queueResult = await queueRef.transaction((current: QueueWithOfferData | null) => {
    if (!current || current.status !== "offering" || current.claim ||
      current.currentOffer?.riderId !== uid || current.currentOffer.expiresAt < claimAt) return undefined;
    return {...current, claim: {riderId: uid, claimedAt: claimAt}, updatedAt: claimAt};
  }, undefined, false);
  if (!queueResult.committed) throw new DomainError("aborted", "This delivery offer is no longer available.");
  const queue = queueResult.snapshot.val() as QueueWithOfferData;
  const orderRef = db.ref(pathFor.order(queue.customerId, orderId));
  const before = (await orderRef.get()).val() as SavrivoOrder | null;
  if (!before || !canTransition(before.status, "Assigned", "rider")) {
    await queueRef.transaction((current: QueueWithOfferData | null) => current?.claim?.riderId === uid ? {...current, claim: null} : undefined);
    throw new DomainError("failed-precondition", "Order is no longer ready for assignment.");
  }
  const event: StatusEvent = {status: "Assigned", at: claimAt, actorId: uid, actorRole: "rider"};
  const eventId = `e_${claimAt}_${uid.replace(/[^A-Za-z0-9_-]/g, "").slice(0, 30)}`;
  const orderResult = await orderRef.transaction((current: SavrivoOrder | null) => {
    if (!current || current.status !== "Ready for pickup" || current.riderId) return undefined;
    return {
      ...stripPrivateOrderFields(current),
      riderId: uid,
      riderName: String(rider.fullName ?? presence.riderName ?? "Savrivo Partner"),
      status: "Assigned",
      updatedAt: claimAt,
      statusHistory: {...(current.statusHistory ?? {}), [eventId]: event},
    };
  }, undefined, false);
  if (!orderResult.committed) {
    await queueRef.transaction((current: QueueWithOfferData | null) => current?.claim?.riderId === uid ? {...current, claim: null} : undefined);
    throw new DomainError("aborted", "Another rider secured this order.");
  }
  const order = stripPrivateOrderFields(orderResult.snapshot.val() as SavrivoOrder);
  await db.ref(ROOT).update({
    [`restaurantOrders/${order.restaurantId}/${order.customerId}/${order.id}`]: buildRestaurantOrderProjection(order),
    [`dispatchQueue/${order.id}/status`]: "assigned",
    [`dispatchQueue/${order.id}/active`]: false,
    [`dispatchQueue/${order.id}/updatedAt`]: claimAt,
    [`riderJobs/${uid}/${order.id}`]: buildRiderJobProjection(order),
    [`riderPresence/${uid}/activeOrderId`]: order.id,
  });
  return order;
}
