import {stripPrivateOrderFields} from "./orderSecurity";
import type {SavrivoOrder} from "../types";

export type RestaurantOrderProjection = Omit<SavrivoOrder, "customerPhone" | "address"> & {
  address: {label: string; area: string; city?: string};
};

/** Restaurant operations need the order, not a customer's phone or drop pin. */
export function buildRestaurantOrderProjection(order: SavrivoOrder): RestaurantOrderProjection {
  const clean = stripPrivateOrderFields(order);
  const {customerPhone: _phone, address, ...rest} = clean;
  return {
    ...rest,
    address: {
      label: address.label,
      area: address.area,
      ...(address.city ? {city: address.city} : {}),
    },
  };
}
