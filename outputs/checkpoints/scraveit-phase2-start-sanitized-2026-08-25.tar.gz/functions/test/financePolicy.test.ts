import {describe, expect, it} from "vitest";
import {
  DEFAULT_COD_OUTSTANDING_LIMIT_PAISE,
  DEFAULT_FINANCE_POLICY,
  normalizeFinancePolicy,
} from "../src/domain/financePolicy";

describe("finance policy", () => {
  it("preserves the 15% commission and defaults COD exposure to a finite INR 5,000", () => {
    expect(normalizeFinancePolicy(null)).toEqual(DEFAULT_FINANCE_POLICY);
    expect(DEFAULT_FINANCE_POLICY.codOutstandingLimitPaise).toBe(DEFAULT_COD_OUTSTANDING_LIMIT_PAISE);
    expect(DEFAULT_COD_OUTSTANDING_LIMIT_PAISE).toBe(500_000);
  });

  it("normalizes backend-controlled values and rejects dangerous ranges", () => {
    expect(normalizeFinancePolicy({restaurantCommissionBps: 1_250, codOutstandingLimitPaise: 500_000}))
      .toMatchObject({restaurantCommissionBps: 1_250, codOutstandingLimitPaise: 500_000});
    expect(normalizeFinancePolicy({restaurantCommissionBps: 99_999, codOutstandingLimitPaise: -1}))
      .toMatchObject({restaurantCommissionBps: 5_000, codOutstandingLimitPaise: 0});
    expect(normalizeFinancePolicy({codOutstandingLimitPaise: 0}))
      .toMatchObject({codOutstandingLimitPaise: 0});
  });
});
