import {createHash} from "node:crypto";
import {z} from "zod";
import {
  normalizeDispatchPolicy,
  type DispatchPolicy,
} from "./dispatchPolicy";
import {
  normalizeFinancePolicy,
  type FinancePolicy,
} from "./financePolicy";

const dispatchPatchSchema = z.object({
  mode: z.enum(["sequential", "waves"]).optional(),
  initialRadiusKm: z.number().finite().min(0.25).max(100).optional(),
  radiusExpansionKm: z.number().finite().min(0).max(50).optional(),
  maxRadiusKm: z.number().finite().min(1).max(100).optional(),
  offerTimeoutSeconds: z.number().int().min(15).max(300).optional(),
  ridersPerWave: z.number().int().min(1).max(10).optional(),
  maxWaves: z.number().int().min(1).max(50).optional(),
  maxCandidates: z.number().int().min(1).max(100).optional(),
  presenceFreshMs: z.number().int().min(15_000).max(300_000).optional(),
  maxLocationAccuracyMeters: z.number().finite().min(10).max(500).optional(),
  reofferCooldownMs: z.number().int().min(30_000).max(24 * 60 * 60_000).optional(),
  fairnessLoadPenaltyKm: z.number().finite().min(0).max(100).optional(),
  claimLeaseSeconds: z.number().int().min(15).max(300).optional(),
}).strict().refine((value) => Object.keys(value).length > 0, "Dispatch patch cannot be empty.");

const financePatchSchema = z.object({
  restaurantCommissionBps: z.number().int().min(0).max(5_000).optional(),
  codOutstandingLimitPaise: z.number().int().min(0).max(10_000_000_00).optional(),
}).strict().refine((value) => Object.keys(value).length > 0, "Finance patch cannot be empty.");

export const updatePlatformConfigSchema = z.object({
  operationId: z.string().trim().min(8).max(128)
    .regex(/^[A-Za-z0-9][A-Za-z0-9._:-]*$/, "Operation id contains unsupported characters."),
  expectedRevision: z.number().int().min(0).max(Number.MAX_SAFE_INTEGER).optional(),
  dispatch: dispatchPatchSchema.optional(),
  finance: financePatchSchema.optional(),
}).strict().refine((value) => value.dispatch !== undefined || value.finance !== undefined, {
  message: "At least one policy section is required.",
});

export type UpdatePlatformConfigInput = z.infer<typeof updatePlatformConfigSchema>;

export interface PlatformConfigState {
  dispatch: DispatchPolicy;
  finance: FinancePolicy;
  revision: number;
  updatedAt: number;
  updatedBy: string;
  updatedByRole: "owner" | "ops_admin" | "";
}

type UnknownRecord = Record<string, unknown>;

function record(value: unknown): UnknownRecord {
  return value && typeof value === "object" && !Array.isArray(value) ? value as UnknownRecord : {};
}

function safeNonNegativeInteger(value: unknown): number {
  const parsed = Number(value);
  return Number.isSafeInteger(parsed) && parsed >= 0 ? parsed : 0;
}

/** Reads persisted config defensively; malformed values fall back through the
 * same safe normalizers used by runtime dispatch and finance code. */
export function platformConfigState(value: unknown): PlatformConfigState {
  const root = record(value);
  const metadata = record(root._meta);
  const updatedByRole = metadata.updatedByRole === "owner" || metadata.updatedByRole === "ops_admin"
    ? metadata.updatedByRole
    : "";
  return {
    dispatch: normalizeDispatchPolicy(root.dispatch),
    finance: normalizeFinancePolicy(root.finance),
    revision: safeNonNegativeInteger(metadata.revision),
    updatedAt: safeNonNegativeInteger(metadata.updatedAt),
    updatedBy: typeof metadata.updatedBy === "string" ? metadata.updatedBy.slice(0, 128) : "",
    updatedByRole,
  };
}

/** Applies a strictly validated partial update and returns complete canonical
 * policies. Cross-field checks reject unsafe operator mistakes rather than
 * silently storing a surprising configuration. */
export function applyPlatformConfigPatch(
  current: PlatformConfigState,
  input: UpdatePlatformConfigInput,
): Pick<PlatformConfigState, "dispatch" | "finance"> {
  const rawDispatch = {...current.dispatch, ...(input.dispatch ?? {})};
  if (rawDispatch.mode === "sequential" && input.dispatch?.radiusExpansionKm !== undefined &&
      input.dispatch.radiusExpansionKm !== 0) {
    throw new Error("DISPATCH_SEQUENTIAL_RADIUS_EXPANSION_MUST_BE_ZERO");
  }
  if (rawDispatch.mode === "sequential" && input.dispatch?.ridersPerWave !== undefined &&
      input.dispatch.ridersPerWave !== 1) {
    throw new Error("DISPATCH_SEQUENTIAL_RIDERS_PER_WAVE_MUST_BE_ONE");
  }
  if (rawDispatch.mode === "waves" && input.dispatch?.radiusExpansionKm === 0) {
    throw new Error("DISPATCH_WAVE_RADIUS_EXPANSION_REQUIRED");
  }
  if (rawDispatch.initialRadiusKm > rawDispatch.maxRadiusKm) {
    throw new Error("DISPATCH_INITIAL_RADIUS_EXCEEDS_MAXIMUM");
  }
  if (rawDispatch.ridersPerWave > rawDispatch.maxCandidates) {
    throw new Error("DISPATCH_RIDERS_PER_WAVE_EXCEEDS_MAX_CANDIDATES");
  }
  return {
    dispatch: normalizeDispatchPolicy(rawDispatch),
    finance: normalizeFinancePolicy({...current.finance, ...(input.finance ?? {})}),
  };
}

function canonical(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonical).join(",")}]`;
  if (value && typeof value === "object") {
    const source = value as UnknownRecord;
    return `{${Object.keys(source).sort().map((key) => `${JSON.stringify(key)}:${canonical(source[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}

export function platformConfigHash(value: unknown): string {
  return createHash("sha256").update(canonical(value)).digest("hex");
}

export function platformConfigOperationKey(operationId: string): string {
  return platformConfigHash(operationId);
}
