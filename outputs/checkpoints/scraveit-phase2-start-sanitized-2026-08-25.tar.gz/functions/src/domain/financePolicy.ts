export interface FinancePolicy {
  version: 1;
  /** 1,500 basis points = 15%. */
  restaurantCommissionBps: number;
  /** Zero is an explicit owner override; production defaults to a finite exposure limit. */
  codOutstandingLimitPaise: number;
}

/** Conservative initial exposure ceiling: INR 5,000 per rider. Operations can
 * change it through the existing custom-claim guarded platform configuration
 * control plane without an application release. */
export const DEFAULT_COD_OUTSTANDING_LIMIT_PAISE = 500_000;

export const DEFAULT_FINANCE_POLICY: Readonly<FinancePolicy> = Object.freeze({
  version: 1,
  restaurantCommissionBps: 1_500,
  codOutstandingLimitPaise: DEFAULT_COD_OUTSTANDING_LIMIT_PAISE,
});

function record(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function boundedInteger(value: unknown, fallback: number, minimum: number, maximum: number): number {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? Math.round(Math.min(maximum, Math.max(minimum, parsed))) : fallback;
}

export function normalizeFinancePolicy(value: unknown): FinancePolicy {
  const input = record(value);
  return {
    version: 1,
    restaurantCommissionBps: boundedInteger(
      input.restaurantCommissionBps,
      DEFAULT_FINANCE_POLICY.restaurantCommissionBps,
      0,
      5_000,
    ),
    codOutstandingLimitPaise: boundedInteger(
      input.codOutstandingLimitPaise,
      DEFAULT_FINANCE_POLICY.codOutstandingLimitPaise,
      0,
      10_000_000_00,
    ),
  };
}
