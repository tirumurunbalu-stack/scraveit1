import type {SavrivoOrder} from "../types";

type ExistingRiderJob = Record<string, unknown> | null | undefined;

function assignedAt(order: SavrivoOrder): number {
  if (Number.isFinite(Number(order.riderAssignedAt))) return Number(order.riderAssignedAt);
  const events = Object.values(order.statusHistory ?? {}).filter((event) => event?.status === "Assigned");
  return events.reduce((earliest, event) => Math.min(earliest, Number(event.at) || earliest), order.createdAt);
}

function phaseFor(order: SavrivoOrder, existing: ExistingRiderJob): string {
  if (order.status === "Delivered" || order.status === "Cancelled") return "complete";
  if (order.status === "Arrived") return "arrived";
  if (["Out for delivery", "Near you"].includes(order.status)) return "delivery";
  if (order.status === "Assigned" && existing?.phase === "at_restaurant") return "at_restaurant";
  return "pickup";
}

export function riderMaySeeDropDetails(order: SavrivoOrder): boolean {
  return Boolean(order.riderId) && ["Accepted", "Preparing", "Ready for pickup", "Assigned", "Handed to rider", "Out for delivery", "Near you", "Arrived"].includes(order.status);
}

function riderMaySeeCustomerContact(order: SavrivoOrder): boolean {
  return ["Handed to rider", "Out for delivery", "Near you", "Arrived"].includes(order.status);
}

/** Minimum backend-owned projection; customer contact unlocks only after handover. */
export function buildRiderJobProjection(
  order: SavrivoOrder,
  existing?: ExistingRiderJob,
): Record<string, unknown> {
  const status = order.status === "Delivered" ? "completed" : order.status === "Cancelled" ? "cancelled" : "active";
  const riderFacingStatus = order.riderId && ["Accepted", "Preparing", "Ready for pickup"].includes(order.status)
    ? "Assigned" : order.status;
  const projection: Record<string, unknown> = {
    orderId: order.id,
    customerId: order.customerId,
    restaurantId: order.restaurantId,
    restaurantName: order.restaurant,
    restaurantAddress: order.restaurantLocation.address,
    restaurantLat: order.restaurantLocation.lat,
    restaurantLng: order.restaurantLocation.lng,
    approximateDropZone: order.address.area || order.address.city || "Service area",
    itemCount: order.items.reduce((sum, item) => sum + item.quantity, 0),
    payout: order.pricing.deliveryFee,
    estimatedMinutes: order.etaMax,
    assignedAt: assignedAt(order),
    createdAt: assignedAt(order),
    updatedAt: order.updatedAt,
    orderStatus: riderFacingStatus,
    kitchenStatus: order.status,
    status,
    phase: phaseFor(order, existing),
  };
  if (order.restaurantPhone) projection.restaurantPhone = order.restaurantPhone;
  if (Number.isFinite(Number(existing?.arrivedRestaurantAt))) {
    projection.arrivedRestaurantAt = Number(existing?.arrivedRestaurantAt);
  }
  if (order.status === "Delivered") projection.completedAt = order.deliveredAt ?? order.updatedAt;
  if (riderMaySeeDropDetails(order)) {
    projection.customerName = order.customerName;
    projection.address = {
      label: order.address.label,
      area: order.address.area,
      address: order.address.address,
      lat: order.address.lat,
      lng: order.address.lng,
      ...(order.address.details ? {details: order.address.details} : {}),
      ...(order.address.city ? {city: order.address.city} : {}),
    };
  }
  if (riderMaySeeCustomerContact(order)) {
    projection.customerPhone = order.customerPhone;
    projection.items = order.items;
    projection.instructions = order.instructions;
    projection.contactless = order.contactless;
    projection.total = order.total;
    projection.paymentMethod = order.paymentMethod;
    projection.pricing = {
      deliveryFee: order.pricing.deliveryFee,
      tip: order.pricing.tip,
    };
    projection.otpRequired = true;
    if (order.contactProxy) projection.contactProxy = order.contactProxy;
  }
  return projection;
}
