import {z} from "zod";
import {MAX_CART_LINES, MAX_ITEMS_PER_LINE} from "./config";

const identifier = z.string().trim().min(1).max(120).regex(/^[A-Za-z0-9_.:-]+$/);

export const cartLineSchema = z.object({
  itemId: identifier,
  quantity: z.number().int().min(1).max(MAX_ITEMS_PER_LINE),
  variantId: z.string().trim().max(100).optional(),
  addOnIds: z.array(z.string().trim().min(1).max(100)).max(20).default([]),
  note: z.string().trim().max(200).default(""),
}).strict();

export const createCodOrderSchema = z.object({
  idempotencyKey: z.string().trim().min(16).max(80).regex(/^[A-Za-z0-9_-]+$/),
  restaurantId: identifier,
  items: z.array(cartLineSchema).min(1).max(MAX_CART_LINES),
  addressId: identifier,
  couponCode: z.string().trim().toUpperCase().max(30).default(""),
  tip: z.number().finite().min(0).max(10_000).default(0),
  deliveryMode: z.literal("asap").default("asap"),
  instructions: z.string().trim().max(500).default(""),
  contactless: z.boolean().default(false),
}).strict();

export const recoverDeliveryOtpSchema = z.object({
  orderId: identifier,
}).strict();

export const statusSchema = z.enum([
  "Order placed",
  "Accepted",
  "Preparing",
  "Ready for pickup",
  "Assigned",
  "Handed to rider",
  "Out for delivery",
  "Near you",
  "Arrived",
  "Delivered",
  "Cancelled",
]);

export const transitionOrderSchema = z.object({
  customerId: identifier,
  orderId: identifier,
  toStatus: statusSchema,
  reason: z.string().trim().max(500).default(""),
  deliveryOtp: z.string().trim().regex(/^\d{4,6}$/).optional(),
  cashCollected: z.boolean().default(false),
}).strict();

export const claimOrderSchema = z.object({
  orderId: identifier,
}).strict();

export const declineOrderSchema = claimOrderSchema;

export const initiatePaymentSchema = z.object({
  customerId: identifier,
  orderId: identifier,
  provider: z.literal("phonepe"),
}).strict();

/**
 * An operator-supplied idempotency key is mandatory because a COD deposit may
 * be retried after the wallet reservation or immutable ledger write succeeds.
 * Amounts are integer paise; no floating-point rupee value crosses this API.
 */
export const recordCodRemittanceSchema = z.object({
  operationId: z.string().trim().min(16).max(128)
    .regex(/^[A-Za-z0-9][A-Za-z0-9._:-]*$/, "Operation id contains unsupported characters."),
  riderId: identifier,
  amountPaise: z.number().int().positive().max(1_000_000_000),
  method: z.enum(["cash_deposit", "bank_transfer", "upi"]),
  referenceId: z.string().trim().min(1).max(120)
    .regex(/^[A-Za-z0-9][A-Za-z0-9._:/-]*$/, "Reference id contains unsupported characters.")
    .optional(),
}).strict().superRefine((value, context) => {
  if (value.method !== "cash_deposit" && !value.referenceId) {
    context.addIssue({
      code: z.ZodIssueCode.custom,
      path: ["referenceId"],
      message: "A bank or UPI reference id is required for electronic remittance.",
    });
  }
});

export type RecordCodRemittanceInput = z.infer<typeof recordCodRemittanceSchema>;

export const deviceAppSchema = z.enum(["customer", "restaurant", "rider", "admin"]);
export const devicePlatformSchema = z.enum(["android", "ios"]);

export const registerDeviceTokenSchema = z.object({
  token: z.string().trim().min(20).max(4096),
  app: deviceAppSchema,
  platform: devicePlatformSchema,
  appVersion: z.string().trim().max(40).default(""),
  deviceModel: z.string().trim().max(120).default(""),
}).strict();

export const unregisterDeviceTokenSchema = z.object({
  token: z.string().trim().min(20).max(4096),
}).strict();

export function validationMessage(error: z.ZodError): string {
  return error.issues.map((issue) => `${issue.path.join(".") || "input"}: ${issue.message}`).join("; ");
}
