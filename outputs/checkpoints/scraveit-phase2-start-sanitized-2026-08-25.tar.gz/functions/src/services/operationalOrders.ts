import {logger} from "firebase-functions";
import {db} from "../admin";
import {ROOT} from "../config";
import {
  buildOperationalOrderProjection,
  shouldApplyOperationalOrderProjection,
  type OperationalOrderProjection,
} from "../domain/operationalOrders";
import type {SavrivoOrder} from "../types";

export const OPERATIONAL_ORDERS_ROOT = `${ROOT}/private/operations/orders`;
export const OPERATIONAL_ORDERS_MAX_PAGE = 250;

function pageSize(value: unknown): number {
  const size = Number(value);
  return Number.isInteger(size) ? Math.max(1, Math.min(OPERATIONAL_ORDERS_MAX_PAGE, size)) : 100;
}

export async function reconcileOperationalOrderProjection(
  order: SavrivoOrder,
): Promise<OperationalOrderProjection> {
  const next = buildOperationalOrderProjection(order);
  const result = await db.ref(`${OPERATIONAL_ORDERS_ROOT}/${order.id}`).transaction(
    (current: OperationalOrderProjection | null) =>
      shouldApplyOperationalOrderProjection(current, next) ? next : undefined,
    undefined,
    false,
  );
  if (!result.committed) {
    logger.info("STALE_OPERATIONAL_ORDER_PROJECTION_IGNORED", {
      orderId: order.id,
      status: order.status,
      updatedAt: order.updatedAt,
    });
  }
  return (result.snapshot.val() as OperationalOrderProjection | null) ?? next;
}

function projectionValues(value: unknown): OperationalOrderProjection[] {
  if (!value || typeof value !== "object") return [];
  return Object.values(value as Record<string, OperationalOrderProjection>)
    .filter((entry) => entry?.source === "functions" && entry.version === 1);
}

/**
 * Bounded query foundation for a future callable/admin API. Do not expose the
 * private node directly to clients. Production adoption requires the matching
 * `.indexOn` entries listed in the rollout report.
 */
export async function listActiveOperationalOrders(limit = 100): Promise<OperationalOrderProjection[]> {
  const snapshot = await db.ref(OPERATIONAL_ORDERS_ROOT)
    .orderByChild("activeSortKey")
    .startAt("active:")
    .endAt("active:\uf8ff")
    .limitToLast(pageSize(limit))
    .get();
  return projectionValues(snapshot.val()).filter((entry) => entry.active).sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function listRecentOperationalOrders(limit = 100): Promise<OperationalOrderProjection[]> {
  const snapshot = await db.ref(OPERATIONAL_ORDERS_ROOT)
    .orderByChild("recentSortKey")
    .startAt("recent:")
    .endAt("recent:\uf8ff")
    .limitToLast(pageSize(limit))
    .get();
  return projectionValues(snapshot.val()).filter((entry) => !entry.active).sort((a, b) => b.updatedAt - a.updatedAt);
}
