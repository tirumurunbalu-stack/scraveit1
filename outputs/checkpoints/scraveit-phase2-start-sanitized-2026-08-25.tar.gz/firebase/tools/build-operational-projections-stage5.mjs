#!/usr/bin/env node

import {readFileSync, writeFileSync} from "node:fs";
import {dirname, join, resolve} from "node:path";
import {fileURLToPath} from "node:url";

const toolDirectory = dirname(fileURLToPath(import.meta.url));
const firebaseDirectory = resolve(toolDirectory, "..");

export const stage4Path = join(firebaseDirectory, "feastly-realtime-database-rules.server-authority-stage4.json");
export const stage5Path = join(firebaseDirectory, "feastly-realtime-database-rules.operational-projections-stage5.json");

export const OPERATIONAL_ORDER_INDEXES = Object.freeze(["activeSortKey", "recentSortKey"]);
export const OPERATIONAL_ORDER_RULE_PATH = Object.freeze([
  "rules",
  "feastly",
  "private",
  "operations",
  "orders",
]);

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

export function normalizeIndexOn(value) {
  if (value == null) return [];
  if (typeof value === "string") return [value];
  if (Array.isArray(value) && value.every((entry) => typeof entry === "string")) return [...value];
  throw new Error("Unexpected .indexOn shape in staged rules.");
}

function ensureObjectPath(root, path) {
  return path.reduce((node, segment) => {
    if (!Object.hasOwn(node, segment)) node[segment] = {};
    if (!node[segment] || typeof node[segment] !== "object" || Array.isArray(node[segment])) {
      throw new Error(`Rules path is not an object: ${path.join("/")}`);
    }
    return node[segment];
  }, root);
}

/**
 * Add only the indexes used by the bounded private operational-order queries.
 * Stage 4 already makes /feastly/private server-only, so this transformation
 * changes query planning without granting any client read or write access.
 */
export function addOperationalProjectionIndexes(source) {
  const result = clone(source);
  const orders = ensureObjectPath(result, OPERATIONAL_ORDER_RULE_PATH);
  orders[".indexOn"] = [...new Set([
    ...normalizeIndexOn(orders[".indexOn"]),
    ...OPERATIONAL_ORDER_INDEXES,
  ])].sort();
  return result;
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const stage4 = JSON.parse(readFileSync(stage4Path, "utf8"));
  const stage5 = addOperationalProjectionIndexes(stage4);
  writeFileSync(stage5Path, `${JSON.stringify(stage5, null, 2)}\n`, {encoding: "utf8", mode: 0o644});
  console.log("Generated operational-projections stage 5 from server-authority stage 4 (active rules/config unchanged).");
}
