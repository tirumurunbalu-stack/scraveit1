# Savrivo 3.1 developer build — install and test

Savrivo is now split into **four Android apps** over the same Firebase project:

1. **Savrivo Customer** — discovery, ordering, addresses and live tracking.
2. **Savrivo Admin** — Savrivo platform-owner operations, approvals and overrides.
3. **Savrivo Restaurant** — restaurant owner/manager/staff daily operations.
4. **Savrivo Partner** — rider onboarding, delivery workflow, navigation and live location.

All modules target Android API 36 and Android 6.0+ (min API 23).

## Build on the development Mac

Install these pinned prerequisites in Android Studio's SDK Manager:

- Android SDK Platform 36;
- Android SDK Build Tools 36.0.0;
- a JDK from 17 through 25 (the current Android Studio bundled JDK is supported).

From the repository root:

```sh
native_android/tests/run.sh
native_android/build_savrivo.sh
```

The script delegates to the pinned Gradle wrapper and produces debug-signed APKs for all four apps. To run release lint and additionally build optimized release bundles:

```sh
native_android/build_savrivo.sh --release-bundles
```

Release AABs are deliberately unsigned. Do not commit a private key or password. Sign the Customer and Partner release bundles with a separately protected Play upload key in CI or Android Studio, then let Play App Signing protect the distribution key.

Individual release tasks are also available:

```sh
cd native_android
./gradlew :customer:bundleRelease
./gradlew :rider:bundleRelease
```

Run the complete four-app release gate directly with `./gradlew verifyProduction`.

## Customer Google sign-in production gate

The Customer app uses Android Credential Manager and exchanges a Google ID token with Firebase Authentication. Before testing each signing channel:

1. In Firebase project `savrivo-app`, enable **Authentication → Sign-in method → Google** and select a support email.
2. Add the SHA-1 for every certificate that can sign an installed Customer app:
   - local debug: run `cd native_android && ./gradlew :customer:signingReport`;
   - Play production/internal/closed tracks: copy the **App signing key certificate SHA-1** from Play Console → Setup → App integrity;
   - add any separate internal-app-sharing signing certificate if that channel is used.
3. Download a fresh `google-services.json` for Android package `com.feastly.app` and replace `native_android/app/google-services.json`.
4. Confirm the file contains a Web OAuth client. Gradle generates `default_web_client_id` from that client; the app never hard-codes a client ID.

The upload certificate and Play app-signing certificate are not necessarily the same. Registering only the upload SHA-1 will make Google sign-in fail in the Play-installed app. Certificate fingerprints are safe to register; private keys and passwords must never be shared or committed.

## First integrated test

1. Run `native_android/tests/run.sh`; do not continue if it fails.
2. Deploy the prepared Firebase RTDB/Storage rules to a **test Firebase project first**, not production.
3. Sign in to Savrivo Admin as the platform owner.
4. Create/verify a restaurant and provision a Restaurant account for it.
5. Sign in to Savrivo Restaurant and verify only the assigned restaurant is visible.
6. Add/edit a menu item, upload a photo, change price and toggle availability. Confirm Customer receives the normalized menu update.
7. Toggle the restaurant offline for 30 minutes. Confirm Customer immediately treats it as unavailable; restore online.
8. In Customer, add a delivery address using the tappable map pin or phone location, then place a COD test order.
9. In Restaurant, accept → preparing → ready for pickup. Confirm the delivery appears to eligible Partner users.
10. Put a Partner online and claim the delivery. Attempt a near-simultaneous second claim from another Partner; only one fresh claim should win.
11. Navigate to restaurant, confirm handover, navigate to customer, and verify the Customer tracking view updates from the foreground GPS service.
12. Complete delivery with the verification flow and confirm it appears in history.

## Important production gates

The repository is substantially safer than the previous developer build, but do **not** take real online payments yet. Production launch still requires trusted server-side price/payment verification, payment-gateway webhooks, production push delivery, Firebase emulator/rules testing, real-device QA, release signing, legal/privacy pages, monitoring and controlled Firebase deployment.
