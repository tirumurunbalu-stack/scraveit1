package com.savrivo.firebase;

import android.app.Activity;
import android.os.CancellationSignal;

import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;
import androidx.credentials.exceptions.NoCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Shared Credential Manager implementation used by Savrivo's approved-role apps. */
public final class GoogleCredentialSignIn {
  public interface Callback {
    void onIdToken(String idToken);
    void onFailure(String message);
  }

  private final Activity activity;
  private final CredentialManager manager;
  private final ExecutorService executor = Executors.newSingleThreadExecutor();
  private CancellationSignal cancellation;
  private boolean inFlight;

  public GoogleCredentialSignIn(Activity activity) {
    this.activity = activity;
    this.manager = CredentialManager.create(activity);
  }

  public void start(String serverClientId, Callback callback) {
    if (inFlight) return;
    if (serverClientId == null || serverClientId.trim().isEmpty()) {
      callback.onFailure("Google sign-in is not configured for this build.");
      return;
    }
    inFlight = true;
    // Always show every Google account available on the device. Filtering to
    // previously authorized accounts made the picker look like a single-account login.
    request(serverClientId, false, callback);
  }

  private void request(String serverClientId, boolean authorizedOnly, Callback callback) {
    GetGoogleIdOption option = new GetGoogleIdOption.Builder()
        .setFilterByAuthorizedAccounts(authorizedOnly)
        .setAutoSelectEnabled(false)
        .setServerClientId(serverClientId)
        .build();
    cancellation = new CancellationSignal();
    manager.getCredentialAsync(
        activity,
        new GetCredentialRequest.Builder().addCredentialOption(option).build(),
        cancellation,
        executor,
        new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
          @Override public void onResult(GetCredentialResponse response) {
            Credential credential = response == null ? null : response.getCredential();
            if (!(credential instanceof CustomCredential)
                || (!GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())
                    && !GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_SIWG_CREDENTIAL.equals(credential.getType()))) {
              finishFailure(callback, "Google did not return a supported sign-in credential.");
              return;
            }
            try {
              String token = GoogleIdTokenCredential.createFrom(credential.getData()).getIdToken();
              if (token == null || token.isEmpty()) {
                finishFailure(callback, "Google did not return a sign-in token. Please try again.");
                return;
              }
              activity.runOnUiThread(() -> {
                inFlight = false;
                cancellation = null;
                callback.onIdToken(token);
              });
            } catch (RuntimeException error) {
              finishFailure(callback, "Google returned an invalid sign-in response. Please try again.");
            }
          }

          @Override public void onError(GetCredentialException error) {
            if (authorizedOnly && error instanceof NoCredentialException) {
              request(serverClientId, false, callback);
              return;
            }
            finishFailure(callback, error instanceof GetCredentialCancellationException
                ? "Google sign-in was cancelled."
                : "Google sign-in could not be completed. Check Google Play services and try again.");
          }
        });
  }

  private void finishFailure(Callback callback, String message) {
    activity.runOnUiThread(() -> {
      inFlight = false;
      cancellation = null;
      callback.onFailure(message);
    });
  }

  public void close() {
    if (cancellation != null) cancellation.cancel();
    executor.shutdownNow();
  }
}
