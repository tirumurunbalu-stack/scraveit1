package com.savrivo.firebase;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONObject;

/** Narrow native bridge exposed only to the locally packaged, trusted WebView page. */
public final class SavrivoOperationsBridge {
    private static final String TAG = "SavrivoCloudBridge";
    public interface TrustedPage {
        boolean isTrusted();
    }

    private static final int NOTIFICATION_PERMISSION_REQUEST = 8431;
    private final Activity activity;
    private final WebView webView;
    private final TrustedPage trustedPage;

    public SavrivoOperationsBridge(Activity activity, WebView webView, TrustedPage trustedPage) {
        this.activity = activity;
        this.webView = webView;
        this.trustedPage = trustedPage;
    }

    @JavascriptInterface public void registerPushToken(String requestId, String idToken) {
        invokeOnMain(requestId, "NATIVE_PUSH_REGISTRATION_UNAVAILABLE", () -> {
            if (!valid(requestId, idToken)) {
                respond(requestId, false, "{\"error\":{\"message\":\"INVALID_REQUEST\"}}");
                return;
            }
            requestNotificationPermission();
            SavrivoCallableClient.registerPushToken(activity, idToken,
                    (success, json) -> respond(requestId, success, json));
        });
    }

    @JavascriptInterface public void unregisterPushToken(String requestId, String idToken) {
        invokeOnMain(requestId, "NATIVE_PUSH_UNREGISTER_UNAVAILABLE", () -> {
            if (!valid(requestId, idToken)) {
                respond(requestId, false, "{\"error\":{\"message\":\"INVALID_REQUEST\"}}");
                return;
            }
            SavrivoCallableClient.unregisterPushToken(activity, idToken,
                    (success, json) -> respond(requestId, success, json));
        });
    }

    @JavascriptInterface public void updateOrderStatus(
            String requestId, String idToken, String payloadJson) {
        try {
            if (payloadJson == null || payloadJson.length() > 64_000) {
                respond(requestId, false, "{\"error\":{\"message\":\"INVALID_REQUEST\"}}");
                return;
            }
            JSONObject payload = new JSONObject(payloadJson);
            invokeOnMain(requestId, "NATIVE_ORDER_UPDATE_UNAVAILABLE", () -> {
                if (!valid(requestId, idToken)) {
                    respond(requestId, false, "{\"error\":{\"message\":\"INVALID_REQUEST\"}}");
                    return;
                }
                SavrivoCallableClient.updateOrderStatus(activity, idToken, payload,
                        (success, json) -> respond(requestId, success, json));
            });
        } catch (Throwable error) {
            Log.e(TAG, "updateOrderStatus bridge failed", error);
            respond(requestId, false,
                    "{\"error\":{\"message\":\"NATIVE_ORDER_UPDATE_UNAVAILABLE\"}}");
        }
    }

    @JavascriptInterface public void claimRiderOrder(
            String requestId, String idToken, String orderId) {
        try {
            invokeOnMain(requestId, "NATIVE_RIDER_CLAIM_UNAVAILABLE", () -> {
                if (!valid(requestId, idToken)) {
                    respond(requestId, false, "{\"error\":{\"message\":\"INVALID_REQUEST\"}}");
                    return;
                }
                SavrivoCallableClient.claimRiderOrder(activity, idToken, orderId,
                        (success, json) -> respond(requestId, success, json));
            });
        } catch (Throwable error) {
            Log.e(TAG, "claimRiderOrder bridge failed", error);
            respond(requestId, false,
                    "{\"error\":{\"message\":\"NATIVE_RIDER_CLAIM_UNAVAILABLE\"}}");
        }
    }

    @JavascriptInterface public void declineRiderOrder(
            String requestId, String idToken, String orderId) {
        try {
            invokeOnMain(requestId, "NATIVE_RIDER_DECLINE_UNAVAILABLE", () -> {
                if (!valid(requestId, idToken)) {
                    respond(requestId, false, "{\"error\":{\"message\":\"INVALID_REQUEST\"}}");
                    return;
                }
                SavrivoCallableClient.declineRiderOrder(activity, idToken, orderId,
                        (success, json) -> respond(requestId, success, json));
            });
        } catch (Throwable error) {
            Log.e(TAG, "declineRiderOrder bridge failed", error);
            respond(requestId, false,
                    "{\"error\":{\"message\":\"NATIVE_RIDER_DECLINE_UNAVAILABLE\"}}");
        }
    }

    @JavascriptInterface public void startOrderAlarm(
            String alarmId, String title, String body, String orderId) {
        activity.runOnUiThread(() -> {
            if (!trustedPage.isTrusted() || !"restaurant".equals(SavrivoFirebase.appRole(activity))) return;
            OrderAlarmService.start(activity, alarmId, title, body, orderId);
        });
    }

    @JavascriptInterface public void stopOrderAlarm(String alarmId) {
        activity.runOnUiThread(() -> {
            if (!trustedPage.isTrusted() || !"restaurant".equals(SavrivoFirebase.appRole(activity))) return;
            OrderAlarmService.stop(activity, alarmId);
        });
    }

    @JavascriptInterface public void dismissRiderOffer(String orderId) {
        activity.runOnUiThread(() -> {
            if (!trustedPage.isTrusted() || !"rider".equals(SavrivoFirebase.appRole(activity))
                    || orderId == null || !orderId.matches("[A-Za-z0-9_.:-]{1,120}")) return;
            NotificationManager manager = activity.getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.cancel(SavrivoNotifications.stableId("rider-offer", orderId));
            }
            OrderAlarmService.stop(activity, "rider-offer:" + orderId);
            SavrivoPushStore.removeRiderOffer(activity, orderId);
        });
    }

    @JavascriptInterface public void startRiderOffer(
            String orderId, String title, String body, long expiresAt, long offeredAt) {
        activity.runOnUiThread(() -> {
            if (!trustedPage.isTrusted() || !"rider".equals(SavrivoFirebase.appRole(activity))
                    || orderId == null || !orderId.matches("[A-Za-z0-9_.:-]{1,120}")
                    || expiresAt <= System.currentTimeMillis()) return;
            OrderAlarmService.start(activity, "rider-offer:" + orderId,
                    title == null ? "New delivery offer" : title,
                    body == null ? "Accept or decline this nearby delivery." : body,
                    orderId, offeredAt);
        });
    }

    private boolean valid(String requestId, String idToken) {
        return trustedPage.isTrusted()
                && requestId != null && requestId.matches("[A-Za-z0-9_-]{1,80}")
                && idToken != null && idToken.length() >= 32 && idToken.length() <= 16_384
                && idToken.matches("[A-Za-z0-9._~-]+");
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT < 33
                || activity.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) return;
        activity.runOnUiThread(() -> {
            if (trustedPage.isTrusted()) {
                activity.requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_REQUEST);
            }
        });
    }

    /**
     * Android invokes {@link JavascriptInterface} methods on its Java bridge worker thread.
     * Firebase Android SDK entry points are lifecycle-aware and must be started from the main
     * thread. Posting every cloud operation here also gives all four apps one consistent bridge
     * boundary instead of leaving individual actions vulnerable to a synchronous SDK failure.
     */
    private void invokeOnMain(String requestId, String failureCode, Runnable action) {
        activity.runOnUiThread(() -> {
            if (!trustedPage.isTrusted() || activity.isFinishing()
                    || (Build.VERSION.SDK_INT >= 17 && activity.isDestroyed())) {
                respond(requestId, false,
                        "{\"error\":{\"message\":\"NATIVE_ACTIVITY_UNAVAILABLE\"}}");
                return;
            }
            try {
                action.run();
            } catch (Throwable error) {
                Log.e(TAG, failureCode, error);
                respond(requestId, false, "{\"error\":{\"message\":"
                        + JSONObject.quote(failureCode) + "}}");
            }
        });
    }

    private void respond(String requestId, boolean success, String json) {
        String safeJson = normalizeJson(json);
        String script = "window.SavrivoNativeCallbacks&&window.SavrivoNativeCallbacks.resolve("
                + JSONObject.quote(requestId) + "," + success + "," + safeJson + ")";
        activity.runOnUiThread(() -> {
            if (trustedPage.isTrusted() && webView != null) {
                webView.evaluateJavascript(script, null);
            }
        });
    }

    private static String normalizeJson(String json) {
        if (json == null || json.length() == 0 || json.length() > 300_000) return "null";
        try { return new JSONObject("{\"v\":" + json + "}").get("v") == null ? "null" : json; }
        catch (Exception ignored) { return JSONObject.quote(json); }
    }
}
