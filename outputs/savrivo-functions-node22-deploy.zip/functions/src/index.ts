import {createHash} from "node:crypto";
import {logger} from "firebase-functions";
import {onValueCreated, onValueUpdated, onValueWritten} from "firebase-functions/v2/database";
import {onCall, onRequest} from "firebase-functions/v2/https";
import {onTaskDispatched} from "firebase-functions/v2/tasks";
import {z} from "zod";
import {db} from "./admin";
import {DATABASE_REGION, REGION, ROOT} from "./config";
import {asHttpsError, DomainError} from "./errors";
import {buildRiderJobProjection} from "./domain/riderJob";
import {buildRestaurantOrderProjection} from "./domain/restaurantOrder";
import {
  claimOrderSchema,
  createCodOrderSchema,
  initiatePaymentSchema,
  registerDeviceTokenSchema,
  transitionOrderSchema,
  unregisterDeviceTokenSchema,
  validationMessage,
} from "./schemas";
import {
  advanceDispatchOffer,
  beginSequentialDispatch,
  claimDispatchOffer,
  type Presence,
  updateRiderAvailabilityIndex,
} from "./services/dispatch";
import {registerDeviceToken, unregisterDeviceToken} from "./services/deviceTokens";
import {
  notifyCustomerStatus,
  notifyRestaurantNewOrder,
  stopRiderOffers,
  stopRestaurantAlarm,
} from "./services/notifications";
import {createAuthoritativeCodOrder, recordCodLedger, scrubLegacyPublicOtp, transitionOrder} from "./services/orders";
import {processTrackingUpdate} from "./services/tracking";
import {reconcileRestaurantWorkload} from "./services/workload";
import {
  callbackHash,
  initiatePayment,
  UnconfiguredPhonePeGateway,
} from "./services/payments";
import type {SavrivoOrder} from "./types";

function parse<S extends z.ZodTypeAny>(schema: S, value: unknown): z.infer<S> {
  const result = schema.safeParse(value);
  if (!result.success) throw new DomainError("invalid-argument", validationMessage(result.error));
  return result.data as z.infer<S>;
}

async function sideEffectLease(key: string, work: () => Promise<void>): Promise<void> {
  const safeKey = createHash("sha256").update(key).digest("hex");
  const ref = db.ref(`${ROOT}/backendEvents/${safeKey}`);
  const now = Date.now();
  const lease = await ref.transaction((current: {status?: string; leaseUntil?: number} | null) => {
    if (current?.status === "done" || Number(current?.leaseUntil ?? 0) > now) return undefined;
    return {status: "running", startedAt: now, leaseUntil: now + 5 * 60_000};
  }, undefined, false);
  if (!lease.committed) return;
  try {
    await work();
    await ref.update({status: "done", completedAt: Date.now(), leaseUntil: 0});
  } catch (error) {
    await ref.update({status: "retry", lastError: error instanceof Error ? error.message.slice(0, 300) : "unknown", leaseUntil: 0});
    throw error;
  }
}

export const createCodOrder = onCall({
  region: REGION,
  enforceAppCheck: true,
  timeoutSeconds: 30,
  memory: "256MiB",
}, async (request) => {
  if (!request.auth) throw asHttpsError(new DomainError("unauthenticated", "Sign in to place an order."));
  try {
    const input = parse(createCodOrderSchema, request.data);
    const result = await createAuthoritativeCodOrder(request.auth.uid, input);
    return {
      orderId: result.order.id,
      order: result.order,
      deliveryOtp: result.deliveryOtp,
      recovered: result.recovered,
    };
  } catch (error) {
    logger.warn("createCodOrder rejected", {uid: request.auth.uid, error});
    throw asHttpsError(error);
  }
});

export const updateOrderStatus = onCall({
  region: REGION,
  enforceAppCheck: true,
  timeoutSeconds: 30,
  memory: "256MiB",
}, async (request) => {
  if (!request.auth) throw asHttpsError(new DomainError("unauthenticated", "Sign in to update an order."));
  try {
    const input = parse(transitionOrderSchema, request.data);
    const result = await transitionOrder(request.auth.uid, request.auth.token, input);
    return {orderId: result.order.id, status: result.order.status, updatedAt: result.order.updatedAt};
  } catch (error) {
    logger.warn("updateOrderStatus rejected", {uid: request.auth.uid, error});
    throw asHttpsError(error);
  }
});

export const claimRiderOrder = onCall({
  region: REGION,
  enforceAppCheck: true,
  timeoutSeconds: 30,
  memory: "256MiB",
}, async (request) => {
  if (!request.auth) throw asHttpsError(new DomainError("unauthenticated", "Sign in to accept a delivery."));
  try {
    const input = parse(claimOrderSchema, request.data);
    const order = await claimDispatchOffer(request.auth.uid, input.orderId);
    return {orderId: order.id, status: order.status, riderId: order.riderId};
  } catch (error) {
    logger.warn("claimRiderOrder rejected", {uid: request.auth.uid, error});
    throw asHttpsError(error);
  }
});

export const registerPushToken = onCall({
  region: REGION,
  enforceAppCheck: true,
  timeoutSeconds: 20,
  memory: "256MiB",
}, async (request) => {
  if (!request.auth) throw asHttpsError(new DomainError("unauthenticated", "Sign in to register this device."));
  try {
    const input = parse(registerDeviceTokenSchema, request.data);
    return await registerDeviceToken(request.auth.uid, request.auth.token, input);
  } catch (error) {
    logger.warn("registerPushToken rejected", {uid: request.auth.uid, error});
    throw asHttpsError(error);
  }
});

export const unregisterPushToken = onCall({
  region: REGION,
  enforceAppCheck: true,
  timeoutSeconds: 20,
  memory: "256MiB",
}, async (request) => {
  if (!request.auth) throw asHttpsError(new DomainError("unauthenticated", "Sign in to remove this device."));
  try {
    const input = parse(unregisterDeviceTokenSchema, request.data);
    return await unregisterDeviceToken(request.auth.uid, input);
  } catch (error) {
    logger.warn("unregisterPushToken rejected", {uid: request.auth.uid, error});
    throw asHttpsError(error);
  }
});

const phonePeGateway = new UnconfiguredPhonePeGateway();

export const createPhonePeIntent = onCall({
  region: REGION,
  enforceAppCheck: true,
  timeoutSeconds: 30,
  memory: "256MiB",
}, async (request) => {
  if (!request.auth) throw asHttpsError(new DomainError("unauthenticated", "Sign in to start payment."));
  try {
    const input = parse(initiatePaymentSchema, request.data);
    return await initiatePayment(request.auth.uid, input, phonePeGateway);
  } catch (error) {
    throw asHttpsError(error);
  }
});

export const phonePeWebhook = onRequest({
  region: REGION,
  timeoutSeconds: 30,
  memory: "256MiB",
  invoker: "public",
}, async (request, response) => {
  if (request.method !== "POST") {
    response.status(405).set("Allow", "POST").send("Method Not Allowed");
    return;
  }
  const rawBody = request.rawBody ?? Buffer.from("");
  const result = await phonePeGateway.verifyWebhook(
    Object.fromEntries(Object.entries(request.headers).map(([key, value]) => [key, Array.isArray(value) ? value[0] : value])),
    rawBody,
  );
  if (!result.verified) {
    logger.warn("Rejected unverified PhonePe callback", {reason: result.reason, callbackHash: callbackHash(rawBody)});
    response.status(503).json({accepted: false, reason: result.reason});
    return;
  }
  // The unconfigured adapter cannot reach this branch. A production adapter
  // must independently query PhonePe status before returning verified:true.
  response.status(501).json({accepted: false, reason: "PRODUCTION_ADAPTER_REQUIRED"});
});

export const dispatchOfferTimeout = onTaskDispatched({
  region: REGION,
  retryConfig: {maxAttempts: 5, minBackoffSeconds: 5, maxBackoffSeconds: 60, maxDoublings: 3},
  rateLimits: {maxConcurrentDispatches: 50, maxDispatchesPerSecond: 20},
}, async (request) => {
  const schema = z.object({orderId: z.string().min(1).max(120), attempt: z.number().int().min(0).max(100)}).strict();
  const input = parse(schema, request.data);
  await advanceDispatchOffer(input.orderId, input.attempt);
});

export const onOrderCreated = onValueCreated({
  ref: `/${ROOT}/orders/{customerId}/{orderId}`,
  region: DATABASE_REGION,
  retry: true,
  timeoutSeconds: 60,
  memory: "256MiB",
}, async (event) => {
  const rawOrder = event.data.val() as SavrivoOrder | null;
  if (!rawOrder) return;
  const order = await scrubLegacyPublicOtp(rawOrder);
  await db.ref(`${ROOT}/restaurantOrders/${order.restaurantId}/${order.customerId}/${order.id}`)
    .set(buildRestaurantOrderProjection(order));
  await reconcileRestaurantWorkload(order);
  await sideEffectLease(`order-created:${event.id}`, () => notifyRestaurantNewOrder(order));
});

export const onOrderUpdated = onValueUpdated({
  ref: `/${ROOT}/orders/{customerId}/{orderId}`,
  region: DATABASE_REGION,
  retry: true,
  timeoutSeconds: 60,
  memory: "256MiB",
}, async (event) => {
  const before = event.data.before.val() as SavrivoOrder | null;
  const rawOrder = event.data.after.val() as SavrivoOrder | null;
  if (!before || !rawOrder) return;
  const order = await scrubLegacyPublicOtp(rawOrder);
  await db.ref(`${ROOT}/restaurantOrders/${order.restaurantId}/${order.customerId}/${order.id}`)
    .set(buildRestaurantOrderProjection(order));
  await reconcileRestaurantWorkload(order);
  if (before.status === order.status) return;

  if (order.status === "Ready for pickup") await beginSequentialDispatch(order);
  if (order.status === "Cancelled") {
    const updates: Record<string, unknown> = {
      [`${ROOT}/dispatchQueue/${order.id}/active`]: false,
      [`${ROOT}/dispatchQueue/${order.id}/status`]: "cancelled",
      [`${ROOT}/tracking/${order.id}`]: null,
      [`${ROOT}/private/trackingEvidence/${order.id}`]: null,
      [`${ROOT}/private/deliveryOtps/${order.id}`]: null,
    };
    if (order.riderId) updates[`${ROOT}/riderJobs/${order.riderId}/${order.id}/status`] = "cancelled";
    await db.ref().update(updates);
  }
  if (order.riderId) {
    if (order.status === "Assigned") {
      await db.ref(ROOT).update({
        [`riderJobs/${order.riderId}/${order.id}`]: buildRiderJobProjection(order),
        [`dispatchQueue/${order.id}/status`]: "assigned",
        [`dispatchQueue/${order.id}/active`]: false,
        [`dispatchQueue/${order.id}/updatedAt`]: order.updatedAt,
        [`riderPresence/${order.riderId}/activeOrderId`]: order.id,
      });
    } else {
      const jobRef = db.ref(`${ROOT}/riderJobs/${order.riderId}/${order.id}`);
      const existingJob = (await jobRef.get()).val() as Record<string, unknown> | null;
      await jobRef.set(buildRiderJobProjection(order, existingJob));
    }
  }
  if (order.status === "Delivered") {
    await recordCodLedger(order);
    const deliveredUpdates: Record<string, null> = {
      [`${ROOT}/tracking/${order.id}`]: null,
      [`${ROOT}/private/trackingEvidence/${order.id}`]: null,
      [`${ROOT}/private/deliveryOtps/${order.id}`]: null,
    };
    if (order.riderId) deliveredUpdates[`${ROOT}/riderPresence/${order.riderId}/activeOrderId`] = null;
    await db.ref().update(deliveredUpdates);
  }

  const notifications: Promise<void>[] = [
    sideEffectLease(`customer-status:${event.id}`, () => notifyCustomerStatus(order)),
  ];
  if (before.status === "Order placed") {
    notifications.push(sideEffectLease(`stop-restaurant-alarm:${event.id}`, () => stopRestaurantAlarm(order)));
  }
  if (order.status === "Assigned" && order.riderId) {
    notifications.push(sideEffectLease(`stop-rider-offers:${event.id}`, async () => {
      const queue = (await db.ref(`${ROOT}/dispatchQueue/${order.id}`).get()).val() as {candidates?: Array<{riderId?: string}>} | null;
      await stopRiderOffers((queue?.candidates ?? []).map((candidate) => String(candidate.riderId ?? "")).filter(Boolean), order.id, order.riderId!);
    }));
  }
  await Promise.all(notifications);
});

export const onRiderPresenceUpdated = onValueWritten({
  ref: `/${ROOT}/riderPresence/{riderId}`,
  region: DATABASE_REGION,
  retry: true,
  timeoutSeconds: 30,
  memory: "256MiB",
}, async (event) => {
  await updateRiderAvailabilityIndex(
    String(event.params.riderId),
    event.data.before.exists() ? event.data.before.val() as Presence : null,
    event.data.after.exists() ? event.data.after.val() as Presence : null,
  );
});

export const onTrackingUpdated = onValueWritten({
  ref: `/${ROOT}/tracking/{orderId}`,
  region: DATABASE_REGION,
  retry: true,
  timeoutSeconds: 30,
  memory: "256MiB",
}, async (event) => {
  const result = await processTrackingUpdate({
    orderId: String(event.params.orderId),
    eventId: event.id,
    authType: event.authType,
    ...(event.authId ? {authId: event.authId} : {}),
    before: event.data.before.exists() ? event.data.before.val() : null,
    after: event.data.after.exists() ? event.data.after.val() : null,
  });
  if (result.outcome === "transitioned") {
    logger.info("Tracking geofence advanced order", {orderId: event.params.orderId, status: result.status});
  }
});
