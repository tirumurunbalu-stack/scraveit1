export const REGION = "asia-south1";
// Realtime Database triggers must be deployed in the database instance's
// location. Savrivo's default RTDB instance is in us-central1; keeping this
// separate lets customer-facing callables stay close to users in India.
export const DATABASE_REGION = "us-central1";
export const ROOT = "feastly";
// Keep version 3 until every installed client and the deployed RTDB rules have
// completed the coordinated schema migration. Server authority is recorded in
// pricingContext without breaking existing order readers.
export const SCHEMA_VERSION = 3;
export const PRESENCE_FRESH_MS = 90_000;
export const RIDER_OFFER_SECONDS = 30;
export const MAX_RIDER_CANDIDATES = 20;
export const MAX_CART_LINES = 50;
export const MAX_ITEMS_PER_LINE = 20;
export const MAX_DEVICE_TOKENS_PER_USER = 20;

export const pathFor = {
  order: (customerId: string, orderId: string) =>
    `${ROOT}/orders/${customerId}/${orderId}`,
  restaurantOrder: (restaurantId: string, customerId: string, orderId: string) =>
    `${ROOT}/restaurantOrders/${restaurantId}/${customerId}/${orderId}`,
  menu: (restaurantId: string) => `${ROOT}/menus/${restaurantId}`,
  restaurant: (restaurantId: string) => `${ROOT}/catalog/restaurants/${restaurantId}`,
  user: (uid: string) => `${ROOT}/users/${uid}`,
  dispatch: (orderId: string) => `${ROOT}/dispatchQueue/${orderId}`,
} as const;
